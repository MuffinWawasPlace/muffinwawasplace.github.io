"""Cash-Secured Put: sell an OTM put backed by cash for 100 shares at the strike. Creates an obligation to BUY."""
from __future__ import annotations

from option_battle.config import Config
from option_battle.models.option import NormalizedChain
from option_battle.models.trade import Leg
from option_battle.strategies.base import META, Strategy, make_trade


class CashSecuredPut(Strategy):
    key, meta = "cash_secured_put", META["cash_secured_put"]

    def build(self, chain: NormalizedChain, exps: list, cfg: Config) -> list:
        lo, hi = cfg.short_delta_range
        center = sum(cfg.delta_bands[self.key]) / 2.0
        per_exp = max(5, cfg.max_candidates_per_strategy // max(1, len(exps)))
        out = []
        for e in exps:
            puts = [c for c in chain.by_exp_right(e, "P") if c.strike < chain.spot]
            for c in self.pick(puts, lo, hi, center, per_exp, need_bid=True, min_oi=cfg.min_open_interest):
                out.append(make_trade(self.key, chain.symbol, chain.spot, [Leg(c, -1)], primary=0))
        return out
