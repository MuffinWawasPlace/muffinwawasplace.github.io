"""Strategy registry. Every strategy builds candidate trades; scoring is shared (analytics/scoring.py)."""
from __future__ import annotations

from option_battle.strategies.base import META, Strategy  # noqa: F401
from option_battle.strategies.cash_secured_put import CashSecuredPut
from option_battle.strategies.covered_call import CoveredCall
from option_battle.strategies.long_options import LongCall, LongPut
from option_battle.strategies.protective import Collar, ProtectivePut
from option_battle.strategies.spreads import BearPutSpread, BullCallSpread, CallCreditSpread, PutCreditSpread

ALL_STRATEGIES = [LongCall(), LongPut(), CoveredCall(), CashSecuredPut(), BullCallSpread(), BearPutSpread(),
                  CallCreditSpread(), PutCreditSpread(), ProtectivePut(), Collar()]
BY_KEY = {s.key: s for s in ALL_STRATEGIES}
