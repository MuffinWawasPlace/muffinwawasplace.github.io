"""Long Call / Long Put: pay premium for convex directional exposure (net long vega, net negative theta)."""
from __future__ import annotations

from option_battle.config import Config
from option_battle.models.option import NormalizedChain
from option_battle.models.trade import Leg
from option_battle.strategies.base import META, Strategy, make_trade


class _LongOption(Strategy):
    right = "C"

    def build(self, chain: NormalizedChain, exps: list, cfg: Config) -> list:
        lo, hi = cfg.long_delta_range
        band = cfg.delta_bands[self.key]
        center = sum(band) / 2.0
        per_exp = max(5, cfg.max_candidates_per_strategy // max(1, len(exps)))
        out = []
        for e in exps:
            for c in self.pick(chain.by_exp_right(e, self.right), lo, hi, center, per_exp, need_bid=False,
                               min_oi=cfg.min_open_interest):
                out.append(make_trade(self.key, chain.symbol, chain.spot, [Leg(c, +1)], primary=0))
        return out


class LongCall(_LongOption):
    key, right, meta = "long_call", "C", META["long_call"]


class LongPut(_LongOption):
    key, right, meta = "long_put", "P", META["long_put"]
