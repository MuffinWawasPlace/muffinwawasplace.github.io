"""Strategy base class + the shared Trade factory.

A strategy ONLY builds candidate trades (legs, prices, exact payoff facts, position Greeks). It does not score.
Scoring lives in analytics/scoring.py so all strategies are ranked by one transparent methodology.

Intent metadata (`bias`, `vega_sign`, ...) is the strategy's *intended* exposure and is used by regime-fit scoring;
the trade's actual net Greeks are also computed and shown, so intent can be checked against reality.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from option_battle.analytics.payoff import payoff_facts
from option_battle.config import Config
from option_battle.models.option import NormalizedChain, OptionContract
from option_battle.models.trade import STRATEGY_NAMES, Leg, Trade


@dataclass(frozen=True)
class StrategyMeta:
    key: str
    family: str            # long | short | debit_spread | credit_spread | hedge
    bias: float            # intended directional exposure -1..+1 (stock-owning strategies: net of the shares)
    vega_sign: float       # +1 long vol, -1 short vol
    vol_weight: float      # how much volatility pricing matters to this structure (0..1)
    owns_shares: bool = False
    needs_cash: bool = False


META: dict = {
    "long_call": StrategyMeta("long_call", "long", +1.00, +1.0, 1.0),
    "long_put": StrategyMeta("long_put", "long", -1.00, +1.0, 1.0),
    "covered_call": StrategyMeta("covered_call", "short", +0.35, -1.0, 1.0, owns_shares=True),
    "cash_secured_put": StrategyMeta("cash_secured_put", "short", +0.50, -1.0, 1.0, needs_cash=True),
    "bull_call_spread": StrategyMeta("bull_call_spread", "debit_spread", +0.75, +1.0, 0.35),
    "bear_put_spread": StrategyMeta("bear_put_spread", "debit_spread", -0.75, +1.0, 0.35),
    "call_credit_spread": StrategyMeta("call_credit_spread", "credit_spread", -0.60, -1.0, 0.45),
    "put_credit_spread": StrategyMeta("put_credit_spread", "credit_spread", +0.60, -1.0, 0.45),
    "protective_put": StrategyMeta("protective_put", "hedge", +0.30, +1.0, 0.45, owns_shares=True),
    "collar": StrategyMeta("collar", "hedge", +0.20, 0.0, 0.20, owns_shares=True),
}


def trade_id(strategy: str, legs: list) -> str:
    parts = [f"{l.contract.expiration:%y%m%d}{l.contract.right}{l.contract.strike:g}{'L' if l.side > 0 else 'S'}"
             for l in legs]
    return f"{strategy}:{'|'.join(parts)}"


def make_trade(strategy: str, underlying: str, spot: float, legs: list, primary: int,
               stock_units: float = 0.0) -> Trade:
    """Assemble a Trade from legs: prices (mid / natural / best), position Greeks, exact payoff facts."""
    exp = legs[0].contract.expiration
    dte = legs[0].contract.dte
    mid = sum(l.side * l.qty * l.contract.mid for l in legs)
    natural = sum(l.side * l.qty * (l.contract.ask if l.side > 0 else l.contract.bid) for l in legs)
    best = sum(l.side * l.qty * (l.contract.bid if l.side > 0 else l.contract.ask) for l in legs)

    def g(attr: str) -> float:
        return sum(l.side * l.qty * (getattr(l.contract, attr) or 0.0) for l in legs)

    delta = g("delta") + stock_units
    facts = payoff_facts(legs, stock_units, spot, mid)
    strikes = sorted({l.contract.strike for l in legs})
    width = (strikes[-1] - strikes[0]) if len(strikes) > 1 else 0.0
    t = Trade(id=trade_id(strategy, legs), strategy=strategy, title=STRATEGY_NAMES[strategy], underlying=underlying,
              expiration=exp, dte=dte, spot=spot, legs=legs, primary=primary, stock_units=stock_units,
              price_mid=mid, price_natural=natural, price_best=best, delta=delta, gamma=g("gamma"),
              theta=g("theta"), vega=g("vega"), max_gain=facts["max_gain"], max_loss=facts["max_loss"],
              breakevens=facts["breakevens"], width=width)
    return t


class Strategy:
    key = ""
    meta: StrategyMeta

    def build(self, chain: NormalizedChain, exps: list, cfg: Config) -> list:
        raise NotImplementedError

    # ---- shared helpers -------------------------------------------------------------------------------------
    @staticmethod
    def pick(contracts: list, lo: float, hi: float, center: float, limit: int, *, need_bid: bool,
             min_oi: int = 0) -> list:
        """Contracts whose |delta| lies in [lo, hi], best `limit` by closeness to `center`."""
        out = []
        for c in contracts:
            if not c.usable or c.delta is None or c.iv is None:
                continue
            if need_bid and not c.sellable:
                continue
            if c.ask <= 0:
                continue
            d = abs(c.delta)
            if lo <= d <= hi and c.open_interest >= min_oi:
                out.append(c)
        out.sort(key=lambda c: abs(abs(c.delta) - center))
        return out[:limit]

    @staticmethod
    def neighbor(chain: NormalizedChain, c: OptionContract, width: float, direction: int) -> Optional[OptionContract]:
        """Same-expiry, same-right contract about `width` dollars away (direction +1 higher strike, -1 lower)."""
        target = c.strike + direction * width
        lst = [x for x in chain.by_exp_right(c.expiration, c.right) if x.delta is not None and x.iv is not None
               and x.ask > 0 and ((x.strike > c.strike) if direction > 0 else (x.strike < c.strike))]
        if not lst:
            return None
        best = min(lst, key=lambda x: abs(x.strike - target))
        return best if abs(best.strike - target) <= max(0.6 * width, 1e-9) else None


def width_targets(spot: float) -> list:
    """Candidate spread widths in dollars (about 1%, 2%, 3.5% of spot), rounded to a sensible increment."""
    out = []
    for pct in (0.01, 0.02, 0.035):
        w = spot * pct
        step = 0.5 if spot < 50 else 1.0 if spot < 300 else 5.0
        out.append(max(step, round(w / step) * step))
    return sorted(set(out))
