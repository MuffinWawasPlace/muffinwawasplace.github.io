"""Protective Put (shares + long put) and Collar (shares + long put + short call).

Both assume ownership of 100 shares per contract: the engine marks them hypothetical when the portfolio does not
show the shares. The primary leg is the long put (the protection)."""
from __future__ import annotations

from option_battle.config import Config
from option_battle.models.option import NormalizedChain
from option_battle.models.trade import Leg
from option_battle.strategies.base import META, Strategy, make_trade


class ProtectivePut(Strategy):
    key, meta = "protective_put", META["protective_put"]

    def build(self, chain: NormalizedChain, exps: list, cfg: Config) -> list:
        center = sum(cfg.delta_bands[self.key]) / 2.0
        per_exp = max(4, cfg.max_candidates_per_strategy // max(1, len(exps)))
        out = []
        for e in exps:
            puts = [c for c in chain.by_exp_right(e, "P") if c.strike < chain.spot]
            for c in self.pick(puts, 0.10, 0.45, center, per_exp, need_bid=False, min_oi=cfg.min_open_interest):
                out.append(make_trade(self.key, chain.symbol, chain.spot, [Leg(c, +1)], primary=0, stock_units=1.0))
        return out


class Collar(Strategy):
    key, meta = "collar", META["collar"]

    def build(self, chain: NormalizedChain, exps: list, cfg: Config) -> list:
        p_center = sum(cfg.delta_bands["collar"]) / 2.0          # the band the collar is scored against
        c_center = sum(cfg.delta_bands["covered_call"]) / 2.0
        out = []
        for e in exps:
            puts = self.pick([c for c in chain.by_exp_right(e, "P") if c.strike < chain.spot], 0.10, 0.45, p_center, 3,
                             need_bid=False, min_oi=cfg.min_open_interest)
            calls = self.pick([c for c in chain.by_exp_right(e, "C") if c.strike > chain.spot], 0.10, 0.35, c_center, 3,
                              need_bid=True, min_oi=cfg.min_open_interest)
            for p in puts:
                for c in calls:
                    out.append(make_trade(self.key, chain.symbol, chain.spot, [Leg(p, +1), Leg(c, -1)], primary=0,
                                          stock_units=1.0))
        return out
