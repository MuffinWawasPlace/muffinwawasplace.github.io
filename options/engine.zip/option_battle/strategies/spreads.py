"""Vertical spreads (defined risk): bull call / bear put (debits) and put credit / call credit (credits).

Primary leg: the SHORT leg for credit spreads, the LONG leg for debit spreads. Widths are about 1% / 2% / 3.5% of spot,
snapped to available strikes.
"""
from __future__ import annotations

from option_battle.config import Config
from option_battle.models.option import NormalizedChain
from option_battle.models.trade import Leg
from option_battle.strategies.base import META, Strategy, make_trade, width_targets


class _Vertical(Strategy):
    right = "C"
    direction = +1          # +1: second leg is a HIGHER strike, -1: LOWER strike
    debit = True

    def build(self, chain: NormalizedChain, exps: list, cfg: Config) -> list:
        lo, hi = cfg.long_delta_range if self.debit else cfg.short_delta_range
        center = sum(cfg.delta_bands[self.key]) / 2.0
        per_exp = max(4, cfg.max_candidates_per_strategy // max(1, len(exps)) // 2)
        out, seen = [], set()
        for e in exps:
            pool = chain.by_exp_right(e, self.right)
            if self.debit:                       # buy the primary, sell the farther leg
                pool = [c for c in pool if (c.strike <= chain.spot * 1.02 if self.right == "C" else c.strike >= chain.spot * 0.98)]
            else:                                # sell the primary (OTM), buy the farther leg
                pool = [c for c in pool if (c.strike > chain.spot if self.right == "C" else c.strike < chain.spot)]
            for p in self.pick(pool, lo, hi, center, per_exp, need_bid=not self.debit, min_oi=cfg.min_open_interest):
                for w in width_targets(chain.spot):
                    o = self.neighbor(chain, p, w, self.direction)
                    if o is None or not o.usable or (self.debit and not o.sellable) or (not self.debit and o.ask <= 0):
                        continue
                    if o.open_interest < cfg.min_open_interest:
                        continue
                    legs = [Leg(p, +1 if self.debit else -1), Leg(o, -1 if self.debit else +1)]
                    t = make_trade(self.key, chain.symbol, chain.spot, legs, primary=0)
                    if t.id in seen or abs(t.price_mid) <= 0:
                        continue
                    seen.add(t.id)
                    out.append(t)
        return out


class BullCallSpread(_Vertical):
    key, meta, right, direction, debit = "bull_call_spread", META["bull_call_spread"], "C", +1, True


class BearPutSpread(_Vertical):
    key, meta, right, direction, debit = "bear_put_spread", META["bear_put_spread"], "P", -1, True


class CallCreditSpread(_Vertical):
    key, meta, right, direction, debit = "call_credit_spread", META["call_credit_spread"], "C", +1, False


class PutCreditSpread(_Vertical):
    key, meta, right, direction, debit = "put_credit_spread", META["put_credit_spread"], "P", -1, False
