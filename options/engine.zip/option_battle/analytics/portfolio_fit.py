"""Portfolio context: current exposure, and how a NEW trade changes it (portfolio fit, kept separate from isolated
trade quality).

Exposure groups, leverage factors and broad/other concentration guidelines are the preserved legacy definitions
(EXPOSURE_GROUPS / BROAD_GROUPS / exposure_key). Position Greeks come from the normalized chain when the contract is
listed (model Greeks from observed IV); otherwise they are a model estimate from the nearest strike's IV, labelled.
"""
from __future__ import annotations

import datetime as dt
from typing import Optional

from option_battle.analytics.greeks import BlackScholes
from option_battle.core.util import clamp
from option_battle.legacy.options_suggester import BROAD_GROUPS, exposure_key
from option_battle.strategies.base import META

_BS = BlackScholes()


def _position_quote(pos, spot: float, chain, cfg, today: dt.date, now_u) -> dict:
    from option_battle.legacy.options_suggester import years_to_expiry
    c = chain.get(pos.expiration, pos.right, pos.strike) if chain is not None else None
    if c is not None and c.mid > 0 and c.bid > 0:
        # Mark at the bid/ask MID whenever a two-sided quote exists, never at the last trade. Greeks come from the
        # contract's own IV; if it has none, they are a model estimate from the nearest strike's IV (mark stays mid).
        if c.delta is not None:
            return {"mark": c.mid, "delta": c.delta, "gamma": c.gamma or 0.0, "theta": c.theta or 0.0,
                    "vega": c.vega or 0.0, "iv": c.iv, "source": f"mid {c.bid:.2f} x {c.ask:.2f} + model Greeks",
                    "kind": "calculated"}
        mid_only = c.mid
    elif c is not None:
        # Listed, but no two-sided quote in this snapshot. Never fall through to intrinsic ($0 for an OTM option):
        # use the last trade if there is one (labelled), otherwise report the mark as unavailable.
        if c.last > 0:
            g = None
            if c.iv:
                g = _BS.greeks(pos.right, spot, pos.strike, c.t_years, cfg.risk_free, cfg.div_for(pos.symbol), c.iv)
            return {"mark": c.last, "delta": g.delta if g else None, "gamma": g.gamma if g else 0.0,
                    "theta": g.theta if g else 0.0, "vega": g.vega if g else 0.0, "iv": c.iv,
                    "source": "LAST TRADE (no bid/ask in this snapshot)" + ("" if g else "; Greeks unavailable"),
                    "kind": "estimated"}
        return {"mark": None, "delta": None, "gamma": 0.0, "theta": 0.0, "vega": 0.0, "iv": None,
                "source": "NO QUOTE (no bid/ask or last trade in this snapshot)", "kind": "unavailable"}
    else:
        mid_only = None
    dte = (pos.expiration - today).days
    if dte < 0:
        return {"mark": 0.0, "delta": 0.0, "gamma": 0.0, "theta": 0.0, "vega": 0.0, "iv": None,
                "source": "expired: confirm expiry/assignment with your broker", "kind": "unavailable"}
    iv = None
    if chain is not None:
        n = chain.nearest(pos.expiration, pos.right, pos.strike) if pos.expiration in chain.expirations() else None
        if n is None:
            exps = chain.expirations()
            if exps:
                e = min(exps, key=lambda x: abs((x - pos.expiration).days))
                n = chain.nearest(e, pos.right, pos.strike)
        iv = n.iv if n is not None else None
    if not iv and mid_only is not None:
        return {"mark": mid_only, "delta": 0.0, "gamma": 0.0, "theta": 0.0, "vega": 0.0, "iv": None,
                "source": "mid of bid/ask; Greeks UNAVAILABLE (no IV in chain)", "kind": "calculated"}
    if not iv:
        intr = max(0.0, spot - pos.strike) if pos.right == "C" else max(0.0, pos.strike - spot)
        return {"mark": intr, "delta": (1.0 if pos.right == "C" else -1.0) if intr > 0 else 0.0, "gamma": 0.0,
                "theta": 0.0, "vega": 0.0, "iv": None, "source": "intrinsic only (contract not listed, no IV)",
                "kind": "estimated"}
    t = years_to_expiry(pos.expiration, now_u)
    g = _BS.greeks(pos.right, spot, pos.strike, t, cfg.risk_free, cfg.div_for(pos.symbol), iv)
    if mid_only is not None:
        return {"mark": mid_only, "delta": g.delta, "gamma": g.gamma, "theta": g.theta, "vega": g.vega, "iv": iv,
                "source": "mid of bid/ask; Greeks estimated from nearest-strike IV", "kind": "calculated"}
    return {"mark": g.price, "delta": g.delta, "gamma": g.gamma, "theta": g.theta, "vega": g.vega, "iv": iv,
            "source": "MODEL ESTIMATE (contract not in chain; nearest-strike IV)", "kind": "estimated"}


def portfolio_state(pf, markets: dict, cfg, today: dt.date, now_u) -> Optional[dict]:
    """markets: symbol -> {'spot': float, 'chain': NormalizedChain|None, 'error': str|None}."""
    if pf is None or pf.empty:
        return None
    warnings: list = []
    positions: list = []
    by_u: dict = {}

    def u(sym: str) -> dict:
        return by_u.setdefault(sym, {"symbol": sym, "shares": 0, "short_calls": 0, "short_puts": 0, "long_calls": 0,
                                     "long_puts": 0, "delta_shares": 0.0, "delta_usd": 0.0, "gamma": 0.0,
                                     "theta_usd": 0.0, "vega_usd": 0.0, "spot": None, "value": 0.0})

    equity = pf.liquid_cash                      # cash + money-market cash equivalents
    warnings.extend(pf.notes)
    short_put_collateral = 0.0
    exp_risk: dict = {}
    for sym, sh in pf.stocks.items():
        mk = markets.get(sym) or {}
        spot = mk.get("spot")
        e = u(sym)
        e["shares"] += sh
        e["spot"] = spot
        if spot:
            e["delta_shares"] += sh
            e["delta_usd"] += sh * spot
            e["value"] += sh * spot
            equity += sh * spot
            positions.append({"label": f"{sym} shares", "qty": sh, "kind": "stock", "spot": spot, "mark": spot,
                              "value": sh * spot, "delta_shares": float(sh), "theta_usd": 0.0, "vega_usd": 0.0,
                              "source": mk.get("source") or "spot"})
        else:
            warnings.append(f"{sym}: no price ({mk.get('error') or 'not loaded'}); holding excluded from equity/exposure")
    for p in pf.options:
        mk = markets.get(p.symbol) or {}
        spot = mk.get("spot")
        e = u(p.symbol)
        if not spot:
            warnings.append(f"{p.label}: no underlying price ({mk.get('error') or 'not loaded'}); excluded")
            continue
        e["spot"] = spot
        if p.expiration < today:
            warnings.append(f"{p.label}: expiration has passed; excluded from exposure, collateral and share coverage "
                            "(confirm expiry/assignment with your broker and remove it)")
            continue
        q = _position_quote(p, spot, mk.get("chain"), cfg, today, now_u)
        mult = p.qty * 100.0
        if q["mark"] is None or q["delta"] is None:
            warnings.append(f"{p.label}: {q['source']}"
                            + ("; excluded from equity" if q["mark"] is None else "")
                            + ("; delta excluded from exposure" if q["delta"] is None else ""))
        val = q["mark"] * mult if q["mark"] is not None else None
        equity += val or 0.0
        ds = (q["delta"] or 0.0) * mult
        e["delta_shares"] += ds
        e["delta_usd"] += ds * spot
        e["gamma"] += q["gamma"] * mult
        e["theta_usd"] += q["theta"] * mult
        e["vega_usd"] += q["vega"] * mult
        e["value"] += val or 0.0
        key = ("short_" if p.qty < 0 else "long_") + ("calls" if p.right == "C" else "puts")
        e[key] += abs(p.qty)
        if p.qty < 0 and p.right == "P":
            short_put_collateral += p.strike * 100.0 * abs(p.qty)
        risk = (p.strike * 100.0 * abs(p.qty)) if p.qty < 0 else max(0.0, val or 0.0)
        ek = p.expiration.isoformat()
        exp_risk[ek] = exp_risk.get(ek, 0.0) + risk
        pnl = None
        if p.entry and q["mark"] is not None:
            pnl = (q["mark"] - p.entry) * mult
        positions.append({"label": p.label, "qty": p.qty, "kind": "option", "spot": spot, "mark": q["mark"], "value": val,
                          "delta_shares": ds, "theta_usd": q["theta"] * mult, "vega_usd": q["vega"] * mult,
                          "iv": q["iv"], "entry": p.entry, "pnl_usd": pnl, "source": q["source"], "data_kind": q["kind"]})
    for sym, e in by_u.items():
        covered = int(e["shares"] // 100)              # whole 100-share lots only (fractional shares never cover)
        e["free_lots"] = max(0, covered - e["short_calls"])
        e["free_shares"] = max(0, e["shares"] - 100 * e["short_calls"])
        if e["short_calls"] > covered:
            warnings.append(f"{sym}: {e['short_calls']} short call(s) vs {e['shares']} shares -> "
                            f"{e['short_calls'] - covered} UNCOVERED (naked) call(s)")
    groups: dict = {}
    for sym, e in by_u.items():
        g, lev = exposure_key(sym)
        groups.setdefault(g, {"group": g, "delta_usd": 0.0, "members": [], "broad": g in BROAD_GROUPS})
        groups[g]["delta_usd"] += e["delta_usd"] * lev
        groups[g]["members"].append(sym + (f" x{lev:g}" if lev != 1 else ""))
    free_cash = pf.liquid_cash - short_put_collateral
    if free_cash < 0:
        warnings.append(f"cash ${pf.liquid_cash:,.0f} is less than the ${short_put_collateral:,.0f} needed to secure existing short "
                        "puts: margin is being used or the cash figure excludes collateral (enter cash NOT already securing puts)")
    tot = {"delta_usd": sum(e["delta_usd"] for e in by_u.values()), "vega_usd": sum(e["vega_usd"] for e in by_u.values()),
           "theta_usd": sum(e["theta_usd"] for e in by_u.values()), "gamma_shares": sum(e["gamma"] for e in by_u.values())}
    return {"equity": equity, "cash": pf.cash, "cash_equivalents": dict(pf.cash_equivalents), "free_cash": max(0.0, free_cash), "short_put_collateral": short_put_collateral,
            "positions": positions, "by_underlying": by_u, "groups": groups, "exp_risk": exp_risk, "totals": tot,
            "warnings": warnings, "equity_note": "cash + stock value + option marks (liquidation basis, model where noted)"}


def _limit_conc(sym: str, cfg) -> float:
    g, _ = exposure_key(sym)
    return cfg.limits.max_underlying_conc_broad if g in BROAD_GROUPS else cfg.limits.max_underlying_conc_other


def trade_requirements(trade, st: Optional[dict]) -> dict:
    """Does the portfolio hold what the structure needs? (shares for covered calls/hedges, cash for CSPs)."""
    meta = META[trade.strategy]
    out = {"needs_shares": meta.owns_shares, "needs_cash": meta.needs_cash, "ok": True, "notes": []}
    if st is None:
        out["ok"] = None
        out["notes"].append("no portfolio entered: share/cash requirements not checked")
        return out
    u = st["by_underlying"].get(trade.underlying, {})
    if meta.owns_shares:
        free = u.get("free_lots", 0) if trade.strategy in ("covered_call", "collar") else int(u.get("shares", 0) // 100)
        out["available_units"] = free
        if free < 1:
            out["ok"] = False
            out["notes"].append(f"requires 100 {trade.underlying} shares per contract"
                                + (" not already covered by short calls" if trade.strategy in ("covered_call", "collar") else "")
                                + f"; portfolio shows {u.get('shares', 0)} shares ({free} usable lot(s))")
    if meta.needs_cash:
        need = trade.primary_leg.contract.strike * 100.0 - trade.credit_mid * 100.0
        out["cash_per_unit"] = need
        out["available_units"] = int(st["free_cash"] // need) if need > 0 else 0
        if st["free_cash"] < need:
            out["ok"] = False
            out["notes"].append(f"needs ${need:,.0f} cash per contract (strike x 100 - credit); free cash "
                                f"${st['free_cash']:,.0f}")
    return out


def trade_fit(trade, m, ctx, st: Optional[dict], sizing: Optional[dict]) -> dict:
    """PORTFOLIO FIT 0..100 (None without a portfolio). Starts at 75; every adjustment is a named statement."""
    if st is None:
        return {"score": None, "statements": [{"tone": "info", "text": "No portfolio entered: showing isolated trade "
                                                                       "quality only."}], "adjustments": []}
    cfg = ctx.cfg
    lim = cfg.limits
    S = trade.spot
    eq = st["equity"]
    adj: list = []
    say: list = []

    def add(pts: float, tone: str, text: str) -> None:
        adj.append({"points": pts, "text": text})
        say.append({"tone": tone, "text": text})

    req = trade_requirements(trade, st)
    for n in req["notes"]:
        add(-35.0, "bad", n)
    u = st["by_underlying"].get(trade.underlying, {})
    shares = u.get("shares", 0)
    d_add = m.net_delta_shares * S                                   # per unit, dollars
    if trade.strategy in ("covered_call", "collar") and req["ok"]:
        k = trade.legs[-1].contract.strike if trade.strategy == "collar" else trade.primary_leg.contract.strike
        add(+8.0, "good", f"uses idle shares: caps upside on 100 of your {shares} {trade.underlying} shares above ${k:g} "
                          "(you keep the premium, give up gains past the strike)")
        d_add = (m.net_delta_shares - 100.0) * S                     # the shares are already in the portfolio
    if trade.strategy == "protective_put" and req["ok"]:
        add(+12.0, "good", f"protects 100 of your {shares} {trade.underlying} shares below "
                           f"${trade.primary_leg.contract.strike:g}")
        d_add = (m.net_delta_shares - 100.0) * S
    if trade.strategy == "cash_secured_put":
        add(0.0, "warn", f"creates an obligation to BUY 100 {trade.underlying} at ${trade.primary_leg.contract.strike:g} "
                         f"(${trade.primary_leg.contract.strike * 100:,.0f}) per contract if assigned"
                         + (f"; you already hold {shares} shares" if shares else ""))
    tot_d = st["totals"]["delta_usd"]
    if eq > 0:
        before, after = abs(tot_d) / eq, abs(tot_d + d_add) / eq
        lim_d = lim.max_portfolio_delta_pct
        if after > before + 0.005:
            tone = "bad" if after > lim_d else "warn" if after > 0.75 * lim_d else "info"
            pts = -15.0 if after > lim_d else -6.0 if after > 0.75 * lim_d else 0.0
            add(pts, tone, f"increases portfolio delta exposure: {before:.0%} -> {after:.0%} of equity "
                           f"(limit {lim_d:.0%})")
        elif after < before - 0.005:
            add(+6.0 if before > 0.5 * lim_d else 0.0, "good",
                f"reduces portfolio delta exposure: {before:.0%} -> {after:.0%} of equity")
        v_add = m.net_vega_usd
        v_before, v_after = st["totals"]["vega_usd"], st["totals"]["vega_usd"] + v_add
        lv = lim.max_portfolio_vega_pct * eq
        if v_add < -1 and v_before <= 0:
            pts = -10.0 if abs(v_after) > lv else -3.0 if abs(v_after) > 0.75 * lv else 0.0
            add(pts, "warn" if pts else "info", f"adds short-volatility exposure: vega ${v_before:,.0f} -> ${v_after:,.0f} "
                                               f"per vol point (limit ${lv:,.0f})")
        elif v_add > 1 and v_before < 0:
            add(+3.0, "good", f"offsets existing short vega (${v_before:,.0f} -> ${v_after:,.0f} per vol point)")
        g, lev = exposure_key(trade.underlying)
        gcur = st["groups"].get(g, {}).get("delta_usd", 0.0)
        gnew = gcur + d_add * lev
        lim_c = _limit_conc(trade.underlying, cfg)
        if abs(gnew) > abs(gcur) + 1:
            c_after = abs(gnew) / eq
            if c_after > lim_c:
                add(-15.0, "bad", f"concentration: {g} exposure {abs(gcur) / eq:.0%} -> {c_after:.0%} of equity "
                                  f"(guideline {lim_c:.0%})")
            elif c_after > 0.75 * lim_c:
                add(-5.0, "warn", f"concentration rising in {g}: {c_after:.0%} of equity (guideline {lim_c:.0%})")
        ek = trade.expiration.isoformat()
        if st["exp_risk"].get(ek):
            add(-4.0, "warn", f"same expiration as existing positions ({ek}): risk clusters on one date "
                              f"(${st['exp_risk'][ek]:,.0f} already expiring then)")
    else:
        say.append({"tone": "warn", "text": "portfolio equity is zero or negative: exposure percentages unavailable"})
    if META[trade.strategy].family in ("long",) and trade.delta < 0 and tot_d > 0:
        add(+4.0, "good", "adds downside protection against existing long delta")
    if sizing and sizing.get("rows"):
        r1 = sizing["rows"][0]
        for b in r1.get("breaches", []):
            add(-10.0, "bad", f"1 contract already breaches: {b}")
    score = clamp(75.0 + sum(a["points"] for a in adj), 0.0, 100.0)
    return {"score": round(score, 1), "statements": say, "adjustments": adj, "requirements": req,
            "method": "75 baseline + named adjustments (shown); independent of isolated trade quality"}
