"""Implied-volatility context: ATM IV, expected move, IV-vs-realized regime, smile neighbours, term structure.

Preserved from the legacy script: the expected-move definition (1 sd = spot x ATM IV x sqrt(t), with the
"ATM straddle x 1.25" fallback) and the IV/RV "vol edge" scale (0.85 -> 1.40). Everything here is CALCULATED from
observed quotes; the IV-vs-RV percentile is an INFERRED context number (this project has no IV history, so it can
not report a true IV rank).
"""
from __future__ import annotations

import datetime as dt
import math
from dataclasses import dataclass
from typing import Optional

from option_battle.core.util import clamp, finite, mean
from option_battle.legacy.options_suggester import is_standard_monthly
from option_battle.models.option import NormalizedChain, OptionContract


@dataclass
class ExpInfo:
    expiration: dt.date
    dte: int
    t_years: float
    atm_strike: Optional[float]
    atm_iv: Optional[float]
    straddle_mid: Optional[float]
    expected_move: Optional[float]          # 1 sd, dollars
    expected_move_pct: Optional[float]
    em_source: str
    iv_rv: Optional[float]                  # ATM IV / realized-vol blend
    standard_monthly: bool
    n_contracts: int

    def to_dict(self) -> dict:
        d = dict(self.__dict__)
        d["expiration"] = self.expiration.isoformat()
        return d


def atm_stats(chain: NormalizedChain, exp: dt.date, spot: float, rv_blend: Optional[float],
              all_exps: set) -> Optional[ExpInfo]:
    cs = [c for c in chain.contracts if c.expiration == exp and c.usable]
    if not cs:
        return None
    t, dte = cs[0].t_years, cs[0].dte
    by_k: dict = {}
    for c in cs:
        by_k.setdefault(c.strike, {})[c.right] = c
    ivk = {}
    for k, d in by_k.items():
        v = [x.iv for x in d.values() if x.iv and x.bid > 0]
        if v:
            ivk[k] = sum(v) / len(v)
    atm_k = atm_iv = None
    if ivk:
        atm_k = min(ivk, key=lambda k: abs(k - spot))
        below = [k for k in ivk if k <= spot]
        above = [k for k in ivk if k > spot]
        if below and above:
            k0, k1 = max(below), min(above)
            w = (spot - k0) / (k1 - k0) if k1 > k0 else 0.0
            atm_iv = ivk[k0] * (1 - w) + ivk[k1] * w
        else:
            atm_iv = ivk[atm_k]
    straddle = None
    for k in sorted(by_k, key=lambda k: abs(k - spot)):
        d = by_k[k]
        if "C" in d and "P" in d and d["C"].bid > 0 and d["P"].bid > 0:
            straddle = d["C"].mid + d["P"].mid
            break
    em, src = None, "unavailable"
    if atm_iv and t > 0:
        em, src = spot * atm_iv * math.sqrt(t), "ATM IV (interpolated across the spot)"
    elif straddle:
        em, src = straddle * 1.25, "ATM straddle x1.25 (approximation)"
        atm_iv = em / (spot * math.sqrt(t)) if (spot > 0 and t > 0) else None
    return ExpInfo(exp, dte, t, atm_k, atm_iv, straddle, em, (em / spot) if (em and spot) else None, src,
                   (atm_iv / rv_blend) if (atm_iv and rv_blend) else None,
                   is_standard_monthly(exp, all_exps), len(cs))


def iv_regime(atm_iv: Optional[float], rv20: Optional[float], rv60: Optional[float],
              rv_series_pctile: Optional[float] = None) -> dict:
    """Is implied vol rich or cheap relative to what the underlying has actually realized?

    ratio = ATM IV / mean(RV20, RV60);  V in [-1, +1] = clamp((ratio - 1.125) / 0.275)  (the legacy lin(0.85..1.40) map,
    re-centred so a typical ~10% variance premium reads as 'Fair').  +1 = rich (favours sellers), -1 = cheap (favours
    buyers).  `rv_pctile` is where today's 20d realized vol sits in its own one-year history (INFERRED context).
    """
    rvs = [v for v in (rv20, rv60) if v]
    rv_blend = (sum(rvs) / len(rvs)) if rvs else None
    if not atm_iv or not rv_blend:
        return {"level": "Unknown", "V": 0.0, "ratio": None, "atm_iv": atm_iv, "rv_blend": rv_blend, "rv20": rv20,
                "rv60": rv60, "rv_pctile": rv_series_pctile, "available": False,
                "note": "needs both an ATM IV and >= 21 daily bars; vol-dependent scores are neutral"}
    ratio = atm_iv / rv_blend
    v = clamp((ratio - 1.125) / 0.275, -1.0, 1.0)
    level = ("Rich" if v >= 0.6 else "Elevated" if v >= 0.2 else "Cheap" if v <= -0.6
             else "Soft" if v <= -0.2 else "Fair")
    return {"level": level, "V": v, "ratio": ratio, "atm_iv": atm_iv, "rv_blend": rv_blend, "rv20": rv20, "rv60": rv60,
            "rv_pctile": rv_series_pctile, "available": True,
            "note": f"ATM IV {atm_iv * 100:.1f}% vs realized {rv_blend * 100:.1f}% (ratio {ratio:.2f})"}


def smile_fair_iv(chain: NormalizedChain, c: OptionContract, max_gap_pct: float = 0.08) -> Optional[float]:
    """IV interpolated (in log-strike) from the nearest usable neighbours on each side of `c`, excluding `c`.
    Used to ask 'is this strike rich or cheap versus its own smile?'.  None when neighbours are missing/too far."""
    lst = [x for x in chain.by_exp_right(c.expiration, c.right) if x is not c and x.iv and x.bid > 0
           and x.open_interest > 0]
    lo = [x for x in lst if x.strike < c.strike]
    hi = [x for x in lst if x.strike > c.strike]
    if not lo or not hi:
        return None
    a, b = max(lo, key=lambda x: x.strike), min(hi, key=lambda x: x.strike)
    if (b.strike - a.strike) > max_gap_pct * c.spot:
        return None
    w = (math.log(c.strike) - math.log(a.strike)) / (math.log(b.strike) - math.log(a.strike))
    return a.iv * (1 - w) + b.iv * w


def term_structure(infos: dict, max_dte: int = 400) -> dict:
    pts = sorted(((i.dte, i.atm_iv) for i in infos.values() if i.atm_iv and i.dte <= max_dte), key=lambda p: p[0])
    out = {"points": [{"dte": d, "iv": v} for d, v in pts], "slope": None, "label": "Unavailable"}
    if len(pts) >= 2 and pts[-1][0] > pts[0][0]:
        slope = (pts[-1][1] - pts[0][1]) / pts[0][1]
        out["slope"] = slope
        out["label"] = ("Backwardation (near-term IV above later IV)" if slope < -0.03
                        else "Contango (normal upward slope)" if slope > 0.03 else "Flat")
    return out
