"""Exact expiry payoff analysis for any combination of option legs + owned shares.

Payoff is piecewise linear in the underlying price, so max gain / max loss / breakevens are EXACT (evaluated at the
kinks), not sampled. Probability and expected-value functions use closed-form lognormal integrals (no grid).

Per-share convention (multiply by 100 for a contract): P&L(S) = sum(side*qty*intrinsic_i(S)) + stock_units*(S - spot0) - net_price
where net_price > 0 is a debit paid and < 0 a credit received.
"""
from __future__ import annotations

import math
from typing import Optional

from option_battle.legacy.options_suggester import norm_cdf


def legs_payoff(legs: list, stock_units: float, spot0: float, price: float, S: float) -> float:
    tot = 0.0
    for l in legs:
        c = l.contract
        intr = max(0.0, S - c.strike) if c.right == "C" else max(0.0, c.strike - S)
        tot += l.side * l.qty * intr
    return tot + stock_units * (S - spot0) - price


def payoff_facts(legs: list, stock_units: float, spot0: float, price: float) -> dict:
    """Exact max gain / max loss (None = unbounded) and breakevens (ascending)."""
    strikes = sorted({l.contract.strike for l in legs})
    pts = [0.0] + strikes
    far = (max(strikes) if strikes else spot0) * 3.0 + spot0
    # slope for S -> infinity: calls contribute side*qty, puts contribute 0, stock contributes stock_units
    slope_inf = stock_units + sum(l.side * l.qty for l in legs if l.contract.right == "C")
    vals = [legs_payoff(legs, stock_units, spot0, price, s) for s in pts]
    far_val = legs_payoff(legs, stock_units, spot0, price, far)
    hi = max(vals + [far_val if slope_inf <= 1e-12 else -math.inf])
    lo = min(vals + [far_val if slope_inf >= -1e-12 else math.inf])
    max_gain = None if slope_inf > 1e-12 else hi
    max_loss = None if slope_inf < -1e-12 else -lo
    # breakevens: linear segments between consecutive points, plus the final ray
    xs = pts + [far]
    ys = vals + [far_val]
    bes: list = []
    for i in range(len(xs) - 1):
        y0, y1 = ys[i], ys[i + 1]
        if y0 == 0.0 and y1 == 0.0:
            continue
        if (y0 < 0 < y1) or (y0 > 0 > y1):
            x = xs[i] + (0 - y0) * (xs[i + 1] - xs[i]) / (y1 - y0)
            bes.append(x)
        elif y0 == 0.0 and xs[i] > 0:
            bes.append(xs[i])
    bes = sorted({round(b, 6) for b in bes})
    return {"max_gain": max_gain, "max_loss": max_loss, "breakevens": bes, "slope_inf": slope_inf,
            "pnl_at_zero": vals[0]}


def _cdf_ln(x: float, S: float, mu: float, sigma: float, t: float) -> float:
    """P(S_T <= x) for lognormal S_T with drift mu (continuous) and vol sigma."""
    if x <= 0:
        return 0.0
    if t <= 0 or sigma <= 0:
        return 1.0 if S <= x else 0.0
    return norm_cdf((math.log(x / S) - (mu - 0.5 * sigma * sigma) * t) / (sigma * math.sqrt(t)))


def prob_profit(legs: list, stock_units: float, spot0: float, price: float, S: float, t: float,
                sigma: float, mu: float) -> Optional[float]:
    """P(P&L > 0 at expiry) under lognormal(mu, sigma). Exact given the breakevens."""
    if sigma <= 0 or t <= 0 or S <= 0:
        return None
    facts = payoff_facts(legs, stock_units, spot0, price)
    edges = [0.0] + facts["breakevens"] + [math.inf]
    p = 0.0
    for a, b in zip(edges[:-1], edges[1:]):
        probe = (a + b) / 2.0 if math.isfinite(b) else a + max(1.0, 0.1 * spot0)
        if probe <= 0:
            probe = b / 2.0 if math.isfinite(b) else 1.0
        if legs_payoff(legs, stock_units, spot0, price, probe) > 0:
            lo = _cdf_ln(a, S, mu, sigma, t)
            hi = 1.0 if not math.isfinite(b) else _cdf_ln(b, S, mu, sigma, t)
            p += max(0.0, hi - lo)
    return min(1.0, max(0.0, p))


def _e_call(S: float, K: float, t: float, mu: float, sigma: float) -> float:
    """E[max(S_T - K, 0)] under lognormal(mu, sigma), undiscounted."""
    if t <= 0 or sigma <= 0:
        return max(0.0, S - K)
    sd = sigma * math.sqrt(t)
    d1 = (math.log(S / K) + (mu + 0.5 * sigma * sigma) * t) / sd
    return S * math.exp(mu * t) * norm_cdf(d1) - K * norm_cdf(d1 - sd)


def _e_put(S: float, K: float, t: float, mu: float, sigma: float) -> float:
    if t <= 0 or sigma <= 0:
        return max(0.0, K - S)
    sd = sigma * math.sqrt(t)
    d1 = (math.log(S / K) + (mu + 0.5 * sigma * sigma) * t) / sd
    return K * norm_cdf(sd - d1) - S * math.exp(mu * t) * norm_cdf(-d1)


def expected_pnl(legs: list, stock_units: float, spot0: float, price: float, S: float, t: float,
                 sigma: float, mu: float) -> Optional[float]:
    """E[P&L at expiry] per share under lognormal(mu, sigma). With mu = r - q and sigma = the traded IV this is
    ~0 minus costs by construction (risk-neutral); with sigma = realized vol and mu ~ 0 it is a MODEL estimate of
    the volatility edge, not a forecast (ignores skew, jumps, drift, early exercise)."""
    if sigma <= 0 or t <= 0 or S <= 0:
        return None
    tot = 0.0
    for l in legs:
        c = l.contract
        e = _e_call(S, c.strike, t, mu, sigma) if c.right == "C" else _e_put(S, c.strike, t, mu, sigma)
        tot += l.side * l.qty * e
    tot += stock_units * (S * math.exp(mu * t) - spot0)
    return tot - price
