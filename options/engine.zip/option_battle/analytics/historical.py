"""Historical move analysis. EVERYTHING here is descriptive statistics of the past - 'historical context only', never a
forecast, and it is labelled that way in the API and the UI.

Look-ahead discipline
  * Every feature used to decide whether a past day "resembles" today is computed from bars up to and including that
    day only (rolling series, no full-sample normalisation).
  * A past day only contributes a forward return when the whole forward window already exists in the data.
  * Overlapping windows are thinned (no two samples closer than max(5, h // 2) bars) so n is not inflated by
    consecutive near-duplicate days; overlapping-window frequencies (excursions, touches) are labelled as such.
"""
from __future__ import annotations

import math
from typing import Optional

from option_battle.analytics.technicals import gaps as gap_series
from option_battle.core.util import autocorr, mean, median, percentile, rank_of, stdev

LABEL = "HISTORICAL CONTEXT ONLY - descriptive statistics of past data, not a forecast"


def _rets(c: list) -> list:
    return [c[i] / c[i - 1] - 1.0 for i in range(1, len(c))]


def _sma_series(c: list, n: int) -> list:
    out, run = [None] * len(c), 0.0
    for i, v in enumerate(c):
        run += v
        if i >= n:
            run -= c[i - n]
        if i >= n - 1:
            out[i] = run / n
    return out


def _atr_series(bars: list, n: int = 14) -> list:
    out = [None] * len(bars)
    trs = [None] + [max(bars[i].high - bars[i].low, abs(bars[i].high - bars[i - 1].close),
                        abs(bars[i].low - bars[i - 1].close)) for i in range(1, len(bars))]
    if len(bars) <= n:
        return out
    atr = sum(trs[1:n + 1]) / n
    out[n] = atr
    for i in range(n + 1, len(bars)):
        atr = (atr * (n - 1) + trs[i]) / n
        out[i] = atr
    return out


def _rsi_series(c: list, n: int = 14) -> list:
    out = [None] * len(c)
    if len(c) <= n:
        return out
    gains = [max(c[i] - c[i - 1], 0.0) for i in range(1, len(c))]
    losses = [max(c[i - 1] - c[i], 0.0) for i in range(1, len(c))]
    ag, al = sum(gains[:n]) / n, sum(losses[:n]) / n

    def val(a, l):
        return 100.0 if (l == 0 and a > 0) else 50.0 if l == 0 else 100.0 - 100.0 / (1.0 + a / l)

    out[n] = val(ag, al)
    for i in range(n, len(gains)):
        ag = (ag * (n - 1) + gains[i]) / n
        al = (al * (n - 1) + losses[i]) / n
        out[i + 1] = val(ag, al)
    return out


def _rv_series(c: list, n: int = 20) -> list:
    out = [None] * len(c)
    lr = [None] + [math.log(c[i] / c[i - 1]) for i in range(1, len(c))]
    for i in range(n, len(c)):
        w = lr[i - n + 1:i + 1]
        m = sum(w) / n
        out[i] = math.sqrt(sum((x - m) ** 2 for x in w) / (n - 1) * 252.0)
    return out


def _trailing_rank(vals: list, i: int, lookback: int = 252) -> Optional[float]:
    if vals[i] is None:
        return None
    win = [v for v in vals[max(0, i - lookback + 1):i + 1] if v is not None]
    return rank_of(win, vals[i]) if len(win) >= 60 else None


class _Feat:
    """Rolling feature series; `at(i)` only reads bars <= i."""

    def __init__(self, bars: list) -> None:
        self.c = [b.close for b in bars]
        self.sma20, self.sma50, self.sma200 = (_sma_series(self.c, n) for n in (20, 50, 200))
        self.atr = _atr_series(bars)
        self.rsi = _rsi_series(self.c)
        self.rv = _rv_series(self.c)

    def at(self, i: int) -> Optional[dict]:
        s20, s50, s200, a = self.sma20[i], self.sma50[i], self.sma200[i], self.atr[i]
        if None in (s20, s50, s200, a) or a <= 0:
            return None
        px = self.c[i]
        trend = 1 if (px > s200 and s50 > s200) else -1 if (px < s200 and s50 < s200) else 0
        z = (px - s20) / a
        ext = "below" if z <= -1.0 else "above" if z >= 1.0 else "near"
        pr = _trailing_rank(self.rv, i)
        vol = None if pr is None else ("low" if pr < 0.33 else "high" if pr > 0.67 else "mid")
        rsi = self.rsi[i]
        return {"trend": trend, "ext": ext, "vol": vol, "z20": z, "rsi": rsi, "rv_pctile": pr}


def _stats(vals: list) -> dict:
    return {"n": len(vals), "mean": mean(vals), "median": median(vals), "best": max(vals), "worst": min(vals),
            "pct_positive": sum(1 for v in vals if v > 0) / len(vals), "p10": percentile(vals, 10),
            "p90": percentile(vals, 90)}


def similar_setups(bars: list, horizons: list, min_n: int = 8) -> dict:
    ft = _Feat(bars)
    n = len(bars)
    cur = ft.at(n - 1)
    if cur is None:
        return {"available": False, "note": "needs >= 200 bars of history to describe today's setup"}
    out = {"available": True, "current": cur, "horizons": {}, "label": LABEL}
    c = ft.c
    for h in horizons:
        res = None
        for crit_name, keys in (("trend state + 20d extension + vol tercile", ("trend", "ext", "vol")),
                                ("trend state + 20d extension", ("trend", "ext"))):
            picks, last = [], -10 ** 9
            for j in range(200, n - h):
                f = ft.at(j)
                if f is None or any(f[k] != cur[k] for k in keys):
                    continue
                if j - last < max(5, h // 2):
                    continue
                last = j
                window = c[j + 1:j + h + 1]
                picks.append((c[j + h] / c[j] - 1.0, min(window) / c[j] - 1.0))
            if len(picks) >= min_n or (res is None and keys == ("trend", "ext")):
                res = {"criteria": crit_name, "n": len(picks)}
                if len(picks) >= min_n:
                    res.update(_stats([p[0] for p in picks]))
                    res["median_worst_dip"] = median([p[1] for p in picks])
                else:
                    res["insufficient"] = True
                    res["note"] = f"only {len(picks)} comparable periods (< {min_n}): not shown"
                if len(picks) >= min_n:
                    break
        out["horizons"][str(h)] = res
    return out


def _streaks(rets: list) -> dict:
    out = {"up": {}, "down": {}}
    for k in (1, 2, 3, 4):
        for name, sgn in (("up", 1), ("down", -1)):
            hit = tot = 0
            for i in range(k, len(rets)):
                if all(sgn * r > 0 for r in rets[i - k:i]):
                    tot += 1
                    hit += 1 if sgn * rets[i] > 0 else 0
            out[name][str(k)] = {"n": tot, "p_continue": (hit / tot) if tot >= 20 else None}
    cur, sgn = 0, 0
    for r in reversed(rets):
        s = 1 if r > 0 else -1 if r < 0 else 0
        if cur == 0:
            sgn, cur = s, 1 if s else 0
        elif s == sgn:
            cur += 1
        else:
            break
    out["current"] = {"direction": "up" if sgn > 0 else "down" if sgn < 0 else "flat", "length": cur}
    return out


def _clustering(rets: list) -> dict:
    a = [abs(r) for r in rets]
    med = median(a) or 0.0
    big = [x > 2.0 * med for x in a]
    pairs = [(big[i], big[i + 1]) for i in range(len(big) - 1)]
    p_big = sum(1 for _, b in pairs if b) / len(pairs) if pairs else None
    after = [b for x, b in pairs if x]
    return {"abs_autocorr_lag1": autocorr(a, 1), "abs_autocorr_lag5": autocorr(a, 5),
            "p_big_next": p_big, "p_big_next_after_big": (sum(after) / len(after)) if len(after) >= 20 else None,
            "n_big": sum(big), "note": "big = |return| > 2 x median |return|"}


def _shocks(rets: list) -> dict:
    res = {"up": {"1d": [], "5d": []}, "down": {"1d": [], "5d": []}}
    for i in range(61, len(rets)):
        sig = stdev(rets[i - 60:i])           # prior 60 returns only
        if not sig or abs(rets[i]) <= 2.0 * sig:
            continue
        side = "up" if rets[i] > 0 else "down"
        if i + 1 < len(rets):
            res[side]["1d"].append(rets[i + 1])
        if i + 5 < len(rets):
            f = 1.0
            for r in rets[i + 1:i + 6]:
                f *= 1.0 + r
            res[side]["5d"].append(f - 1.0)
    out = {}
    for side in ("up", "down"):
        out[side] = {}
        for hz in ("1d", "5d"):
            v = res[side][hz]
            out[side][hz] = {"n": len(v), "mean": mean(v), "median": median(v),
                             "pct_positive": (sum(1 for x in v if x > 0) / len(v)) if v else None} if len(v) >= 5 else {"n": len(v)}
    out["definition"] = "shock day = |return| > 2 sd of the PRIOR 60 returns (no look-ahead)"
    return out


def _excursions(c: list, horizons: list) -> dict:
    out = {}
    n = len(c)
    for h in horizons:
        if n <= h + 20:
            continue
        dd, ru = [], []
        for i in range(n - h):
            w = c[i + 1:i + h + 1]
            dd.append(min(w) / c[i] - 1.0)
            ru.append(max(w) / c[i] - 1.0)
        out[str(h)] = {
            "windows": len(dd), "overlapping": True,
            "drawdown_p50": percentile(dd, 50), "drawdown_p90_worst": percentile(dd, 10),
            "drawdown_worst": min(dd), "rally_p50": percentile(ru, 50), "rally_p90_best": percentile(ru, 90),
            "rally_best": max(ru),
            "p_dip_1pct": sum(1 for x in dd if x <= -0.01) / len(dd), "p_dip_2pct": sum(1 for x in dd if x <= -0.02) / len(dd),
            "p_dip_3pct": sum(1 for x in dd if x <= -0.03) / len(dd), "p_dip_5pct": sum(1 for x in dd if x <= -0.05) / len(dd),
            "p_pop_1pct": sum(1 for x in ru if x >= 0.01) / len(ru), "p_pop_2pct": sum(1 for x in ru if x >= 0.02) / len(ru),
            "p_pop_3pct": sum(1 for x in ru if x >= 0.03) / len(ru), "p_pop_5pct": sum(1 for x in ru if x >= 0.05) / len(ru),
            "basis": "close-to-close within the window; overlapping windows are not independent"}
    return out


def touch_frequency(bars: list, pct: float, horizon: int, direction: str) -> dict:
    """How often did the underlying trade `pct` below ('down') / above ('up') the starting close within `horizon`
    bars (intraday low/high touch), and how often did it FINISH beyond that level? Overlapping windows."""
    n = len(bars)
    if n <= horizon + 20 or pct <= 0:
        return {"n_windows": 0, "touch": None, "finish_beyond": None}
    touch = fin = tot = 0
    for i in range(n - horizon):
        base = bars[i].close
        w = bars[i + 1:i + horizon + 1]
        if direction == "down":
            lvl = base * (1.0 - pct)
            touch += 1 if min(b.low for b in w) <= lvl else 0
            fin += 1 if w[-1].close <= lvl else 0
        else:
            lvl = base * (1.0 + pct)
            touch += 1 if max(b.high for b in w) >= lvl else 0
            fin += 1 if w[-1].close >= lvl else 0
        tot += 1
    return {"n_windows": tot, "touch": touch / tot, "finish_beyond": fin / tot, "horizon_bars": horizon,
            "label": LABEL}


def _level_behavior(bars: list) -> dict:
    atr = _atr_series(bars)
    res = {"near_low": [], "broke_low": [], "near_high": [], "broke_high": []}
    last = {k: -10 ** 9 for k in res}
    n = len(bars)
    for i in range(25, n - 5):
        a = atr[i]
        if not a:
            continue
        plo = min(b.low for b in bars[i - 20:i])
        phi = max(b.high for b in bars[i - 20:i])
        c = bars[i].close
        fwd = bars[i + 5].close / c - 1.0
        for key, cond in (("near_low", plo <= c <= plo + 0.5 * a), ("broke_low", c < plo),
                          ("near_high", phi - 0.5 * a <= c <= phi), ("broke_high", c > phi)):
            if cond and i - last[key] >= 3:
                res[key].append(fwd)
                last[key] = i
    out = {}
    for k, v in res.items():
        out[k] = {"n": len(v), "mean_5d": mean(v), "median_5d": median(v),
                  "pct_positive": (sum(1 for x in v if x > 0) / len(v)) if v else None} if len(v) >= 5 else {"n": len(v)}
    out["definition"] = ("prior 20-bar low/high (excluding the day itself) used as a proxy for support/resistance; "
                         "'near' = within 0.5 ATR without breaking; forward = next 5 closes")
    return out


def historical_context(bars: list, dte: int = 30) -> dict:
    n = len(bars)
    if n < 60:
        return {"available": False, "n_bars": n, "label": LABEL,
                "note": f"{n} bars (< 60): historical statistics unavailable"}
    c = [b.close for b in bars]
    rets = _rets(c)
    a = [abs(r) for r in rets]
    sd = stdev(rets) or 0.0
    h_dte = int(max(3, min(60, round(dte * 252.0 / 365.0))))
    hs = sorted({5, 10, 21, h_dte})
    gp = gap_series(bars)
    peak, mdd = c[0], 0.0
    for v in c:
        peak = max(peak, v)
        mdd = min(mdd, v / peak - 1.0)
    hi52 = max(c[-252:])
    daily = {"n": len(rets), "avg_abs_move": mean(a), "median_abs_move": median(a),
             "abs_p25": percentile(a, 25), "abs_p50": percentile(a, 50), "abs_p75": percentile(a, 75),
             "abs_p90": percentile(a, 90), "sd": sd, "signed_p5": percentile(rets, 5), "signed_p95": percentile(rets, 95),
             "freq_ge_2pct": sum(1 for x in a if x >= 0.02) / len(a), "freq_ge_3pct": sum(1 for x in a if x >= 0.03) / len(a),
             "freq_ge_2sd": sum(1 for x in a if x >= 2 * sd) / len(a) if sd else None}
    gaps = {"n": len(gp), "mean_abs": mean([abs(g) for g in gp]) if gp else None,
            "median_abs": median([abs(g) for g in gp]) if gp else None,
            "p95_up": percentile(gp, 95) if gp else None, "p5_down": percentile(gp, 5) if gp else None,
            "freq_ge_1pct": (sum(1 for g in gp if abs(g) >= 0.01) / len(gp)) if gp else None}
    warnings = []
    if n < 252:
        warnings.append(f"only {n} bars (< 1 year): percentiles and similar-setup counts are thin")
    if not gp:
        warnings.append("bars carry no usable open prices: gap statistics unavailable")
    return {
        "available": True, "label": LABEL, "n_bars": n, "span": f"{bars[0].date} to {bars[-1].date}",
        "horizon_days": h_dte, "horizons": hs, "daily": daily, "gaps": gaps, "streaks": _streaks(rets),
        "clustering": _clustering(rets), "shocks": _shocks(rets), "excursions": _excursions(c, hs),
        "levels": _level_behavior(bars), "similar": similar_setups(bars, hs),
        "drawdown": {"max_drawdown_sample": mdd, "current_from_52w_high": c[-1] / hi52 - 1.0},
        "warnings": warnings}
