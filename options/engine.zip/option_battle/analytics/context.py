"""AnalysisContext: everything the scoring / decision / entry / risk layers need about the MARKET (not about any one
trade), built once per analysis from a provider snapshot. Pure function of its inputs (+ the clock), so tests can pin
`now_u` and get reproducible results."""
from __future__ import annotations

import datetime as dt
import logging
from dataclasses import dataclass, field
from typing import Optional

from option_battle.analytics.events import Event, load_events
from option_battle.analytics.historical import historical_context
from option_battle.analytics.posture import Posture, compute_posture
from option_battle.analytics.regime import RegimeResult, classify_regime
from option_battle.analytics.technicals import Levels, TechnicalSnapshot, compute_snapshot, support_resistance
from option_battle.analytics.volatility import ExpInfo, atm_stats, iv_regime, term_structure
from option_battle.config import Config
from option_battle.data.normalize import normalize_snapshot, snapshot_freshness
from option_battle.legacy.options_suggester import is_standard_monthly, to_et, utc_now
from option_battle.models.market import MarketSnapshot
from option_battle.models.option import NormalizedChain
from option_battle.models.portfolio import PortfolioContext

LOG = logging.getLogger("option_battle.context")


@dataclass
class Context:
    symbol: str
    spot: float
    cfg: Config
    now_u: dt.datetime
    today: dt.date
    provider: str
    is_mock: bool
    snapshot: MarketSnapshot
    chain: NormalizedChain
    bars: list
    tech: TechnicalSnapshot
    levels: Levels
    regime: RegimeResult
    exp: dict                      # date -> ExpInfo (every listed expiration within 400 DTE)
    selected_exps: list
    focus_exp: Optional[dt.date]
    rv20: Optional[float]
    rv60: Optional[float]
    rv_blend: Optional[float]
    ivr: dict
    term: dict
    posture: Posture
    hist: dict
    events: list
    event_coverage: dict
    freshness: dict
    portfolio: Optional[PortfolioContext] = None
    pf_state: Optional[dict] = None
    warnings: list = field(default_factory=list)
    selection_note: str = ""

    @property
    def atr(self) -> Optional[float]:
        return self.tech.atr14

    def info(self, exp: dt.date) -> Optional[ExpInfo]:
        return self.exp.get(exp)


def select_expirations(chain: NormalizedChain, cfg: Config, today: dt.date, explicit: Optional[list] = None,
                       dte_target: Optional[int] = None) -> tuple:
    exps = sorted({c.expiration for c in chain.contracts if c.usable})
    avail = set(exps)
    if explicit:
        sel = sorted(e for e in explicit if e in avail)
        if sel:
            return sel, f"user-selected expirations ({len(sel)})"
    target = dte_target or cfg.preferred_dte
    window = [e for e in exps if cfg.dte_min <= (e - today).days <= cfg.dte_max]
    pool, kind = window, "all listed expirations"
    if not cfg.allow_weeklies:
        monthly = [e for e in window if is_standard_monthly(e, avail)]
        if monthly:
            pool, kind = monthly, "standard monthlies only"
    if not pool:
        near = [e for e in exps if (e - today).days >= 3]
        pool, kind = near[:3], "no expiration in the DTE window: using the nearest available"
    pool = sorted(pool, key=lambda e: abs((e - today).days - target))[:max(1, cfg.max_expirations)]
    pool.sort()
    return pool, f"{kind}, {cfg.dte_min}-{cfg.dte_max} DTE window, {len(pool)} nearest to {target} DTE"


def build_context(snap: MarketSnapshot, cfg: Config, portfolio: Optional[PortfolioContext] = None,
                  extra_events: Optional[list] = None, expirations: Optional[list] = None,
                  dte_target: Optional[int] = None, now_u: Optional[dt.datetime] = None) -> Context:
    now_u = now_u or utc_now()
    today = to_et(now_u).date()
    chain = normalize_snapshot(snap, cfg, now_u, today)
    spot = chain.spot
    bars = snap.bars
    warnings = list(snap.warnings)
    tech = compute_snapshot(bars, spot)
    levels = support_resistance(bars, spot, tech.atr14) if len(bars) >= 40 else Levels(
        note="insufficient history for support/resistance (need >= 40 bars)")
    rv20, rv60 = tech.rv20, tech.rv60
    rvs = [v for v in (rv20, rv60) if v]
    rv_blend = sum(rvs) / len(rvs) if rvs else None
    if rv_blend is None:
        warnings.append("realized volatility unavailable (needs >= 21 daily bars): IV-vs-RV scoring is neutral")
    events, ev_cov = load_events(snap.symbol, today, cfg, snap.events, extra_events)
    ev_dicts = [{"date": e.date, "name": e.name, "risk": e.risk} for e in events]
    regime = classify_regime(bars, spot, ev_dicts, today)
    sel, sel_note = select_expirations(chain, cfg, today, expirations, dte_target)
    all_exps = {c.expiration for c in chain.contracts if c.usable}
    infos: dict = {}
    for e in sorted(all_exps):
        if 0 <= (e - today).days <= 400:
            i = atm_stats(chain, e, spot, rv_blend, all_exps)
            if i is not None:
                infos[e] = i
    target = dte_target or cfg.preferred_dte
    focus = min(sel, key=lambda e: abs((e - today).days - target)) if sel else None
    fi = infos.get(focus) if focus else None
    ivr = iv_regime(fi.atm_iv if fi else None, rv20, rv60, tech.rv_pctile)
    posture = compute_posture(regime, ivr)
    hist = historical_context(bars, fi.dte if fi else target)
    if not hist.get("available"):
        warnings.append(hist.get("note", "historical statistics unavailable"))
    fresh = chain.diag.get("freshness") or snapshot_freshness(snap, cfg, now_u)
    if fresh.get("stale"):
        warnings.append(fresh["note"])
    if not regime.available:
        warnings.extend(regime.notes)
    return Context(symbol=snap.symbol, spot=spot, cfg=cfg, now_u=now_u, today=today, provider=snap.provider,
                   is_mock=snap.is_mock, snapshot=snap, chain=chain, bars=bars, tech=tech, levels=levels,
                   regime=regime, exp=infos, selected_exps=sel, focus_exp=focus, rv20=rv20, rv60=rv60,
                   rv_blend=rv_blend, ivr=ivr, term=term_structure(infos), posture=posture, hist=hist,
                   events=events, event_coverage=ev_cov, freshness=fresh, portfolio=portfolio, warnings=warnings,
                   selection_note=sel_note)
