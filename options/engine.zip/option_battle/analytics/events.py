"""Event awareness.

Honesty rules:
  * Only events with a published schedule are included automatically. FOMC decision days, CPI and Employment Situation
    release dates below were read from federalreserve.gov and bls.gov on 2026-10-08. They can change: verify before
    relying on them. CPI / jobs coverage ends where the agencies' published 2026 calendars end.
  * Earnings, ex-dividend dates and company events are NOT in the CBOE feed. They appear only if you supply them (events
    file or the Settings tab) or if a provider returns them. The coverage report says so explicitly.
  * `risk` is a model classification of how much a release tends to matter to broad index options, not a measurement.
"""
from __future__ import annotations

import datetime as dt
import json
import logging
import os
from dataclasses import dataclass, field
from typing import Optional

from option_battle.config import Config

LOG = logging.getLogger("option_battle.events")
VERIFIED_ON = "2026-10-08"
SRC_FED = f"federalreserve.gov FOMC calendar (read {VERIFIED_ON}; 2027 dates tentative per the Fed)"
SRC_BLS = f"bls.gov release schedule (read {VERIFIED_ON})"

# (first day, second day) - the policy decision / statement is on the second day, 14:00 ET
FOMC = [((2026, 1, 27), (2026, 1, 28)), ((2026, 3, 17), (2026, 3, 18)), ((2026, 4, 28), (2026, 4, 29)),
        ((2026, 6, 16), (2026, 6, 17)), ((2026, 7, 28), (2026, 7, 29)), ((2026, 9, 15), (2026, 9, 16)),
        ((2026, 10, 27), (2026, 10, 28)), ((2026, 12, 8), (2026, 12, 9)),
        ((2027, 1, 26), (2027, 1, 27)), ((2027, 3, 16), (2027, 3, 17)), ((2027, 4, 27), (2027, 4, 28)),
        ((2027, 6, 8), (2027, 6, 9)), ((2027, 7, 27), (2027, 7, 28)), ((2027, 9, 14), (2027, 9, 15)),
        ((2027, 10, 26), (2027, 10, 27)), ((2027, 12, 7), (2027, 12, 8))]
CPI = [(2026, 1, 13), (2026, 2, 13), (2026, 3, 11), (2026, 4, 10), (2026, 5, 12), (2026, 6, 10), (2026, 7, 14),
       (2026, 8, 12), (2026, 9, 11), (2026, 10, 14), (2026, 11, 10), (2026, 12, 10)]
JOBS = [(2026, 1, 9), (2026, 2, 11), (2026, 3, 6), (2026, 4, 3), (2026, 5, 8), (2026, 6, 5), (2026, 7, 2),
        (2026, 8, 7), (2026, 9, 4), (2026, 10, 2), (2026, 11, 6), (2026, 12, 4)]
RISK_W = {"HIGH": 1.0, "MEDIUM": 0.5, "LOW": 0.2}


@dataclass
class Event:
    name: str
    date: dt.date
    time_et: str
    risk: str
    kind: str
    source: str
    implication: str = ""
    days_away: int = 0
    note: str = ""

    def to_dict(self) -> dict:
        d = dict(self.__dict__)
        d["date"] = self.date.isoformat()
        return d


def _implication(kind: str, risk: str) -> str:
    base = {
        "fomc": "Rate decision/statement; index and rate-sensitive vol commonly reprices around it.",
        "cpi": "Inflation print; can move rate expectations and the whole index within minutes.",
        "jobs": "Employment report; can gap the open and reprice rate expectations.",
        "earnings": "Company-specific gap risk; implied vol usually carries an event premium into the print.",
        "ex_dividend": "Short ITM calls face elevated early-assignment risk just before the ex-date.",
    }.get(kind, "User-supplied event; assess gap and volatility risk before expiration.")
    tail = ("Inside a short option's life: short premium carries gap risk, long premium may be paying event-inflated IV."
            if risk in ("HIGH", "MEDIUM") else "Lower expected impact.")
    return f"{base} {tail}"


def _d(t) -> dt.date:
    return dt.date(*t)


def _builtin(today: dt.date, horizon: int) -> list:
    end = today + dt.timedelta(days=horizon)
    out = []
    for (_, b) in FOMC:
        d = _d(b)
        if today <= d <= end:
            out.append(Event("FOMC rate decision", d, "14:00 ET", "HIGH", "fomc", SRC_FED, _implication("fomc", "HIGH")))
    for t in CPI:
        d = _d(t)
        if today <= d <= end:
            out.append(Event("CPI release", d, "08:30 ET", "HIGH", "cpi", SRC_BLS, _implication("cpi", "HIGH")))
    for t in JOBS:
        d = _d(t)
        if today <= d <= end:
            out.append(Event("Employment Situation (jobs report)", d, "08:30 ET", "MEDIUM", "jobs", SRC_BLS,
                             _implication("jobs", "MEDIUM")))
    return out


def _coerce(raw: dict, source: str, symbol: str) -> Optional[Event]:
    try:
        d = raw["date"] if isinstance(raw["date"], dt.date) else dt.date.fromisoformat(str(raw["date"])[:10])
    except (KeyError, ValueError, TypeError):
        return None
    syms = [s.upper() for s in (raw.get("symbols") or [])]
    if syms and symbol.upper() not in syms:
        return None
    risk = str(raw.get("risk", "MEDIUM")).upper()
    risk = risk if risk in RISK_W else "MEDIUM"
    kind = str(raw.get("kind", "user")).lower()
    return Event(str(raw.get("name", "event")), d, str(raw.get("time", raw.get("time_et", "")) or "time n/a"), risk,
                 kind, str(raw.get("source", source)), raw.get("implication") or _implication(kind, risk),
                 note=str(raw.get("note", "")))


def load_events(symbol: str, today: dt.date, cfg: Config, provider_events: Optional[list] = None,
                extra_events: Optional[list] = None, horizon_days: int = 120) -> tuple:
    """-> (events sorted by date, coverage report)."""
    events = _builtin(today, horizon_days)
    user_n = 0
    path = cfg.events_file or os.environ.get("OPTION_BATTLE_EVENTS", "")
    file_note = "none configured"
    if path:
        try:
            with open(path, "r", encoding="utf-8") as fh:
                for raw in json.load(fh):
                    e = _coerce(raw, f"user file {os.path.basename(path)}", symbol)
                    if e and today <= e.date <= today + dt.timedelta(days=horizon_days):
                        events.append(e)
                        user_n += 1
            file_note = f"{path}"
        except (OSError, ValueError, TypeError) as exc:
            file_note = f"could not read {path}: {exc}"
            LOG.warning(file_note)
    for lst, src in ((provider_events, "provider"), (extra_events, "entered in the UI")):
        for raw in lst or []:
            e = _coerce(raw, src, symbol)
            if e and today <= e.date <= today + dt.timedelta(days=horizon_days):
                events.append(e)
                user_n += 1
    for e in events:
        e.days_away = (e.date - today).days
    events.sort(key=lambda e: (e.date, e.name))
    last_cpi, last_jobs = _d(CPI[-1]), _d(JOBS[-1])
    coverage = {
        "fomc": "scheduled dates through 2027 (2027 tentative)",
        "cpi": f"published dates through {last_cpi.isoformat()}" + ("" if today <= last_cpi else " - CALENDAR EXHAUSTED"),
        "jobs": f"published dates through {last_jobs.isoformat()}" + ("" if today <= last_jobs else " - CALENDAR EXHAUSTED"),
        "earnings": "UNAVAILABLE from the CBOE feed - add to an events file or the Settings tab",
        "ex_dividend": "UNAVAILABLE from the CBOE feed - add to an events file or the Settings tab",
        "user_supplied": user_n, "events_file": file_note,
        "verified_on": VERIFIED_ON,
    }
    return events, coverage


def events_before(events: list, expiration: dt.date, today: dt.date) -> list:
    return [e for e in events if today <= e.date <= expiration]


def event_exposure(events: list, expiration: dt.date, today: dt.date, dte: int) -> float:
    """0..1 weight of scheduled event risk inside an option's life: biggest event risk x a horizon factor
    (an event inside a 3-day option matters far more than inside a 45-day one)."""
    inside = events_before(events, expiration, today)
    if not inside:
        return 0.0
    w = max(RISK_W.get(e.risk, 0.5) for e in inside)
    horizon = 0.3 + 0.7 * max(0.0, min(1.0, (45.0 - dte) / 40.0))
    return w * horizon
