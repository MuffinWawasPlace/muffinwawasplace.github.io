"""TradeMetrics: every number about ONE trade that scoring / decision / entry / compare read. Computed once, so all
layers agree and the debugger can show exactly what was fed into the score."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from option_battle.analytics.liquidity import trade_liquidity
from option_battle.analytics.payoff import expected_pnl
from option_battle.analytics.risk import adverse_direction, capital_basis, risk_report
from option_battle.analytics.volatility import smile_fair_iv
from option_battle.analytics.events import event_exposure, events_before
from option_battle.strategies.base import META


@dataclass
class TradeMetrics:
    side: str
    em: Optional[float]
    em_pct: Optional[float]
    atm_iv: Optional[float]
    iv_rv: Optional[float]
    primary_label: str
    primary_delta_abs: float
    primary_iv: Optional[float]
    primary_distance: float            # dollars OTM (negative = ITM)
    primary_distance_pct: float
    em_ratio: Optional[float]          # primary distance / expected move
    credit_mid_usd: float
    debit_mid_usd: float
    spread_cost_usd: float
    spread_cost_pct: float
    net_delta_shares: float
    net_gamma: float
    net_theta_usd: float
    net_vega_usd: float
    pop: Optional[float]
    p_itm_primary: Optional[float]
    max_gain_usd: Optional[float]
    max_loss_usd: Optional[float]
    capital_usd: float
    target_profit_usd: float
    loss_realistic_usd: Optional[float]
    rr: Optional[float]
    roc: float
    annualized_roc: float
    liquidity: dict
    smile_ratio: Optional[float]
    model_edge_rv_usd: Optional[float]
    event_exposure: float
    events_inside: list
    breakeven_nearest_pct: Optional[float]
    risk: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = {k: v for k, v in self.__dict__.items() if k != "risk"}
        return d


def compute_metrics(trade, ctx) -> TradeMetrics:
    cfg = ctx.cfg
    S = trade.spot
    info = ctx.info(trade.expiration)
    em = info.expected_move if info else None
    p = trade.primary_leg.contract
    dist = (p.strike - S) if p.right == "C" else (S - p.strike)
    risk = risk_report(trade, ctx)
    cap, _ = capital_basis(trade)
    credit, debit = trade.credit_mid * 100.0, trade.debit_mid * 100.0
    fam = META[trade.strategy].family
    # target profit: what the structure is designed to earn in the quiet / favourable case
    if fam in ("short", "credit_spread"):
        target = credit
    elif fam in ("long", "debit_spread"):
        fav = None
        if em:
            s_f = S + em if trade.delta > 0 else max(0.01, S - em)
            fav = max(0.0, trade.pnl_expiry(s_f) * 100.0)
        cap_gain = (trade.max_gain * 100.0) if trade.max_gain is not None else None
        target = fav if fav is not None else 0.0
        if cap_gain is not None:
            target = min(target, cap_gain)
    else:  # hedges: value delivered in a 2 EM drop net of cost
        # value of the OPTIONS alone in a 2-EM drop, net of their cost (the share loss is what is being hedged)
        target = 0.0
        if em:
            s_d = max(0.01, S - 2 * em)
            target = max(0.0, (trade.pnl_expiry(s_d) - trade.stock_units * (s_d - S)) * 100.0)
    loss_real = risk["realistic_loss"].get("adverse_2em_usd")
    rr = None
    if loss_real is not None and loss_real > 1e-9:
        rr = target / loss_real
    roc = target / cap if cap > 0 else 0.0
    ann = roc * 365.0 / max(trade.dte, 1)
    liq = trade_liquidity(trade, cfg.spread_abs_ok)
    spread_cost = abs(trade.price_natural - trade.price_mid) * 100.0
    prem = abs(trade.price_mid) * 100.0
    sc_pct = spread_cost / prem if prem > 0 else 1.0
    fair = smile_fair_iv(ctx.chain, p)
    smile_ratio = (p.iv / fair) if (fair and p.iv) else None
    edge = None
    t = p.t_years
    if ctx.rv_blend and t > 0:
        e = expected_pnl(trade.legs, trade.stock_units, S, trade.price_mid, S, t, ctx.rv_blend, 0.0)
        edge = None if e is None else e * 100.0
    inside = events_before(ctx.events, trade.expiration, ctx.today)
    bes = [abs(b - S) / S for b in trade.breakevens]
    return TradeMetrics(
        side=risk["side"], em=em, em_pct=(em / S) if em else None, atm_iv=info.atm_iv if info else None,
        iv_rv=info.iv_rv if info else None, primary_label=p.label, primary_delta_abs=p.abs_delta, primary_iv=p.iv,
        primary_distance=dist, primary_distance_pct=dist / S, em_ratio=(dist / em) if em else None,
        credit_mid_usd=credit, debit_mid_usd=debit, spread_cost_usd=spread_cost, spread_cost_pct=sc_pct,
        net_delta_shares=trade.delta * 100.0, net_gamma=trade.gamma * 100.0, net_theta_usd=trade.theta * 100.0,
        net_vega_usd=trade.vega * 100.0, pop=risk["probability"]["profit_at_expiry"],
        p_itm_primary=risk["probability"]["primary_leg_itm"],
        max_gain_usd=risk["max_gain_usd"], max_loss_usd=risk["max_loss_usd"], capital_usd=cap, target_profit_usd=target,
        loss_realistic_usd=loss_real, rr=rr, roc=roc, annualized_roc=ann, liquidity=liq, smile_ratio=smile_ratio,
        model_edge_rv_usd=edge, event_exposure=event_exposure(ctx.events, trade.expiration, ctx.today, trade.dte),
        events_inside=[e.to_dict() for e in inside], breakeven_nearest_pct=min(bes) if bes else None, risk=risk)
