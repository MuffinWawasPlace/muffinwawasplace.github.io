"""Regime 'posture': the handful of numbers the strategy-fit logic needs, derived from the regime result and the
IV regime. Keeping this in one place means scoring, the debugger and the backtest all read the same definitions.

  D        directional lean -1..+1 (higher-timeframe structure counted explicitly, scaled by regime confidence)
  V        vol richness -1..+1 (+1: IV rich vs realized -> favours sellers)
  R        range-boundness 0..1
  E        vol trend -1 (compressing) .. +1 (expanding)
  overext  -1/0/+1 stretched below/none/above trend
  hedge_need 0..1 how much downside protection the regime argues for
"""
from __future__ import annotations

from dataclasses import dataclass, field

from option_battle.core.util import clamp


@dataclass
class Posture:
    D: float
    D_eff: float
    V: float
    R: float
    E: float
    overext: int
    hedge_need: float
    confidence: float
    label: str
    notes: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return dict(self.__dict__)


def compute_posture(regime, ivr: dict) -> Posture:
    f = regime.features or {}
    notes: list = []
    if not regime.available:
        return Posture(0.0, 0.0, float(ivr.get("V", 0.0)), 0.5, 0.0, 0, 0.0, regime.confidence, regime.label,
                       ["regime unavailable (short history): direction neutral"])
    lean = float(f.get("lean", 0.0))
    bull, bear = bool(f.get("bull_htf")), bool(f.get("bear_htf"))
    D = clamp(lean + 0.35 * (1 if bull else 0) - 0.35 * (1 if bear else 0), -1.0, 1.0)
    notes.append(f"D = lean {lean:+.2f} {'+0.35 (bull structure)' if bull else '-0.35 (bear structure)' if bear else '(no structural tilt)'}")
    label = regime.label
    over = int(f.get("overextended", 0))
    if label == "Overextended Trend":
        D *= 0.5
        notes.append("Overextended: directional conviction halved (chasing risk)")
    elif label == "Mean Reversion":
        z = float(f.get("z20", 0.0))
        D = clamp(-0.25 * z / 3.0, -0.4, 0.4)
        notes.append(f"Mean reversion: lean replaced by fade of the stretch (z20 {z:+.1f})")
    elif label in ("Sideways / Range", "Low-Volatility Compression"):
        D *= 0.5
        notes.append("Range/compression: directional conviction halved")
    elif label in ("High-Volatility Expansion", "Event Risk"):
        D *= 0.7
        notes.append(f"{label}: directional conviction reduced 30%")
    conf = float(regime.confidence)
    D_eff = D * (0.5 + 0.5 * conf)
    R = 0.8 if f.get("range_bound") else clamp(1.0 - abs(lean) * 1.5) * 0.5
    E = 1.0 if f.get("vol_expanding") else -1.0 if f.get("vol_compressing") else 0.0
    ev = 1.0 if (f.get("event_risk")) else 0.0
    hedge = clamp(0.6 * max(0.0, -D) + 0.25 * (1 if over > 0 else 0) + 0.25 * ev * 0.6 + (0.10 if E > 0 else 0.0))
    return Posture(D, D_eff, float(ivr.get("V", 0.0)), R, E, over, hedge, conf, label, notes)
