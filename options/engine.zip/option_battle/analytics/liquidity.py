"""Liquidity and quote-quality scoring (0..1). Preserved scales from the legacy script:
spread% lin(0.15 -> 0.02), open interest on log10 (10 -> 5,000), volume on log10 (1 -> 1,000)."""
from __future__ import annotations

import math

from option_battle.core.util import clamp, lin
from option_battle.models.option import OptionContract

W_SPREAD, W_OI, W_VOL, W_SIZE = 0.45, 0.30, 0.15, 0.10


def contract_liquidity(c: OptionContract, spread_abs_ok: float = 0.05) -> dict:
    spread_q = lin(c.spread_pct, 0.15, 0.02)
    notes = []
    if c.spread <= spread_abs_ok:                      # a nickel-wide market is tight whatever the percentage says
        spread_q = max(spread_q, 0.80)
        notes.append(f"spread ${c.spread:.2f} <= ${spread_abs_ok:.2f}: treated as tight")
    oi_q = lin(math.log10(c.open_interest + 1), 1.0, math.log10(5000))
    vol_q = lin(math.log10(c.volume + 1), 0.0, math.log10(1000))
    size_q = None
    if c.bid_size > 0 and c.ask_size > 0:
        size_q = lin(math.log10(min(c.bid_size, c.ask_size) + 1), 0.0, math.log10(100))
    parts = [(W_SPREAD, spread_q), (W_OI, oi_q), (W_VOL, vol_q)] + ([(W_SIZE, size_q)] if size_q is not None else [])
    tot_w = sum(w for w, _ in parts)
    raw = sum(w * v for w, v in parts) / tot_w
    score = raw * (0.6 + 0.4 * c.quality)
    if not c.sellable:
        score = min(score, 0.35)
        notes.append("no valid bid: cap 0.35")
    if size_q is None:
        notes.append("quote sizes unavailable: weight redistributed")
    return {"score": clamp(score), "spread_q": spread_q, "oi_q": oi_q, "vol_q": vol_q, "size_q": size_q,
            "quality": c.quality, "oi": c.open_interest, "volume": c.volume, "spread_pct": c.spread_pct,
            "spread": c.spread, "notes": notes}


def trade_liquidity(trade, spread_abs_ok: float = 0.05) -> dict:
    legs = [(l, contract_liquidity(l.contract, spread_abs_ok)) for l in trade.legs]
    scores = [x["score"] for _, x in legs]
    weakest = min(legs, key=lambda p: p[1]["score"])
    return {"min": min(scores), "mean": sum(scores) / len(scores),
            "score": 0.7 * min(scores) + 0.3 * (sum(scores) / len(scores)),
            "weakest": weakest[0].contract.label, "legs": [{"label": l.contract.label, **x} for l, x in legs]}
