"""Plain-language reasons built ONLY from computed numbers (deterministic templates, no LLM).

why_ranked:   the strongest score components, phrased with their inputs, plus the margin over nearby candidates
what_breaks:  the concrete adverse scenarios already computed by the risk engine
"""
from __future__ import annotations

from option_battle.strategies.base import META


def money(x: float) -> str:
    return ("-$" if x < 0 else "$") + f"{abs(x):,.0f}"


def action_label(trade) -> str:
    legs = trade.legs
    if len(legs) == 1:
        l = legs[0]
        word = "CALL" if l.contract.right == "C" else "PUT"
        base = f"{l.action} ${l.contract.strike:g} {word}"
        if trade.strategy == "covered_call":
            return base + " (covered)"
        if trade.strategy == "protective_put":
            return base + " (protective)"
        return base
    if trade.strategy == "collar":
        p, c = legs[0].contract, legs[1].contract
        return f"COLLAR ${p.strike:g}P / ${c.strike:g}C"
    a, b = legs[0].contract, legs[1].contract
    word = "CALL" if a.right == "C" else "PUT"
    verb = "SELL" if trade.price_mid < 0 else "BUY"
    lo, hi = sorted((a.strike, b.strike))
    return f"{verb} ${lo:g}/${hi:g} {word} SPREAD"


def short_label(trade) -> str:
    if len(trade.legs) == 1:
        c = trade.legs[0].contract
        return f"${c.strike:g}{c.right}"
    ks = "/".join(f"{l.contract.strike:g}" for l in trade.legs)
    return f"${ks}{trade.legs[0].contract.right if len({l.contract.right for l in trade.legs}) == 1 else ''}"


def why_ranked(e, ctx, rank_peers: list) -> list:
    s, m, t = e.score, e.metrics, e.trade
    comps = {c["key"]: c for c in s.components}
    out = []

    def strong(k: str, thr: float = 0.70) -> bool:
        return comps[k]["factor"] >= thr and comps[k]["weight"] > 0

    if strong("regime_fit"):
        out.append(f"Strong regime fit: {META[t.strategy].family.replace('_', ' ')} exposure suits "
                   f"{ctx.regime.label} (fit {comps['regime_fit']['factor']:.2f})")
    if strong("vol_edge") and m.iv_rv is not None:
        out.append(f"Favourable volatility pricing: ATM IV / realized {m.iv_rv:.2f} ({ctx.ivr.get('level', '?')})")
    if strong("liquidity"):
        lg = m.liquidity["legs"][0]
        out.append(f"Good liquidity: spread {lg['spread_pct'] * 100:.1f}%, open interest {lg['oi']:,}")
    if strong("technical_fit"):
        p = t.primary_leg.contract
        sup = ctx.levels.supports[0].price if (ctx.levels.available and ctx.levels.supports) else None
        res = ctx.levels.resistances[0].price if (ctx.levels.available and ctx.levels.resistances) else None
        if p.right == "P" and sup and p.strike < sup and META[t.strategy].family in ("short", "credit_spread"):
            out.append(f"Strike ${p.strike:g} sits below support ${sup:.2f}, {m.em_ratio:.2f}x the expected move away")
        elif p.right == "C" and res and p.strike > res and META[t.strategy].family in ("short", "credit_spread"):
            out.append(f"Strike ${p.strike:g} sits above resistance ${res:.2f}, {m.em_ratio:.2f}x the expected move away")
        else:
            out.append(f"Favourable strike location (technical fit {comps['technical_fit']['factor']:.2f})")
    if strong("risk_reward"):
        if t.price_mid < 0 and t.strategy in ("cash_secured_put", "covered_call"):
            out.append(f"Attractive premium for {t.dte} DTE: {m.annualized_roc * 100:.1f}% annualized on capital")
        elif t.price_mid < 0:
            out.append(f"Credit ${t.credit_mid:.2f} on a ${t.width:g} wide spread with model P(profit) "
                       f"{(m.pop or 0) * 100:.0f}%")
        else:
            out.append(f"Payoff profile: risk/reward factor {comps['risk_reward']['factor']:.2f}")
    if strong("theta_profile"):
        out.append(f"Decay profile suits the structure ({t.dte} DTE, theta {"+" if m.net_theta_usd >= 0 else "-"}${abs(m.net_theta_usd):.2f}/day)")
    if strong("delta_fit", 0.85):
        out.append(f"|Delta| {m.primary_delta_abs:.2f} inside the target band")
    if rank_peers:
        nxt = rank_peers[0]
        out.append(f"Scores {s.total - nxt[0]:+.1f} vs the next same-strategy candidate ({nxt[1]})")
    if not out:
        out.append("Highest total under the current weights, but no single component is strong")
    return out


def what_breaks(e, ctx, inval: dict) -> list:
    m, t = e.metrics, e.trade
    r = m.risk or {}
    out = []
    if inval.get("level"):
        out.append(f"Thesis level fails: {inval['text']}")
    vr = r.get("vol_risk") or {}
    meta = META[t.strategy]
    if meta.vega_sign < 0 and vr.get("pnl_iv_up5_usd") is not None:
        out.append(f"Volatility expands sharply: +5 IV points marks about {money(vr['pnl_iv_up5_usd'])} per contract")
    elif meta.vega_sign > 0 and vr.get("pnl_iv_down5_usd") is not None:
        out.append(f"Volatility collapses: -5 IV points marks about {money(vr['pnl_iv_down5_usd'])} per contract")
    g = r.get("gap") or {}
    if g.get("available"):
        out.append(f"Overnight gap at the historical {('5th' if g['gap_pct'] < 0 else '95th')} percentile "
                   f"({g['gap_pct'] * 100:+.1f}%): about {money(g['pnl_usd'])} per contract")
    if m.events_inside:
        names = ", ".join(f"{x['name']} {x['date']}" for x in m.events_inside[:3])
        out.append(f"Scheduled event before expiration: {names}")
    rl = r.get("realistic_loss") or {}
    if rl.get("adverse_2em_usd"):
        out.append(f"A 2-expected-move adverse finish loses about ${rl['adverse_2em_usd']:,.0f} per contract at expiry")
    if ctx.regime.label not in ("Sideways / Range",):
        out.append(f"Market regime changes away from {ctx.regime.label} (confidence {ctx.regime.confidence:.0%})")
    if (r.get("assignment") or {}).get("level") in ("ELEVATED", "HIGH"):
        out.append("Early assignment: " + r["assignment"]["notes"][0])
    return out
