"""Multi-option comparison: side-by-side metrics and category winners (different contracts may win different
categories; 'best overall' is simply the highest Trade Quality)."""
from __future__ import annotations


def _support_distance(e, ctx):
    p = e.trade.primary_leg.contract
    lv = ctx.levels
    if not lv.available or not ctx.atr:
        return None
    if p.right == "P" and lv.supports:
        return (lv.supports[0].price - p.strike) / ctx.atr
    if p.right == "C" and lv.resistances:
        return (p.strike - lv.resistances[0].price) / ctx.atr
    return None


def compare(evals: list, ctx) -> dict:
    rows = []
    for e in evals:
        t, m, s = e.trade, e.metrics, e.score
        rows.append({
            "id": t.id, "label": e.short_label, "action": e.action, "strategy": t.title, "expiration": t.expiration.isoformat(),
            "dte": t.dte, "premium_usd": (m.credit_mid_usd if t.price_mid < 0 else -m.debit_mid_usd),
            "delta_shares": m.net_delta_shares, "gamma": m.net_gamma, "theta_usd": m.net_theta_usd, "vega_usd": m.net_vega_usd,
            "iv": m.primary_iv, "liquidity": m.liquidity["score"], "em_coverage": m.em_ratio,
            "support_distance_atr": _support_distance(e, ctx), "breakevens": t.breakevens, "pop": m.pop,
            "p_itm": m.p_itm_primary, "max_loss_usd": m.max_loss_usd, "capital_usd": m.capital_usd,
            "annualized_roc": m.annualized_roc, "score": s.total, "status": e.decision["status"],
            "armor": s.battle["armor"], "portfolio_fit": (e.fit or {}).get("score"),
            "portfolio_notes": [x["text"] for x in (e.fit or {}).get("statements", [])][:3],
        })
    if not rows:
        return {"rows": [], "winners": {}}

    def best(key, reverse=True, filt=None):
        cand = [r for r in rows if r.get(key) is not None and (filt is None or filt(r))]
        if not cand:
            return None
        r = max(cand, key=lambda r: r[key]) if reverse else min(cand, key=lambda r: r[key])
        return {"id": r["id"], "label": r["label"], "value": r[key]}

    winners = {
        "safety": best("armor"),
        "premium": best("premium_usd"),
        "theta": best("theta_usd"),
        "liquidity": best("liquidity"),
        "overall": best("score"),
    }
    defs = {"safety": "highest ARMOR (strike location vs expected move/levels blended with model P(profit))",
            "premium": "largest net credit received (or smallest debit paid)",
            "theta": "largest positive time decay in $/day per contract",
            "liquidity": "highest liquidity score", "overall": "highest Trade Quality score"}
    return {"rows": rows, "winners": winners, "definitions": defs}
