"""Technical indicators + support/resistance, computed from daily bars.

Every function takes only the bars it is given. Backtests slice `bars[: t + 1]` so nothing here can see the
future; pivots need `right` confirming bars after the pivot, so the most recent pivots are naturally excluded.

Indicator primitives (SMA, Wilder RSI, Wilder ATR, realized vol, RV percentile, returns) are reused from the
preserved legacy script rather than re-implemented.
"""
from __future__ import annotations

import datetime as dt
import math
from dataclasses import dataclass, field
from typing import Optional

from option_battle.core.util import autocorr, mean, median, percentile, rank_of, stdev
from option_battle.legacy.options_suggester import (  # noqa: F401  (re-exported for callers)
    atr_wilder, pct_return, realized_vol, rsi_wilder, rv_percentile, sma,
)
from option_battle.models.market import Bar


def closes_of(bars: list) -> list:
    return [b.close for b in bars]


def ema(vals: list, n: int) -> Optional[float]:
    if len(vals) < n:
        return None
    k = 2.0 / (n + 1)
    e = sum(vals[:n]) / n
    for v in vals[n:]:
        e = v * k + e * (1 - k)
    return e


def log_returns(closes: list) -> list:
    return [math.log(closes[i] / closes[i - 1]) for i in range(1, len(closes)) if closes[i - 1] > 0 and closes[i] > 0]


def true_ranges(bars: list) -> list:
    out = []
    for i in range(1, len(bars)):
        h, l, pc = bars[i].high, bars[i].low, bars[i - 1].close
        out.append(max(h - l, abs(h - pc), abs(l - pc)))
    return out


def avg_tr(bars: list, n: int) -> Optional[float]:
    trs = true_ranges(bars)
    return sum(trs[-n:]) / n if len(trs) >= n else None


def gaps(bars: list) -> list:
    """Overnight gap fractions: open / previous close - 1 (needs a genuine open; bars with open<=0 skipped)."""
    return [bars[i].open / bars[i - 1].close - 1.0 for i in range(1, len(bars))
            if bars[i].open > 0 and bars[i - 1].close > 0]


def weekly_bars(bars: list) -> list:
    """Resample daily bars into ISO-week bars (open of first day, close of last day)."""
    out: list = []
    cur_key = None
    for b in bars:
        key = b.date.isocalendar()[:2]
        if key != cur_key:
            out.append(Bar(b.date, b.open, b.high, b.low, b.close, b.volume))
            cur_key = key
        else:
            w = out[-1]
            out[-1] = Bar(b.date, w.open, max(w.high, b.high), min(w.low, b.low), b.close, w.volume + b.volume)
    return out


def bollinger_width(closes: list, n: int = 20) -> Optional[float]:
    if len(closes) < n:
        return None
    w = closes[-n:]
    m = sum(w) / n
    sd = math.sqrt(sum((x - m) ** 2 for x in w) / (n - 1))
    return (4.0 * sd) / m if m > 0 else None


def bollinger_width_pctile(closes: list, n: int = 20, lookback: int = 252) -> Optional[float]:
    if len(closes) < n + 40:
        return None
    series = []
    for end in range(n, len(closes) + 1):
        bw = bollinger_width(closes[:end], n)
        if bw is not None:
            series.append(bw)
    series = series[-lookback:]
    return rank_of(series, series[-1]) if series else None


# ----------------------------------------------------------------------------- support / resistance

@dataclass
class Level:
    price: float
    kind: str                 # support | resistance
    touches: int
    last_touch: Optional[dt.date]
    strength: float           # touches, recency-weighted
    source: str = "swing"     # swing | range | 52w
    distance_atr: Optional[float] = None
    distance_pct: Optional[float] = None


@dataclass
class Levels:
    supports: list = field(default_factory=list)       # nearest first
    resistances: list = field(default_factory=list)    # nearest first
    available: bool = False
    note: str = ""


def swing_points(bars: list, left: int = 3, right: int = 3) -> tuple:
    highs, lows = [], []
    n = len(bars)
    for i in range(left, n - right):
        win_h = [b.high for b in bars[i - left:i + right + 1]]
        win_l = [b.low for b in bars[i - left:i + right + 1]]
        if bars[i].high >= max(win_h):
            highs.append((i, bars[i].high))
        if bars[i].low <= min(win_l):
            lows.append((i, bars[i].low))
    return highs, lows


def _cluster(points: list, tol: float, n_bars: int, bars: list, kind: str) -> list:
    pts = sorted(points, key=lambda p: p[1])
    clusters: list = []
    for idx, px in pts:
        if clusters and abs(px - mean([p[1] for p in clusters[-1]])) <= tol:  # type: ignore[arg-type]
            clusters[-1].append((idx, px))
        else:
            clusters.append([(idx, px)])
    out = []
    for cl in clusters:
        price = sum(p[1] for p in cl) / len(cl)
        recent = sum(1 for p in cl if n_bars - p[0] <= 60)
        last_i = max(p[0] for p in cl)
        out.append(Level(price, kind, len(cl), bars[last_i].date, len(cl) + 0.75 * recent))
    return out


def support_resistance(bars: list, spot: float, atr: Optional[float], lookback: int = 252,
                       min_touches: int = 2, max_each: int = 4) -> Levels:
    """Swing-pivot clusters within +/-0.5 ATR, plus the 20-day and 52-week extremes as reference levels.
    Levels are inferred from past pivots: they describe where price previously turned, not where it will."""
    if len(bars) < 40 or spot <= 0:
        return Levels(note="insufficient history for support/resistance (need >= 40 bars)")
    win = bars[-lookback:]
    tol = max(0.5 * (atr or 0.0), 0.004 * spot)
    hi_pts, lo_pts = swing_points(win)
    n = len(win)
    cands = _cluster(hi_pts + lo_pts, tol, n, win, "level")
    sup, res = [], []
    for lv in cands:
        if lv.touches < min_touches:
            continue
        (sup if lv.price < spot else res).append(lv)
    for lv in sup:
        lv.kind = "support"
    for lv in res:
        lv.kind = "resistance"
    hi20, lo20 = max(b.high for b in win[-20:]), min(b.low for b in win[-20:])
    hi52, lo52 = max(b.high for b in win), min(b.low for b in win)
    for price, src in ((lo20, "20d low"), (lo52, "52w low")):
        if price < spot and not any(abs(price - l.price) <= tol for l in sup):
            sup.append(Level(price, "support", 1, None, 1.0, src))
    for price, src in ((hi20, "20d high"), (hi52, "52w high")):
        if price > spot and not any(abs(price - l.price) <= tol for l in res):
            res.append(Level(price, "resistance", 1, None, 1.0, src))
    sup.sort(key=lambda l: -l.price)
    res.sort(key=lambda l: l.price)
    for lv in sup + res:
        lv.distance_pct = (lv.price - spot) / spot
        lv.distance_atr = ((lv.price - spot) / atr) if atr else None
    return Levels(sup[:max_each], res[:max_each], True,
                  f"{len(hi_pts)} swing highs / {len(lo_pts)} swing lows in last {len(win)} bars; "
                  f"cluster tolerance {tol:.2f}")


# ----------------------------------------------------------------------------- snapshot

@dataclass
class TechnicalSnapshot:
    price: float
    bars: int
    last_bar: Optional[str]
    sma10: Optional[float] = None
    sma20: Optional[float] = None
    sma50: Optional[float] = None
    sma200: Optional[float] = None
    ema21: Optional[float] = None
    rsi14: Optional[float] = None
    atr14: Optional[float] = None
    atr14_pct: Optional[float] = None
    atr50: Optional[float] = None
    atr_ratio: Optional[float] = None          # ATR14 / ATR50 (>1 = expanding ranges)
    rv5: Optional[float] = None
    rv10: Optional[float] = None
    rv20: Optional[float] = None
    rv60: Optional[float] = None
    rv_pctile: Optional[float] = None
    ret1: Optional[float] = None
    ret5: Optional[float] = None
    ret10: Optional[float] = None
    ret20: Optional[float] = None
    ret60: Optional[float] = None
    hi20: Optional[float] = None
    lo20: Optional[float] = None
    hi52: Optional[float] = None
    lo52: Optional[float] = None
    dist_hi20_atr: Optional[float] = None
    dist_lo20_atr: Optional[float] = None
    z20: Optional[float] = None                # (price - SMA20) / ATR14
    z50: Optional[float] = None                # (price - SMA50) / ATR14
    bb_width: Optional[float] = None
    bb_width_pctile: Optional[float] = None
    range20_atr: Optional[float] = None        # 20d high-low range in ATRs (small = tight range)
    sma50_slope10: Optional[float] = None      # SMA50 now vs 10 bars ago
    avg_volume20: Optional[float] = None
    vol_ratio: Optional[float] = None          # last volume / 20d average
    last_tr_atr: Optional[float] = None        # last true range in ATRs
    notes: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return dict(self.__dict__)


def compute_snapshot(bars: list, spot: Optional[float] = None) -> TechnicalSnapshot:
    n = len(bars)
    px = spot if spot and spot > 0 else (bars[-1].close if bars else 0.0)
    snap = TechnicalSnapshot(price=px, bars=n, last_bar=bars[-1].date.isoformat() if bars else None)
    if n < 20:
        snap.notes.append(f"only {n} bars: most indicators unavailable")
        return snap
    c = closes_of(bars)
    snap.sma10, snap.sma20, snap.sma50, snap.sma200 = sma(c, 10), sma(c, 20), sma(c, 50), sma(c, 200)
    snap.ema21 = ema(c, 21)
    snap.rsi14 = rsi_wilder(c, 14)
    snap.atr14 = atr_wilder(bars, 14)
    snap.atr14_pct = (snap.atr14 / px) if snap.atr14 and px else None
    snap.atr50 = avg_tr(bars, 50)
    a14 = avg_tr(bars, 14)
    snap.atr_ratio = (a14 / snap.atr50) if a14 and snap.atr50 else None
    snap.rv5, snap.rv10 = realized_vol(c, 5), realized_vol(c, 10)
    snap.rv20, snap.rv60 = realized_vol(c, 20), realized_vol(c, 60)
    snap.rv_pctile = rv_percentile(c)
    for k, nn in (("ret1", 1), ("ret5", 5), ("ret10", 10), ("ret20", 20), ("ret60", 60)):
        setattr(snap, k, pct_return(c, nn))
    snap.hi20, snap.lo20 = max(b.high for b in bars[-20:]), min(b.low for b in bars[-20:])
    w52 = bars[-252:]
    snap.hi52, snap.lo52 = max(b.high for b in w52), min(b.low for b in w52)
    if snap.atr14:
        snap.dist_hi20_atr = (snap.hi20 - px) / snap.atr14
        snap.dist_lo20_atr = (px - snap.lo20) / snap.atr14
        if snap.sma20:
            snap.z20 = (px - snap.sma20) / snap.atr14
        if snap.sma50:
            snap.z50 = (px - snap.sma50) / snap.atr14
        snap.range20_atr = (snap.hi20 - snap.lo20) / snap.atr14
        snap.last_tr_atr = true_ranges(bars[-2:])[-1] / snap.atr14
    snap.bb_width = bollinger_width(c)
    snap.bb_width_pctile = bollinger_width_pctile(c)
    if n >= 60 and snap.sma50:
        prev = sma(c[:-10], 50)
        snap.sma50_slope10 = (snap.sma50 / prev - 1.0) if prev else None
    vols = [b.volume for b in bars[-21:-1]]
    if vols and all(v > 0 for v in vols) and bars[-1].volume > 0:
        snap.avg_volume20 = sum(vols) / len(vols)
        snap.vol_ratio = bars[-1].volume / snap.avg_volume20
    if n < 200:
        snap.notes.append(f"{n} bars: SMA200 unavailable" if n < 200 else "")
    return snap
