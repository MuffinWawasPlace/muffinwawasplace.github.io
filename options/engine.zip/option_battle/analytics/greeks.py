"""Modular option pricing + Greeks.

* `BlackScholes` (European, continuous dividend yield) is the default model. Its price/delta/IV primitives are
  reused from the preserved legacy script; gamma/theta/vega/rho are added here.
* `CRRBinomial` is a Cox-Ross-Rubinstein American-exercise tree. US equity/ETF options are American-style, so
  this model quantifies the early-exercise premium that Black-Scholes ignores. It is slower, so it is used for
  the selected-trade debugger and sanity checks, not for scanning the whole chain.

Add a model by subclassing `PricingModel` and registering it in `MODELS`.

Units (documented because feeds differ):
  theta: per calendar day, per share        vega: per 1 volatility point (0.01), per share
  rho:   per 1 percentage point of rate     gamma: per $1 move in the underlying, per share
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from option_battle.legacy.options_suggester import bs_d1_d2, bs_delta, bs_price, implied_vol, norm_cdf  # noqa: F401

SQRT_2PI = math.sqrt(2.0 * math.pi)


def norm_pdf(x: float) -> float:
    return math.exp(-0.5 * x * x) / SQRT_2PI


@dataclass
class Greeks:
    price: float
    delta: float
    gamma: float
    theta: float
    vega: float
    rho: float = 0.0
    model: str = "black_scholes"

    def as_dict(self) -> dict:
        return {k: getattr(self, k) for k in ("price", "delta", "gamma", "theta", "vega", "rho", "model")}


class PricingModel:
    name = "base"

    def price(self, right: str, S: float, K: float, t: float, r: float, q: float, sigma: float) -> float:
        raise NotImplementedError

    def greeks(self, right: str, S: float, K: float, t: float, r: float, q: float, sigma: float) -> Greeks:
        raise NotImplementedError


class BlackScholes(PricingModel):
    name = "black_scholes"

    def price(self, right, S, K, t, r, q, sigma):
        return bs_price(right, S, K, t, r, q, sigma)

    def greeks(self, right, S, K, t, r, q, sigma) -> Greeks:
        if S <= 0 or K <= 0:
            return Greeks(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, self.name)
        if t <= 0 or sigma <= 0:  # expiry / degenerate: intrinsic payoff, delta is a step function
            px = bs_price(right, S, K, max(t, 0.0), r, q, sigma)
            return Greeks(px, bs_delta(right, S, K, t, r, q, sigma), 0.0, 0.0, 0.0, 0.0, self.name)
        d1, d2 = bs_d1_d2(S, K, t, r, q, sigma)
        sq = math.sqrt(t)
        dq, dr = math.exp(-q * t), math.exp(-r * t)
        pdf = norm_pdf(d1)
        gamma = dq * pdf / (S * sigma * sq)
        vega = S * dq * pdf * sq / 100.0
        if right == "C":
            theta_y = (-S * dq * pdf * sigma / (2 * sq) - r * K * dr * norm_cdf(d2) + q * S * dq * norm_cdf(d1))
            rho = K * t * dr * norm_cdf(d2) / 100.0
        else:
            theta_y = (-S * dq * pdf * sigma / (2 * sq) + r * K * dr * norm_cdf(-d2) - q * S * dq * norm_cdf(-d1))
            rho = -K * t * dr * norm_cdf(-d2) / 100.0
        return Greeks(self.price(right, S, K, t, r, q, sigma), bs_delta(right, S, K, t, r, q, sigma),
                      gamma, theta_y / 365.0, vega, rho, self.name)


class CRRBinomial(PricingModel):
    """American-exercise CRR tree (continuous dividend yield). Greeks via bump-and-reprice."""
    name = "crr_american"

    def __init__(self, steps: int = 120) -> None:
        self.steps = max(20, int(steps))

    def price(self, right, S, K, t, r, q, sigma):
        if t <= 0 or sigma <= 0:
            return max(0.0, S - K) if right == "C" else max(0.0, K - S)
        n = self.steps
        dt_ = t / n
        u = math.exp(sigma * math.sqrt(dt_))
        d = 1.0 / u
        disc = math.exp(-r * dt_)
        p = (math.exp((r - q) * dt_) - d) / (u - d)
        p = min(1.0, max(0.0, p))
        sign = 1.0 if right == "C" else -1.0
        vals = [max(0.0, sign * (S * (u ** (2 * j - n)) - K)) for j in range(n + 1)]
        for i in range(n - 1, -1, -1):
            nxt = []
            for j in range(i + 1):
                cont = disc * (p * vals[j + 1] + (1.0 - p) * vals[j])
                ex = max(0.0, sign * (S * (u ** (2 * j - i)) - K))
                nxt.append(cont if cont > ex else ex)
            vals = nxt
        return vals[0]

    def greeks(self, right, S, K, t, r, q, sigma) -> Greeks:
        base = self.price(right, S, K, t, r, q, sigma)
        h = max(0.005 * S, 0.01)
        up, dn = self.price(right, S + h, K, t, r, q, sigma), self.price(right, S - h, K, t, r, q, sigma)
        delta = (up - dn) / (2 * h)
        gamma = (up - 2 * base + dn) / (h * h)
        dv = 0.01
        vega = (self.price(right, S, K, t, r, q, sigma + dv) - self.price(right, S, K, t, r, q, max(1e-4, sigma - dv))) / 2.0
        dday = 1.0 / 365.0
        theta = self.price(right, S, K, max(t - dday, 1e-6), r, q, sigma) - base
        return Greeks(base, delta, gamma, theta, vega, 0.0, self.name)


MODELS: dict[str, PricingModel] = {"black_scholes": BlackScholes(), "crr_american": CRRBinomial()}


def get_model(name: str) -> PricingModel:
    return MODELS.get(name, MODELS["black_scholes"])


def solve_iv(right: str, price: float, S: float, K: float, t: float, r: float, q: float) -> Optional[float]:
    """Black-Scholes-implied volatility from a price (bisection, from the legacy implementation).
    Returns None when the price lies outside the no-arbitrage band for any sigma in [1e-4, 5]."""
    if not (price > 0 and S > 0 and K > 0 and t > 0):
        return None
    return implied_vol(right, price, S, K, t, r, q)


def early_exercise_premium(right: str, S: float, K: float, t: float, r: float, q: float, sigma: float,
                           steps: int = 160) -> float:
    """American (CRR) minus European (BS) value per share. >= 0 up to tree discretization error."""
    return CRRBinomial(steps).price(right, S, K, t, r, q, sigma) - bs_price(right, S, K, t, r, q, sigma)


def prob_itm(right: str, S: float, K: float, t: float, r: float, q: float, sigma: float) -> float:
    """Risk-neutral P(finish ITM) = N(d2) for calls, N(-d2) for puts. A model estimate, not a forecast."""
    if t <= 0 or sigma <= 0:
        return 1.0 if ((S > K) if right == "C" else (S < K)) else 0.0
    _, d2 = bs_d1_d2(S, K, t, r, q, sigma)
    return norm_cdf(d2) if right == "C" else norm_cdf(-d2)
