"""Order timing + limit-order zone + ENTER / WAIT / AVOID.

Nothing here invents a price. Every number is one of:
  observed    bid / ask / sizes from the chain
  calculated  mid, natural, microprice, and the SCORE-IMPLIED LIMITS: the trade is re-scored at hypothetical fill
              prices (bisection) to find the worst fill at which it still clears the ENTER threshold
  estimated   "wait" targets: the delta-gamma estimate of the premium if the underlying reaches a named level

There is no single mathematically perfect limit. The engine reports a zone and the reasoning for each edge.
"""
from __future__ import annotations

import dataclasses
import math
from typing import Optional

from option_battle.analytics.payoff import payoff_facts
from option_battle.core.util import clamp, lin
from option_battle.strategies.base import META


# ----------------------------------------------------------------------------- timing

def trade_bias(trade) -> int:
    b = META[trade.strategy].bias
    return 1 if b > 0.05 else -1 if b < -0.05 else 0


def timing_assessment(trade, m, ctx) -> dict:
    """0..1 'is now a sensible moment' factor from price location only (no prediction).
    Neutral = 0.70. Penalties: stretched in the trade's direction (chasing / premium already compressed),
    a level just ahead in the trade's direction. Bonus: short premium sold INTO a counter-move (premium inflated)."""
    tech = ctx.tech
    notes: list = []
    flags: list = []
    if not tech.atr14:
        return {"factor": 0.6, "notes": ["no ATR (short history): timing neutral-low"], "flags": ["timing_unavailable"]}
    bias = trade_bias(trade)
    fam = META[trade.strategy].family
    z = tech.z20 or 0.0
    f = 0.70
    if fam in ("short", "credit_spread"):
        # Short premium: what matters is the price of the leg being SOLD. Put premium swells after a drop and
        # shrinks after a rally; call premium does the opposite.
        side = 1 if trade.primary_leg.contract.right == "C" else -1
        s = z * side                            # >0 = price has moved toward the short strike (premium inflated)
        if s > 0.8:
            bon = 0.20 * lin(s, 0.8, 2.5)
            f += bon
            notes.append(f"selling {'calls into a' if side > 0 else 'puts into a'} {abs(z):.1f} ATR "
                         f"{'rally' if side > 0 else 'drop'}: premium on this side is inflated (+{bon:.2f})")
        elif s < -1.0:
            pen = 0.35 * lin(-s, 1.0, 3.0)
            f -= pen
            notes.append(f"{'call' if side > 0 else 'put'} premium compressed after a {abs(z):.1f} ATR move away "
                         f"from the strike (-{pen:.2f})")
            flags.append("premium_compressed")
    elif fam == "hedge":
        # Protection (long puts) is cheaper after a rally and dearer after a drop; never "chasing".
        if z > 1.0:
            bon = 0.15 * lin(z, 1.0, 3.0)
            f += bon
            notes.append(f"buying protection after a {z:.1f} ATR rally: puts are relatively cheap (+{bon:.2f})")
        elif z < -1.0:
            pen = 0.20 * lin(-z, 1.0, 3.0)
            f -= pen
            notes.append(f"buying protection after a {abs(z):.1f} ATR drop: put premium is already inflated (-{pen:.2f})")
    elif bias:
        stretch = z * bias                      # >0 = stretched in the trade's favoured direction (chasing)
        if stretch > 1.0:
            pen = 0.45 * lin(stretch, 1.0, 3.0)
            f -= pen
            notes.append(f"price {z:+.1f} ATR from SMA20 in the trade's direction (stretched, -{pen:.2f})")
            flags.append("extended")
        lv = ctx.levels
        if lv.available:
            nxt = (lv.resistances[0] if bias > 0 and lv.resistances else lv.supports[0] if bias < 0 and lv.supports else None)
            if nxt is not None and nxt.distance_atr is not None and abs(nxt.distance_atr) < 0.6:
                pen = 0.25 * (1.0 - abs(nxt.distance_atr) / 0.6)
                f -= pen
                notes.append(f"{'resistance' if bias > 0 else 'support'} {nxt.price:.2f} only {abs(nxt.distance_atr):.2f} ATR "
                             f"ahead (-{pen:.2f})")
                flags.append("level_ahead")
    if ctx.regime.label == "Breakout" and bias > 0 and fam in ("long", "debit_spread"):
        conf = next((t for t in ctx.regime.rule_trace if t.get("rule") == "breakout/breakdown"), {})
        if not conf.get("confirmed"):
            f -= 0.15
            notes.append("breakout not confirmed by range/volume (-0.15)")
            flags.append("unconfirmed")
    return {"factor": clamp(f), "notes": notes, "flags": flags}


# ----------------------------------------------------------------------------- hypothetical fills

def with_price(trade, price: float):
    """Hypothetical fill at `price`. Natural/best move with it so the observed spread cost (an entry-quality input)
    stays constant: only the economics of the fill change, which keeps the score monotonic in price."""
    facts = payoff_facts(trade.legs, trade.stock_units, trade.spot, price)
    shift = price - trade.price_mid
    return dataclasses.replace(trade, price_mid=price, price_natural=trade.price_natural + shift,
                               price_best=trade.price_best + shift, max_gain=facts["max_gain"],
                               max_loss=facts["max_loss"], breakevens=facts["breakevens"])


def rescore_at(trade, ctx, price: float, weights: dict, timing: dict) -> float:
    from option_battle.analytics.scoring import score_trade
    from option_battle.analytics.trade_metrics import compute_metrics
    t2 = with_price(trade, price)
    m2 = compute_metrics(t2, ctx)
    s2 = score_trade(t2, m2, ctx, weights, timing)
    return s2.total


def _round(x: float, tick: float, up: bool) -> float:
    n = x / tick
    n = math.ceil(n - 1e-9) if up else math.floor(n + 1e-9)
    return round(n * tick, 4)


def limit_zone(trade, score_total: float, ctx, weights: dict, timing: dict, threshold: Optional[float] = None) -> dict:
    """Per-share prices (positive numbers: credit to receive or debit to pay)."""
    cfg = ctx.cfg
    tick = cfg.tick
    thr = cfg.enter_threshold if threshold is None else threshold
    credit = trade.price_mid < 0
    sgn = -1.0 if credit else 1.0
    mid, nat, best = sgn * trade.price_mid, sgn * trade.price_natural, sgn * trade.price_best   # may go <= 0 on wide quotes
    half = abs(nat - mid)
    out = {"side": "CREDIT" if credit else "DEBIT", "mid": mid, "natural": nat, "best": best, "tick": tick,
           "threshold": thr, "kinds": {"mid/natural/best": "observed/calculated", "limits": "calculated (re-scored)",
                                       "wait_target": "estimated (delta-gamma)"}}
    micro = None
    if len(trade.legs) == 1:
        c = trade.legs[0].contract
        if c.bid_size > 0 and c.ask_size > 0 and c.ask > c.bid > 0:
            micro = (c.bid * c.ask_size + c.ask * c.bid_size) / (c.bid_size + c.ask_size)
    out["microprice"] = micro
    spread_pct = (nat - mid) * 2 / mid if mid > 0 else 1.0
    k = 0.0 if spread_pct <= 0.03 else 0.25 if spread_pct <= 0.10 else 0.40
    pref = mid + k * half if credit else mid - k * half
    pref = _round(pref, tick, up=credit)
    out["patience_k"] = k
    out["preferred_note"] = (f"mid {'+' if credit else '-'} {k:.2f} x half-spread: "
                             + ("tight market, work at the mid" if k == 0 else
                                "start inside the spread on the favourable side, then walk toward the mid"))

    # score-implied worst acceptable fill (bisection on the price in the unfavourable direction)
    def score_at(px: float) -> float:
        return rescore_at(trade, ctx, sgn * px, weights, timing)

    lo_bound = max(tick, (nat - (best - nat)) if credit else best)    # credit: search below natural by one spread
    hi_bound = best if credit else nat + (nat - best)                 # debit: search above natural by one spread
    worst = None
    try:
        if credit:
            if score_at(hi_bound) >= thr:
                a, b = lo_bound, hi_bound
                if score_at(a) >= thr:
                    worst = a
                else:
                    for _ in range(14):
                        mmid = 0.5 * (a + b)
                        if score_at(mmid) >= thr:
                            b = mmid
                        else:
                            a = mmid
                    worst = _round(b, tick, up=True)
        else:
            if score_at(max(tick, lo_bound)) >= thr:
                a, b = max(tick, lo_bound), hi_bound
                if score_at(b) >= thr:
                    worst = b
                else:
                    for _ in range(14):
                        mmid = 0.5 * (a + b)
                        if score_at(mmid) >= thr:
                            a = mmid
                        else:
                            b = mmid
                    worst = _round(a, tick, up=False)
    except Exception as exc:   # never let the zone search break an analysis
        out["search_error"] = str(exc)
    worst = round(worst, 4) if worst is not None else None
    out["worst_acceptable"] = worst
    if credit:
        out["label_worst"] = "minimum acceptable credit"
        if worst is None:
            out["acceptable"] = None
            out["worst_note"] = (f"even at the ask-side credit ${best:.2f} the trade stays below the ENTER threshold "
                                 f"{thr:.0f}: no acceptable fill in the current market")
        else:
            out["acceptable"] = [round(max(worst, nat), 4), round(best, 4)] if worst <= best + 1e-9 else None
            out["worst_note"] = (f"re-scoring at lower credits: below ${worst:.2f} the score falls under {thr:.0f}"
                                 + (" (at or below the natural bid: any fill qualifies)" if worst <= nat + 1e-9 else ""))
        out["preferred"] = max(pref, worst or 0.0)
    else:
        out["label_worst"] = "maximum acceptable debit"
        if worst is None:
            out["acceptable"] = None
            out["worst_note"] = (f"even at the bid-side debit ${best:.2f} the trade stays below the ENTER threshold "
                                 f"{thr:.0f}: no acceptable fill in the current market")
        else:
            out["acceptable"] = [round(best, 4), round(min(worst, nat), 4)] if worst >= best - 1e-9 else None
            out["worst_note"] = (f"re-scoring at higher debits: above ${worst:.2f} the score falls under {thr:.0f}"
                                 + (" (at or above the natural ask: any fill qualifies)" if worst >= nat - 1e-9 else ""))
        out["preferred"] = min(pref, worst) if worst is not None else pref
    out["preferred"] = round(out["preferred"], 4)
    out["at_preferred_score"] = round(score_at(out["preferred"]), 1)
    out["at_natural_score"] = round(score_at(nat), 1)
    return out


def premium_if(trade, target_spot: float) -> float:
    """Delta-gamma estimate of the OPTIONS' net per-share price if spot moves to target (stock excluded)."""
    dS = target_spot - trade.spot
    d = trade.delta - trade.stock_units
    est = trade.price_mid + d * dS + 0.5 * trade.gamma * dS * dS
    return est


# ----------------------------------------------------------------------------- thesis / invalidation

def invalidation(trade, ctx) -> dict:
    bias = trade_bias(trade)
    fam = META[trade.strategy].family
    lv = ctx.levels
    tech = ctx.tech
    p = trade.primary_leg.contract
    if fam == "hedge":
        return {"text": "Hedge: no directional thesis to invalidate; review if the shares are sold or the risk you are "
                        "hedging is gone.", "level": None, "kind": "inferred"}
    atr = tech.atr14 or 0.0

    def meaningful(levels: list):
        """First level at least 0.5 ATR from spot: a level sitting on top of the price is noise, not a thesis line."""
        for x in levels:
            if x.distance_atr is None or abs(x.distance_atr) >= 0.5:
                return x
        return levels[-1] if levels else None

    if bias > 0 or (fam == "credit_spread" and p.right == "P"):
        s_lv = meaningful(lv.supports) if lv.available else None
        lvl = s_lv.price if s_lv else tech.sma50
        src = (f"support, {abs(s_lv.distance_atr or 0):.1f} ATR below" if s_lv else "SMA50")
        if lvl is None:
            return {"text": "unavailable (no support level or SMA50)", "level": None, "kind": "unavailable"}
        return {"text": f"{trade.underlying} daily close below ${lvl:.2f} ({src})", "level": lvl, "direction": "below",
                "kind": "inferred", "source": src}
    r_lv = meaningful(lv.resistances) if lv.available else None
    lvl = r_lv.price if r_lv else tech.sma50
    src = (f"resistance, {abs(r_lv.distance_atr or 0):.1f} ATR above" if r_lv else "SMA50")
    if lvl is None:
        return {"text": "unavailable (no resistance level or SMA50)", "level": None, "kind": "unavailable"}
    return {"text": f"{trade.underlying} daily close above ${lvl:.2f} ({src})", "level": lvl, "direction": "above",
            "kind": "inferred", "source": src}


# ----------------------------------------------------------------------------- decision

def _check(name: str, status: str, detail: str) -> dict:
    return {"name": name, "status": status, "detail": detail}


def decide(trade, m, score, ctx, peers: dict, liquidity_floor: float = 0.25) -> dict:
    """ENTER / WAIT / AVOID with every check listed. `peers`: {'same_exp_best': (score, label, id),
    'other_exp_best': (score, label, id)} for the same strategy."""
    cfg = ctx.cfg
    fam = META[trade.strategy].family
    vega = META[trade.strategy].vega_sign
    checks = []
    avoid, wait = [], []
    if score.disqualified:
        avoid.append("fails hard quality gates: " + "; ".join(score.gates[:3]))
        checks.append(_check("quality gates", "fail", "; ".join(score.gates)))
    else:
        checks.append(_check("quality gates", "pass", "all legs tradeable"))
    s = score.total
    if s < cfg.avoid_threshold:
        avoid.append(f"Trade Quality {s:.0f} < {cfg.avoid_threshold:.0f}")
        checks.append(_check("score", "fail", f"{s:.1f} below AVOID line {cfg.avoid_threshold:.0f}"))
    elif s < cfg.enter_threshold:
        wait.append(f"Trade Quality {s:.0f} below the ENTER line {cfg.enter_threshold:.0f}")
        checks.append(_check("score", "warn", f"{s:.1f} between {cfg.avoid_threshold:.0f} and {cfg.enter_threshold:.0f}"))
    else:
        checks.append(_check("score", "pass", f"{s:.1f} >= {cfg.enter_threshold:.0f}"))
    liq = m.liquidity["score"]
    if liq < liquidity_floor:
        avoid.append(f"liquidity poor ({liq:.2f})")
        checks.append(_check("liquidity", "fail", f"liquidity score {liq:.2f} < {liquidity_floor:.2f}"))
    elif max(l.contract.spread_pct for l in trade.legs) > cfg.wide_spread_pct:
        w = max(l.contract.spread_pct for l in trade.legs)
        wait.append(f"spread too wide ({w * 100:.0f}% of mid on the widest leg)")
        checks.append(_check("spread", "warn", f"widest leg {w * 100:.1f}% > {cfg.wide_spread_pct * 100:.0f}%"))
    else:
        checks.append(_check("spread", "pass", f"liquidity {liq:.2f}"))
    rf = score.regime_fit_detail["factor"]
    if rf < 0.30:
        avoid.append(f"poor regime fit ({rf:.2f}) for {ctx.regime.label}")
        checks.append(_check("regime fit", "fail", f"{rf:.2f} < 0.30"))
    elif ctx.regime.confidence < cfg.low_regime_confidence:
        wait.append(f"regime unclear (confidence {ctx.regime.confidence:.0%})")
        checks.append(_check("regime clarity", "warn", f"confidence {ctx.regime.confidence:.2f} < {cfg.low_regime_confidence:.2f}"))
    else:
        checks.append(_check("regime fit", "pass", f"{rf:.2f} in {ctx.regime.label}"))
    V = ctx.posture.V
    if ctx.ivr.get("available"):
        if vega < 0 and V <= -0.2 and META[trade.strategy].vol_weight >= 0.4:
            wait.append(f"IV too low for selling premium (IV regime {ctx.ivr['level']})")
            checks.append(_check("IV level", "warn", f"short vega with V {V:+.2f}"))
        elif vega > 0 and V >= 0.6 and META[trade.strategy].vol_weight >= 0.4:
            wait.append(f"IV too high for buying premium (IV regime {ctx.ivr['level']})")
            checks.append(_check("IV level", "warn", f"long vega with V {V:+.2f}"))
        else:
            checks.append(_check("IV level", "pass", f"IV regime {ctx.ivr['level']} (V {V:+.2f})"))
    else:
        checks.append(_check("IV level", "warn", "IV vs realized unavailable"))
    tm = timing_assessment(trade, m, ctx)
    if "extended" in tm["flags"]:
        wait.append("price too extended in the trade's direction")
    if "premium_compressed" in tm["flags"]:
        wait.append("premium currently unattractive (sold side compressed by the recent move)")
    if "level_ahead" in tm["flags"]:
        wait.append("underlying approaching " + ("resistance" if trade_bias(trade) > 0 else "support"))
    if "unconfirmed" in tm["flags"]:
        wait.append("technical setup not confirmed")
    checks.append(_check("timing", "warn" if tm["flags"] else "pass", "; ".join(tm["notes"]) or "no timing flags"))
    # events
    soon = [e for e in m.events_inside if e.get("risk") == "HIGH" and e.get("days_away", 99) <= 2]
    if soon and trade.dte <= 14:
        nm = soon[0]["name"]
        if fam in ("short", "credit_spread") and trade.dte <= 7 and soon[0].get("days_away", 9) <= 1:
            avoid.append(f"{nm} within a day inside a {trade.dte}-DTE short-premium trade")
            checks.append(_check("event", "fail", f"{nm} on {soon[0]['date']}"))
        else:
            wait.append(f"major event approaching ({nm} {soon[0]['date']})")
            checks.append(_check("event", "warn", f"{nm} on {soon[0]['date']} inside a {trade.dte}-DTE trade"))
    elif m.events_inside:
        checks.append(_check("event", "warn" if any(e.get('risk') == 'HIGH' for e in m.events_inside) else "pass",
                             f"{len(m.events_inside)} scheduled event(s) before expiration (penalised in score)"))
    else:
        checks.append(_check("event", "pass", "no scheduled event before expiration (earnings/ex-div not covered)"))
    # expected move vs strike
    if fam in ("short", "credit_spread") and m.em_ratio is not None and m.em_ratio < 0.75:
        wait.append(f"expected move does not justify the strike ({m.em_ratio:.2f}x EM)")
    # peers
    se = peers.get("same_exp_best")
    oe = peers.get("other_exp_best")
    if se and se[2] != trade.id and se[0] - s > cfg.better_peer_margin:
        wait.append(f"better strike available ({se[1]}, {se[0]:.0f})")
        checks.append(_check("better strike", "warn", f"{se[1]} scores {se[0]:.1f} (+{se[0] - s:.1f})"))
    if oe and oe[2] != trade.id and oe[0] - s > cfg.better_peer_margin:
        wait.append(f"better expiration available ({oe[1]}, {oe[0]:.0f})")
        checks.append(_check("better expiration", "warn", f"{oe[1]} scores {oe[0]:.1f} (+{oe[0] - s:.1f})"))
    fresh = ctx.freshness or {}
    if fresh.get("stale"):
        wait.append("quotes are stale")
        checks.append(_check("freshness", "warn", fresh.get("note", "")))
    elif not ctx.is_mock and fresh.get("market_session") == "closed":
        checks.append(_check("freshness", "warn", "market closed: re-check live quotes at the open"))
        if cfg.closed_market_wait:
            wait.append("market closed")
    status = "AVOID" if avoid else "WAIT" if wait else "ENTER"
    return {"status": status, "avoid_reasons": avoid, "wait_reasons": wait, "checks": checks, "timing": tm}


def wait_condition(trade, ctx, decision: dict, zone: Optional[dict]) -> str:
    """Concrete, derived condition for WAIT; empty for ENTER/AVOID."""
    if decision["status"] != "WAIT":
        return ""
    parts = []
    tech = ctx.tech
    bias = trade_bias(trade)
    fam = META[trade.strategy].family
    if zone and zone.get("worst_acceptable") is None:
        parts.append("current market offers no fill that clears the ENTER threshold")
    if zone and zone.get("worst_acceptable") is not None and zone.get("side") == "CREDIT":
        parts.append(f"credit at or above ${zone['worst_acceptable']:.2f}")
    elif zone and zone.get("worst_acceptable") is not None:
        parts.append(f"debit at or below ${zone['worst_acceptable']:.2f}")
    if fam != "hedge" and any(("extended" in r or "premium currently" in r) for r in decision["wait_reasons"]) and tech.sma20:
        tgt = tech.sma20 + (tech.atr14 or 0) * (0.5 if bias > 0 else -0.5)
        est = abs(premium_if(trade, tgt))
        parts.append(f"a reversion toward {trade.underlying} ${tgt:.2f} (SMA20 +/- 0.5 ATR), where this structure would be "
                     f"~${est:.2f}/sh (delta-gamma estimate)")
    for r in decision["wait_reasons"]:
        if r.startswith("major event"):
            parts.append("the event has passed")
        if r.startswith("better"):
            parts.append("or switch to the " + r.split("(")[0].replace("available", "").strip())
        if r.startswith("IV too low"):
            parts.append("IV/realized ratio back above ~1.0")
        if r.startswith("IV too high"):
            parts.append("IV/realized ratio back below ~1.3")
    return "Wait for: " + "; ".join(dict.fromkeys(parts)) if parts else "Wait for the listed conditions to clear."
