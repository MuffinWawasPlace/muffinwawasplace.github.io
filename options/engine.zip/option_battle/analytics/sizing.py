"""Position sizing table: how 1..N contracts change exposure against configurable limits.

The table never recommends a size. It reports, per contract count, the exposure created and which limits are
breached, plus the largest count inside EVERY limit. Buying power alone never determines that number.
"""
from __future__ import annotations

from typing import Optional

from option_battle.legacy.options_suggester import BROAD_GROUPS, exposure_key
from option_battle.strategies.base import META


def per_unit_risk(trade, m) -> tuple:
    """(dollars at risk per contract, basis text)."""
    if m.max_loss_usd is not None:
        return m.max_loss_usd, "maximum theoretical loss (exact expiry payoff)"
    if m.loss_realistic_usd is not None:
        return m.loss_realistic_usd, "UNBOUNDED max loss: using the 2-expected-move adverse loss (estimate)"
    return m.capital_usd, "capital basis (max loss unavailable)"


def sizing_table(trade, m, ctx, st: Optional[dict]) -> dict:
    cfg = ctx.cfg
    lim = cfg.limits
    S = trade.spot
    risk_u, basis = per_unit_risk(trade, m)
    meta = META[trade.strategy]
    collateral_u = m.risk.get("collateral", {}).get("amount_usd", 0.0) if m.risk else 0.0
    from option_battle.analytics.portfolio_fit import trade_requirements
    owned = bool(meta.owns_shares and st is not None and trade_requirements(trade, st).get("ok"))
    delta_u = (m.net_delta_shares - (100.0 if owned else 0.0)) * S       # owned shares are already in the portfolio
    vega_u, theta_u = m.net_vega_usd, m.net_theta_usd
    rows = []
    eq = st["equity"] if st else None
    g, lev = exposure_key(trade.underlying)
    broad = g in BROAD_GROUPS
    lim_conc = lim.max_underlying_conc_broad if broad else lim.max_underlying_conc_other
    gcur = st["groups"].get(g, {}).get("delta_usd", 0.0) if st else 0.0
    ek = trade.expiration.isoformat()
    ecur = st["exp_risk"].get(ek, 0.0) if st else 0.0
    dcur = st["totals"]["delta_usd"] if st else 0.0
    vcur = st["totals"]["vega_usd"] if st else 0.0
    units_avail = None
    if st and (meta.owns_shares or meta.needs_cash):
        u = st["by_underlying"].get(trade.underlying, {})
        if meta.owns_shares:
            units_avail = u.get("free_lots", 0) if trade.strategy in ("covered_call", "collar") else int(u.get("shares", 0) // 100)
        else:
            need = trade.primary_leg.contract.strike * 100.0 - trade.credit_mid * 100.0
            units_avail = int(st["free_cash"] // need) if need > 0 else 0
    last_ok = 0
    for n in range(1, max(1, lim.max_contracts_table) + 1):
        r = {"contracts": n, "risk_usd": n * risk_u, "collateral_usd": n * collateral_u, "delta_usd": n * delta_u,
             "vega_usd": n * vega_u, "theta_usd": n * theta_u, "premium_usd": n * (m.credit_mid_usd or -m.debit_mid_usd),
             "breaches": []}
        if eq and eq > 0:
            r["risk_pct"] = r["risk_usd"] / eq
            r["conc_after"] = abs(gcur + n * delta_u * lev) / eq
            r["exp_after"] = (ecur + n * risk_u) / eq
            r["delta_after"] = abs(dcur + n * delta_u) / eq
            r["vega_after_pct"] = abs(vcur + n * vega_u) / eq
            cap = lim.max_trade_risk_pct * eq
            if lim.max_trade_risk_usd > 0:
                cap = min(cap, lim.max_trade_risk_usd)
            if r["risk_usd"] > cap:
                r["breaches"].append(f"trade risk ${r['risk_usd']:,.0f} > ${cap:,.0f}")
            if r["conc_after"] > lim_conc and r["conc_after"] > abs(gcur) / eq + 1e-9:
                r["breaches"].append(f"{g} concentration {r['conc_after']:.0%} > {lim_conc:.0%}")
            if r["exp_after"] > lim.max_expiration_conc:
                r["breaches"].append(f"{ek} expiration risk {r['exp_after']:.0%} > {lim.max_expiration_conc:.0%}")
            if r["delta_after"] > lim.max_portfolio_delta_pct and r["delta_after"] > abs(dcur) / eq + 1e-9:
                r["breaches"].append(f"portfolio delta {r['delta_after']:.0%} > {lim.max_portfolio_delta_pct:.0%}")
            if r["vega_after_pct"] > lim.max_portfolio_vega_pct and r["vega_after_pct"] > abs(vcur) / eq + 1e-9:
                r["breaches"].append(f"portfolio vega ${abs(vcur + n * vega_u):,.0f}/pt > "
                                     f"${lim.max_portfolio_vega_pct * eq:,.0f}/pt")
        elif lim.max_trade_risk_usd > 0 and r["risk_usd"] > lim.max_trade_risk_usd:
            r["breaches"].append(f"trade risk ${r['risk_usd']:,.0f} > ${lim.max_trade_risk_usd:,.0f}")
        if units_avail is not None and n > units_avail:
            r["breaches"].append("exceeds available " + ("shares" if meta.owns_shares else "cash"))
        if not r["breaches"] and last_ok == n - 1:
            last_ok = n
        rows.append(r)
    note = ("Largest count inside every configured limit. This is a ceiling for review, NOT a recommended size.")
    if not st:
        note = ("No portfolio entered: percentages and portfolio limits cannot be evaluated; only per-contract exposure "
                "is shown." + (" Absolute risk cap applied." if lim.max_trade_risk_usd > 0 else ""))
    return {"risk_basis": basis, "per_unit": {"risk_usd": risk_u, "collateral_usd": collateral_u, "delta_usd": delta_u,
                                              "vega_usd": vega_u, "theta_usd": theta_u},
            "rows": rows, "max_within_limits": last_ok if st or lim.max_trade_risk_usd > 0 else None,
            "units_available": units_avail, "note": note,
            "limits": {"max_trade_risk_pct": lim.max_trade_risk_pct, "max_trade_risk_usd": lim.max_trade_risk_usd,
                       "max_underlying_conc": lim_conc, "max_expiration_conc": lim.max_expiration_conc,
                       "max_portfolio_delta_pct": lim.max_portfolio_delta_pct,
                       "max_portfolio_vega_pct": lim.max_portfolio_vega_pct}}
