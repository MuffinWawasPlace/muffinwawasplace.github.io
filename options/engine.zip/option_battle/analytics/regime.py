"""Market regime engine.

Multi-timeframe, deterministic, fully explained. Timeframes available from the preserved CBOE/Yahoo/Stooq history
endpoints are DAILY bars only, so the engine reports:

    DAILY       - the preserved legacy points-based trend score (SMA stack, RSI, 20d/60d return)
    WEEKLY      - resampled from the same daily bars (needs ~35 weeks)
    SHORT-TERM  - last 5-10 sessions (momentum measured in ATR units)
    INTRADAY    - 4H / 1H are reported as UNAVAILABLE (no intraday endpoint exists in the project)

Anti-noise rule: SHORT-TERM carries 15% of the directional lean and can never relabel an intact higher-timeframe
structure as a reversal. A short-term counter-move inside an intact daily+weekly trend is classified as a
Pullback/Rally, and the override check records exactly why.

Confidence is an agreement-based index (0-1) built from visible components. It is NOT a probability of being right.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Optional

from option_battle.analytics.technicals import TechnicalSnapshot, compute_snapshot, sma, weekly_bars, closes_of
from option_battle.core.util import clamp
from option_battle.legacy.options_suggester import compute_regime as legacy_compute_regime

REGIMES = ["Bull Trend", "Bear Trend", "Sideways / Range", "Bullish Pullback", "Bearish Rally", "Breakout",
           "Breakdown", "High-Volatility Expansion", "Low-Volatility Compression", "Mean Reversion",
           "Event Risk", "Overextended Trend"]


@dataclass
class TimeframeView:
    name: str
    label: str
    score: Optional[float]
    norm: Optional[float]            # -1..1 directional lean, None if unavailable
    available: bool = True
    detail: str = ""


@dataclass
class RegimeResult:
    label: str
    confidence: float
    direction: str                   # bullish | bearish | neutral
    lean: float                      # -1..1 blended directional lean
    timeframes: dict = field(default_factory=dict)
    volatility: dict = field(default_factory=dict)
    features: dict = field(default_factory=dict)
    components: list = field(default_factory=list)          # legacy daily points table
    confidence_components: list = field(default_factory=list)
    reasons: list = field(default_factory=list)
    override_notes: list = field(default_factory=list)
    rule_trace: list = field(default_factory=list)          # every rule evaluated, in order, with result
    overlays: list = field(default_factory=list)            # e.g. event-risk overlay
    indicators: dict = field(default_factory=dict)
    available: bool = True
    notes: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return {**self.__dict__, "timeframes": {k: v.__dict__ for k, v in self.timeframes.items()}}


def _weekly_view(bars: list, px: float) -> TimeframeView:
    wb = weekly_bars(bars)
    c = closes_of(wb)
    if len(c) < 35:
        return TimeframeView("weekly", "Unavailable", None, None, False, f"{len(c)} weekly bars (<35)")
    s10, s30 = sma(c, 10), sma(c, 30)
    s10_prev = sma(c[:-4], 10)
    r13 = c[-1] / c[-14] - 1.0 if len(c) >= 14 else None
    pts = 0.0
    parts = []
    pts += 1.0 if px > s10 else -1.0
    parts.append(f"px {'>' if px > s10 else '<'} 10w SMA")
    pts += 1.5 if px > s30 else -1.5
    parts.append(f"px {'>' if px > s30 else '<'} 30w SMA")
    pts += 1.0 if s10 > s30 else -1.0
    parts.append(f"10w {'>' if s10 > s30 else '<'} 30w")
    if s10_prev:
        pts += 0.5 if s10 > s10_prev else -0.5
    if r13 is not None:
        pts += 1.5 if r13 > 0.05 else 0.5 if r13 > 0.01 else -1.5 if r13 < -0.05 else -0.5 if r13 < -0.01 else 0.0
        parts.append(f"13w ret {r13 * 100:+.1f}%")
    label = "Bullish" if pts >= 2.0 else "Bearish" if pts <= -2.0 else "Neutral"
    return TimeframeView("weekly", label, round(pts, 2), clamp(pts / 4.5, -1.0, 1.0) if True else 0.0, True, "; ".join(parts))


def _short_view(snap: TechnicalSnapshot) -> TimeframeView:
    if snap.atr14_pct is None or snap.ret5 is None or snap.ret10 is None:
        return TimeframeView("short_term", "Unavailable", None, None, False, "need >= 20 bars")
    z5 = snap.ret5 / (snap.atr14_pct * (5 ** 0.5))
    z10 = snap.ret10 / (snap.atr14_pct * (10 ** 0.5))
    side = 0.0
    if snap.sma10:
        side = 0.3 if snap.price > snap.sma10 else -0.3
    raw = 0.6 * z5 + 0.4 * z10 + side
    norm = clamp(raw / 2.0, -1.0, 1.0)
    if norm <= -0.7:
        lab = "Sharp Short-Term Decline"
    elif norm <= -0.25:
        lab = "Short-Term Pullback"
    elif norm >= 0.7:
        lab = "Sharp Short-Term Thrust"
    elif norm >= 0.25:
        lab = "Short-Term Strength"
    else:
        lab = "Short-Term Consolidation"
    return TimeframeView("short_term", lab, round(raw, 2), norm, True,
                         f"5d {snap.ret5 * 100:+.2f}% ({z5:+.2f} ATR-adj), 10d {snap.ret10 * 100:+.2f}% "
                         f"({z10:+.2f}), px {'above' if snap.price > (snap.sma10 or 0) else 'below'} SMA10")


def _vol_view(snap: TechnicalSnapshot) -> dict:
    pct = snap.rv_pctile
    if pct is None:
        level = "UNKNOWN"
    elif pct >= 0.90:
        level = "STRESSED"
    elif pct >= 0.70:
        level = "ELEVATED"
    elif pct <= 0.30:
        level = "CALM"
    else:
        level = "NORMAL"
    expanding = compressing = False
    if snap.rv10 and snap.rv20 and snap.atr_ratio:
        expanding = snap.rv10 > 1.15 * snap.rv20 or snap.atr_ratio > 1.25
        compressing = (snap.rv10 < 0.85 * snap.rv20 and snap.atr_ratio < 0.97) and not expanding
    trend = "expanding" if expanding else "compressing" if compressing else "stable"
    text = {"UNKNOWN": "Unknown"}.get(level, level.title())
    if trend != "stable":
        text += (" and expanding" if expanding else " but compressing" if level in ("ELEVATED", "STRESSED") else " and compressing")
    return {"level": level, "trend": trend, "expanding": expanding, "compressing": compressing, "text": text,
            "rv_pctile": pct, "rv5": snap.rv5, "rv10": snap.rv10, "rv20": snap.rv20, "rv60": snap.rv60,
            "atr_ratio": snap.atr_ratio, "bb_width_pctile": snap.bb_width_pctile}


def classify_regime(bars: list, spot: Optional[float] = None, events: Optional[list] = None,
                    today: Optional[dt.date] = None) -> RegimeResult:
    """Classify the regime using only `bars` (no look-ahead). `events` = list of dicts with 'date' and 'risk'."""
    snap = compute_snapshot(bars, spot)
    px = snap.price
    if len(bars) < 40 or not snap.atr14 or not px:
        return RegimeResult("Sideways / Range", 0.10, "neutral", 0.0, available=False,
                            notes=[f"Insufficient history ({len(bars)} bars, need >= 40): regime defaulted to "
                                   "Sideways / Range with minimal confidence; regime-dependent scores are neutral."],
                            indicators=snap.to_dict(),
                            timeframes={"daily": TimeframeView("daily", "Unavailable", None, None, False),
                                        "weekly": TimeframeView("weekly", "Unavailable", None, None, False),
                                        "short_term": TimeframeView("short_term", "Unavailable", None, None, False),
                                        "intraday": TimeframeView("intraday", "Unavailable", None, None, False,
                                                                  "4H/1H bars are not provided by the configured data endpoints")})
    leg = legacy_compute_regime(bars, spot)
    daily_norm = clamp(leg.score / 8.0, -1.0, 1.0)
    daily_label = {"STRONG_BULLISH": "Strong Bullish", "BULLISH": "Bullish", "NEUTRAL": "Neutral",
                   "BEARISH": "Bearish", "STRONG_BEARISH": "Strong Bearish"}[leg.label]
    daily = TimeframeView("daily", daily_label, leg.score, daily_norm, True,
                          f"legacy trend score {leg.score:+.1f} (range -12..+11.5)")
    weekly = _weekly_view(bars, px)
    short = _short_view(snap)
    intraday = TimeframeView("intraday", "Unavailable", None, None, False,
                             "4H/1H bars are not provided by the configured data endpoints (daily only)")
    # blended lean: HTF-dominant by construction
    w_d, w_w, w_s = 0.55, 0.30, 0.15
    if not weekly.available:
        w_d, w_w, w_s = 0.75, 0.0, 0.25
    lean = w_d * daily_norm + w_w * (weekly.norm or 0.0) + w_s * (short.norm or 0.0)
    lean = clamp(lean, -1.0, 1.0)
    vol = _vol_view(snap)
    reasons: list = []
    overrides: list = []
    trace: list = []

    dscore, wscore = leg.score, (weekly.score if weekly.available else 0.0)
    st = short.norm or 0.0
    # Higher-timeframe STRUCTURE uses only the slow components of the daily score. The fast ones (price vs SMA20,
    # RSI, 20d return) are exactly what a pullback depresses, so letting them define "structure" would make every
    # pullback look like a trend break. The full score is still reported as the DAILY view and still drives `lean`.
    slow = {"Px vs SMA200", "SMA50 vs SMA200", "SMA50 10d slope", "60d return"}
    have200 = snap.sma200 is not None
    if have200:
        sscore = sum(c["points"] for c in leg.components if c["name"] in slow)
        s_thr = 3.0
    else:                                   # < 200 bars: fall back to the full score (documented limitation)
        sscore, s_thr = dscore, 2.5
    # Trend-quality gate. The legacy points score is sign-based (price 0.2% above every average scores the same
    # as 10% above), so in chop it can read "Strong Bullish". A trend label therefore also needs real separation
    # between SMA50 and SMA200 measured in ATR units; otherwise the structure is range-like.
    ma_sep = None
    if snap.sma50 and snap.sma200 and snap.atr14_pct:
        ma_sep = (snap.sma50 / snap.sma200 - 1.0) / snap.atr14_pct
    sep_bull = ma_sep is None or ma_sep >= 2.5
    sep_bear = ma_sep is None or ma_sep <= -2.5
    bull_htf = sscore >= s_thr and (not weekly.available or wscore >= 0.0) and sep_bull
    bear_htf = sscore <= -s_thr and (not weekly.available or wscore <= 0.0) and sep_bear
    trace.append({"rule": "trend_quality_gate", "ma_separation_atr": ma_sep, "needs": "|SMA50/SMA200-1| >= 2.5 ATR%",
                  "structure_score": sscore, "structure_threshold": s_thr, "slow_components": sorted(slow) if have200 else "full score",
                  "daily_score": dscore, "weekly_score": wscore, "bull_htf": bull_htf, "bear_htf": bear_htf})
    sma200 = snap.sma200
    # price on the correct side of the long-term average = primary structure intact
    above200 = sma200 is None or px > sma200
    below200 = sma200 is None or px < sma200

    # --- breakout / breakdown: close beyond the prior 20-bar extreme within the last 3 sessions
    prior_hi = max(b.high for b in bars[-24:-3]) if len(bars) >= 24 else None
    prior_lo = min(b.low for b in bars[-24:-3]) if len(bars) >= 24 else None
    recent_closes = [b.close for b in bars[-3:]]
    brk_up = bool(prior_hi and max(recent_closes) > prior_hi and px >= prior_hi - 0.5 * snap.atr14)
    brk_dn = bool(prior_lo and min(recent_closes) < prior_lo and px <= prior_lo + 0.5 * snap.atr14)
    confirm = bool((snap.last_tr_atr and snap.last_tr_atr >= 1.1) or (snap.vol_ratio and snap.vol_ratio >= 1.2)
                   or (snap.atr_ratio and snap.atr_ratio >= 1.1))
    # a short burst must not override clearly opposing higher-timeframe structure (anti-noise rule)
    brk_up_raw, brk_dn_raw = brk_up, brk_dn
    if brk_up and bear_htf and below200:
        brk_up = False
        overrides.append("Close above the prior 20-bar high ignored as a Breakout: daily+weekly structure is bearish and "
                         "price is still below the SMA200 (treated as a rally inside a downtrend).")
    if brk_dn and bull_htf and above200 and snap.sma50 and px >= snap.sma50 - 1.5 * snap.atr14:
        brk_dn = False
        overrides.append("Close below the prior 20-bar low ignored as a Breakdown: daily+weekly structure is bullish, "
                         "price is above the SMA200 and within 1.5 ATR of the SMA50 (treated as a pullback).")
    trace.append({"rule": "breakout/breakdown", "up": brk_up, "down": brk_dn, "raw_up": brk_up_raw,
                  "raw_down": brk_dn_raw, "confirmed": confirm, "prior_20bar_high": prior_hi,
                  "prior_20bar_low": prior_lo})
    z20 = snap.z20 or 0.0
    expanding_strong = bool(vol["expanding"] and (snap.rv_pctile or 0) >= 0.80)
    trace.append({"rule": "high_vol_expansion", "expanding": vol["expanding"], "rv_pctile": snap.rv_pctile,
                  "hit": expanding_strong})
    overext_up = lean > 0.35 and (z20 > 3.0 or (snap.rsi14 or 0) >= 78)
    overext_dn = lean < -0.35 and (z20 < -3.0 or (snap.rsi14 or 100) <= 22)
    trace.append({"rule": "overextended", "z20": z20, "rsi14": snap.rsi14, "up": overext_up, "down": overext_dn})
    pullback = bool(bull_htf and st <= -0.25 and above200 and snap.sma50 and px >= snap.sma50 - 1.5 * snap.atr14)
    rally = bool(bear_htf and st >= 0.25 and below200 and snap.sma50 and px <= snap.sma50 + 3.0 * snap.atr14)
    trace.append({"rule": "pullback/rally", "bull_htf": bull_htf, "bear_htf": bear_htf, "short_term": st,
                  "above_sma200": above200, "below_sma200": below200, "pullback": pullback, "rally": rally})
    compress = bool((snap.bb_width_pctile is not None and snap.bb_width_pctile <= 0.20)
                    and (snap.atr_ratio is not None and snap.atr_ratio <= 0.90) and abs(lean) < 0.5)
    deep_compress = bool((snap.bb_width_pctile is not None and snap.bb_width_pctile <= 0.12)
                         and (snap.atr_ratio is not None and snap.atr_ratio <= 0.85))
    mean_rev = abs(z20) >= 2.0 and abs(dscore) < 2.5 and not bull_htf and not bear_htf
    trace.append({"rule": "compression", "bb_pctile": snap.bb_width_pctile, "atr_ratio": snap.atr_ratio,
                  "hit": compress, "deep": deep_compress})
    trace.append({"rule": "mean_reversion", "z20": z20, "hit": mean_rev})

    # --- event overlay
    ev_hi_soon = []
    overlays: list = []
    if events and today:
        for e in events:
            try:
                d = e["date"] if isinstance(e["date"], dt.date) else dt.date.fromisoformat(str(e["date"])[:10])
            except (KeyError, ValueError):
                continue
            days = (d - today).days
            if 0 <= days <= 7:
                overlays.append({"type": "EVENT_RISK", "name": e.get("name", "event"), "days": days,
                                 "risk": e.get("risk", "MEDIUM")})
                if str(e.get("risk", "")).upper() == "HIGH" and days <= 2:
                    ev_hi_soon.append(e)

    # --- decision (priority order)
    label = "Sideways / Range"
    why = ""
    if ev_hi_soon:
        label, why = "Event Risk", f"High-risk event '{ev_hi_soon[0].get('name')}' within 2 days dominates price structure."
    elif overext_up or overext_dn:
        label, why = "Overextended Trend", (f"Price {z20:+.1f} ATR from SMA20, RSI {snap.rsi14:.0f}: stretched "
                                            f"{'above' if overext_up else 'below'} its trend (takes priority over a "
                                            "breakout label: chasing risk).")
    elif (brk_up or brk_dn) and confirm:
        label = "Breakout" if brk_up else "Breakdown"
        why = f"Close beyond prior 20-bar {'high' if brk_up else 'low'} with range/volume confirmation."
    elif expanding_strong:
        label, why = "High-Volatility Expansion", (f"Realized vol in the {snap.rv_pctile:.0%} percentile and expanding "
                                                    f"(RV10/RV20 {snap.rv10 / snap.rv20:.2f}, ATR ratio {snap.atr_ratio:.2f}).")
    elif pullback:
        label, why = "Bullish Pullback", (f"Daily ({daily_label}) and weekly ({weekly.label}) structure intact; "
                                          f"short-term {short.label.lower()} while price holds above the SMA50 band.")
    elif rally:
        label, why = "Bearish Rally", (f"Daily ({daily_label}) and weekly ({weekly.label}) structure bearish; "
                                       f"short-term strength while price stays below the SMA50 band.")
    elif deep_compress:
        label, why = "Low-Volatility Compression", (f"Bollinger width at the {snap.bb_width_pctile:.0%} percentile and ATR "
                                                     f"ratio {snap.atr_ratio:.2f}: ranges have contracted sharply (direction "
                                                     f"lean {lean:+.2f} is kept in the features).")
    elif bull_htf:
        label, why = "Bull Trend", f"Structure score {sscore:+.1f}, daily {daily_label}, weekly {weekly.label}."
    elif bear_htf:
        label, why = "Bear Trend", f"Structure score {sscore:+.1f}, daily {daily_label}, weekly {weekly.label}."
    elif compress:
        label, why = "Low-Volatility Compression", (f"Bollinger width at the {snap.bb_width_pctile:.0%} percentile, "
                                                     f"ATR ratio {snap.atr_ratio:.2f}, no directional commitment.")
    elif mean_rev:
        label, why = "Mean Reversion", f"Price {z20:+.1f} ATR from SMA20 inside a non-trending daily structure."
    else:
        why = "No trend, breakout, expansion or compression criteria met; daily structure is mixed."
        if abs(dscore) >= 2.5 and weekly.available and ((dscore > 0) != (wscore > 0)) and wscore != 0:
            why += " Daily and weekly directions conflict, which prevents a trend label."
    reasons.append(why)

    # --- anti-noise override check (explicit)
    if short.available and daily.available:
        conflicts = (st < -0.25 and daily_norm > 0.3) or (st > 0.25 and daily_norm < -0.3)
        if conflicts:
            if label in ("Bullish Pullback", "Bearish Rally"):
                overrides.append(f"Short-term move ({short.label}) opposes the higher-timeframe lean but structure is "
                                 "intact (price on the right side of the SMA50 band), so it is classed as a "
                                 f"{label.lower()} and does NOT flip the trend label.")
            elif label in ("Bull Trend", "Bear Trend"):
                overrides.append(f"Short-term {short.label.lower()} was too small to qualify as a pullback/rally; "
                                 "higher-timeframe trend label retained (short-term weight is 15%).")
            else:
                overrides.append(f"Short-term {short.label.lower()} conflicts with the daily lean; label "
                                 f"'{label}' was set by a higher-priority rule.")
    if weekly.available and daily.available and daily.norm and weekly.norm and daily.norm * weekly.norm < 0 \
            and abs(daily.norm) > 0.3 and abs(weekly.norm) > 0.2:
        overrides.append(f"Daily ({daily_label}) and weekly ({weekly.label}) disagree: confidence reduced.")

    # --- confidence
    dirn = "bullish" if lean >= 0.15 else "bearish" if lean <= -0.15 else "neutral"
    expected_sign = {"Bull Trend": 1, "Bullish Pullback": 1, "Breakout": 1, "Bear Trend": -1, "Bearish Rally": -1,
                     "Breakdown": -1}.get(label, 0)
    if expected_sign:
        signs = [daily_norm] + ([weekly.norm] if weekly.available else [])
        agree = sum(1 for s in signs if s is not None and s * expected_sign > 0.15) / len(signs)
        clarity = clamp(abs(dscore) / 8.0)
    elif label in ("Sideways / Range", "Low-Volatility Compression", "Mean Reversion"):
        agree = 1.0 - clamp(abs(lean) / 0.5)
        clarity = 0.5 + 0.5 * (1.0 - clamp(abs(dscore) / 5.0))
        if label == "Low-Volatility Compression" and snap.bb_width_pctile is not None:
            clarity = 1.0 - snap.bb_width_pctile
    elif label == "Overextended Trend":
        agree, clarity = clamp(abs(lean) / 0.7), clamp((abs(z20) - 2.0) / 3.0)
    elif label == "High-Volatility Expansion":
        agree, clarity = 0.7, clamp((snap.rv_pctile or 0.8))
    else:  # Event Risk
        agree, clarity = 0.6, 0.6
    data_q = clamp(len(bars) / 252.0) * (1.0 if weekly.available else 0.8)
    conf_parts = [
        {"name": "base", "value": 0.30, "note": "floor for any completed classification"},
        {"name": "timeframe agreement", "value": round(0.30 * agree, 3), "note": f"agreement {agree:.2f} x 0.30"},
        {"name": "signal clarity", "value": round(0.25 * clarity, 3), "note": f"clarity {clarity:.2f} x 0.25"},
        {"name": "data sufficiency", "value": round(0.15 * data_q, 3), "note": f"{len(bars)} daily bars x 0.15"},
    ]
    pen = 0.0
    if overlays:
        p = 0.08 if any(o["risk"] == "HIGH" for o in overlays) else 0.04
        pen += p
        conf_parts.append({"name": "upcoming event", "value": -p, "note": f"{overlays[0]['name']} in {overlays[0]['days']}d"})
    if overrides and any("disagree" in o for o in overrides):
        pen += 0.08
        conf_parts.append({"name": "timeframe conflict", "value": -0.08, "note": "daily vs weekly disagree"})
    if not weekly.available:
        conf_parts.append({"name": "no weekly view", "value": 0.0, "note": "weekly bars unavailable (already in data sufficiency)"})
    conf = clamp(sum(p["value"] for p in conf_parts), 0.05, 0.95)

    features = {
        "lean": lean, "daily_norm": daily_norm, "weekly_norm": weekly.norm, "short_norm": short.norm,
        "trend_strength": clamp(abs(lean)), "bull_htf": bull_htf, "bear_htf": bear_htf,
        "range_bound": label in ("Sideways / Range", "Low-Volatility Compression", "Mean Reversion"),
        "vol_expanding": vol["expanding"], "vol_compressing": vol["compressing"],
        "vol_level": vol["level"], "overextended": 1 if overext_up else -1 if overext_dn else 0,
        "pullback": 1 if pullback else -1 if rally else 0, "breakout": 1 if (brk_up and confirm) else -1 if (brk_dn and confirm) else 0,
        "event_risk": bool(overlays), "z20": z20,
    }
    comps = leg.components
    return RegimeResult(
        label=label, confidence=round(conf, 3), direction=dirn, lean=round(lean, 4),
        timeframes={"daily": daily, "weekly": weekly, "short_term": short, "intraday": intraday},
        volatility=vol, features=features, components=comps, confidence_components=conf_parts,
        reasons=reasons, override_notes=overrides, rule_trace=trace, overlays=overlays,
        indicators=snap.to_dict(), available=True,
        notes=[f"lean = {w_d:.2f}*daily + {w_w:.2f}*weekly + {w_s:.2f}*short-term; "
               "confidence is an agreement index, not a probability"] + list(leg.notes))
