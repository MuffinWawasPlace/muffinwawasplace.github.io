"""Risk engine. One generic implementation for every structure (single legs, verticals, shares + options).

Money convention: everything returned is in DOLLARS PER CONTRACT UNIT (1 contract = 100 shares; share-owning
structures count 100 owned shares per unit). Short premium is never presented as income without its obligation:

    PREMIUM RECEIVED   cash credited when the position is opened
    OBLIGATION CREATED what you may be forced to do (buy / deliver shares, pay out a spread width)
    COLLATERAL         what must be set aside to honour it (broker margin rules differ: this is the conservative
                       cash-secured / defined-risk amount, labelled as such)

Each section carries a `kind`: observed | calculated | estimated | inferred | unavailable.
"""
from __future__ import annotations

import math
from typing import Optional

from option_battle.analytics.greeks import get_model, prob_itm
from option_battle.analytics.payoff import prob_profit
from option_battle.core.util import finite

SCEN = (-2.0, -1.0, -0.5, 0.0, 0.5, 1.0, 2.0)


def adverse_direction(trade) -> str:
    if trade.delta > 0.05:
        return "down"
    if trade.delta < -0.05:
        return "up"
    return "both"


def mark_value(trade, ctx, S: float, t_years: Optional[float] = None, vol_shift: float = 0.0) -> float:
    """Model mark-to-market P&L per share at underlying price S with `t_years` of life left (default: unchanged)."""
    model = get_model(ctx.cfg.pricing_model)
    r, q = ctx.cfg.risk_free, ctx.cfg.div_for(trade.underlying)
    tot = 0.0
    for l in trade.legs:
        c = l.contract
        t = c.t_years if t_years is None else max(t_years, 1e-6)
        iv = max(0.01, (c.iv or 0.0) + vol_shift)
        tot += l.side * l.qty * model.price(c.right, S, c.strike, t, r, q, iv)
    return tot + trade.stock_units * (S - trade.spot) - trade.price_mid


def capital_basis(trade) -> tuple:
    """(dollars per unit, text). The cash/collateral basis used for return-on-capital figures."""
    p = trade.primary_leg.contract
    credit = trade.credit_mid
    s = trade.strategy
    if s == "cash_secured_put":
        return p.strike * 100.0, "strike x 100 (cash-secured; approximate, broker rules differ)"
    if s in ("covered_call",):
        return trade.spot * 100.0, "100 shares at spot (owned)"
    if s in ("protective_put", "collar"):
        return trade.spot * 100.0 + max(0.0, trade.price_mid) * 100.0, "100 shares at spot + net debit"
    if s in ("put_credit_spread", "call_credit_spread"):
        return max(0.0, trade.width - credit) * 100.0, "(width - credit) x 100 (defined-risk max loss; brokers typically hold width x 100)"
    if trade.max_loss is not None:
        return trade.max_loss * 100.0, "debit paid (maximum loss)"
    return abs(trade.price_mid) * 100.0, "net debit"


def obligation_text(trade) -> tuple:
    """(text, notional dollars). What assignment would force."""
    legs = [l for l in trade.legs if l.side < 0]
    if not legs:
        return "none: long premium creates no obligation beyond the debit paid", 0.0
    parts, notional = [], 0.0
    for l in legs:
        c = l.contract
        if c.right == "P":
            parts.append(f"BUY 100 {c.underlying} at ${c.strike:g} per contract if assigned")
            notional += c.strike * 100.0
        else:
            parts.append(f"SELL (deliver) 100 {c.underlying} at ${c.strike:g} per contract if assigned")
            notional += c.strike * 100.0
    if trade.strategy in ("put_credit_spread", "call_credit_spread"):
        return (f"{parts[0]}, offset by the long leg: worst-case payout is the spread width ${trade.width:g} "
                f"(${trade.width * 100:,.0f}) less the credit"), trade.width * 100.0
    return "; ".join(parts), notional


def collateral_text(trade) -> tuple:
    amt, basis = capital_basis(trade)
    if trade.strategy in ("long_call", "long_put", "bull_call_spread", "bear_put_spread"):
        return 0.0, "none beyond the debit paid"
    return amt, basis


def risk_report(trade, ctx, detail: bool = False) -> dict:
    cfg = ctx.cfg
    info = ctx.info(trade.expiration)
    em = info.expected_move if info and info.expected_move else None
    S = trade.spot
    kinds: dict = {}
    mid, nat, best = trade.price_mid, trade.price_natural, trade.price_best
    side = "CREDIT" if mid < 0 else "DEBIT"
    r: dict = {"side": side, "kinds": kinds}
    r["price"] = {"mid_ps": mid, "natural_ps": nat, "best_ps": best, "net_mid_usd": -mid * 100.0,
                  "net_natural_usd": -nat * 100.0, "note": "positive net = credit received, negative = debit paid"}
    kinds["price"] = "observed"
    r["premium_received_usd"] = max(0.0, -mid) * 100.0
    r["premium_paid_usd"] = max(0.0, mid) * 100.0
    ob_text, ob_amt = obligation_text(trade)
    r["obligation"] = {"text": ob_text, "notional_usd": ob_amt}
    col_amt, col_basis = collateral_text(trade)
    r["collateral"] = {"amount_usd": col_amt, "basis": col_basis}
    kinds["obligation"] = kinds["collateral"] = "calculated"
    r["max_gain_usd"] = None if trade.max_gain is None else trade.max_gain * 100.0
    r["max_loss_usd"] = None if trade.max_loss is None else trade.max_loss * 100.0
    r["max_gain_unbounded"] = trade.max_gain is None
    r["max_loss_unbounded"] = trade.max_loss is None
    kinds["max_gain_max_loss"] = "calculated"
    r["breakevens"] = list(trade.breakevens)
    r["breakeven_distance_pct"] = [(b - S) / S for b in trade.breakevens]
    cap, cap_basis = capital_basis(trade)
    r["capital_basis_usd"] = cap
    r["capital_basis_note"] = cap_basis
    # ---- scenarios (expiry exact; mark-to-model optional)
    scen = []
    if em:
        for k in SCEN:
            s_t = max(0.01, S + k * em)
            row = {"move_em": k, "spot": s_t, "move_pct": (s_t - S) / S, "pnl_expiry_usd": trade.pnl_expiry(s_t) * 100.0}
            if detail:
                row["pnl_half_time_usd"] = mark_value(trade, ctx, s_t, 0.5 * trade.primary_leg.contract.t_years) * 100.0
            scen.append(row)
        kinds["scenarios"] = "calculated (expiry payoff exact; half-time column is a Black-Scholes mark, IV unchanged)"
    else:
        kinds["scenarios"] = "unavailable (no expected move)"
    r["scenarios"] = scen
    # ---- realistic losses
    adv = adverse_direction(trade)
    realistic = {"direction": adv}
    if em:
        def loss(k: float) -> float:
            dirs = ("down", "up") if adv == "both" else (adv,)
            worst = 0.0
            for d in dirs:
                s_t = max(0.01, S - k * em) if d == "down" else S + k * em
                worst = max(worst, -trade.pnl_expiry(s_t))
            return max(0.0, worst) * 100.0
        realistic["adverse_1em_usd"], realistic["adverse_2em_usd"] = loss(1.0), loss(2.0)
        kinds["realistic_loss"] = "calculated at expiry for a 1 / 2 expected-move adverse finish (not a forecast)"
    else:
        kinds["realistic_loss"] = "unavailable"
    r["realistic_loss"] = realistic
    # ---- gap risk (needs historical gaps)
    gp = (ctx.hist or {}).get("gaps") or {}
    gap = {"available": False}
    if gp.get("p5_down") is not None and gp.get("p95_up") is not None:
        g = gp["p5_down"] if adv in ("down", "both") else gp["p95_up"]
        s_g = S * (1.0 + g)
        tleft = trade.primary_leg.contract.t_years - 1.0 / 365.0
        pnl = mark_value(trade, ctx, s_g, tleft) * 100.0
        gap = {"available": True, "gap_pct": g, "spot_after": s_g, "pnl_usd": pnl,
               "basis": "overnight gap at the historical 5th/95th percentile (observed history), one day of decay, IV unchanged"}
        kinds["gap"] = "estimated"
    else:
        kinds["gap"] = "unavailable (no usable open prices in history)"
    r["gap"] = gap
    # ---- volatility
    vega_usd = trade.vega * 100.0
    vr = {"vega_usd_per_vol_pt": vega_usd,
          "pnl_iv_up5_usd": (mark_value(trade, ctx, S, None, 0.05) * 100.0 - mark_value(trade, ctx, S) * 100.0),
          "pnl_iv_down5_usd": (mark_value(trade, ctx, S, None, -0.05) * 100.0 - mark_value(trade, ctx, S) * 100.0)}
    r["vol_risk"] = vr
    kinds["vol_risk"] = "calculated (Black-Scholes revaluation, parallel IV shift of +/-5 vol points)"
    # ---- theta
    theta_usd = trade.theta * 100.0
    prem = abs(mid) * 100.0
    r["theta"] = {"per_day_usd": theta_usd, "pct_of_premium_per_day": (theta_usd / prem) if prem > 0 else None,
                  "note": "calendar day; positive = you collect decay, negative = you pay it"}
    kinds["theta"] = "calculated"
    # ---- direction
    dpct = 0.01 * S
    dg = lambda x: (trade.delta * x + 0.5 * trade.gamma * x * x) * 100.0
    r["directional"] = {"delta_shares": trade.delta * 100.0, "delta_usd": trade.delta * 100.0 * S,
                        "pnl_up_1pct_usd": dg(dpct), "pnl_down_1pct_usd": dg(-dpct),
                        "gamma_shares_per_dollar": trade.gamma * 100.0}
    kinds["directional"] = "calculated (delta-gamma approximation)"
    # ---- assignment
    shorts = [l for l in trade.legs if l.side < 0]
    a_level, a_notes = "N/A", []
    if shorts:
        a_level = "LOW"
        for l in shorts:
            c = l.contract
            if c.intrinsic > 0:
                tight = c.extrinsic < max(0.05, 0.002 * c.strike)
                lvl = "HIGH" if tight else "ELEVATED"
                a_notes.append(f"{c.label} is ITM with ${c.extrinsic:.2f} extrinsic"
                               + (": early assignment is likely if exercise is rational" if tight else ""))
            else:
                lvl = "LOW"
                a_notes.append(f"{c.label} is OTM by {abs(c.strike - S) / S * 100:.1f}%")
            rank = {"LOW": 0, "ELEVATED": 1, "HIGH": 2}
            if rank[lvl] > rank[a_level]:
                a_level = lvl
        a_notes.append("American-style options can be exercised early; ex-dividend dates are NOT available from the "
                       "CBOE feed, so dividend-driven call assignment risk cannot be assessed here")
    r["assignment"] = {"level": a_level, "notes": a_notes}
    kinds["assignment"] = "inferred"
    # ---- liquidity / exit cost
    exit_cost = abs(nat - mid) * 100.0
    r["liquidity_risk"] = {"spread_cost_usd": exit_cost, "pct_of_premium": (exit_cost / prem) if prem > 0 else None,
                           "note": "cost of crossing the full bid/ask once (entry OR exit); a round trip at the natural "
                                   "price costs about twice this"}
    kinds["liquidity_risk"] = "calculated"
    # ---- probabilities
    sig = [l.contract.iv for l in trade.legs if l.contract.iv]
    pop = p_itm = None
    t = trade.primary_leg.contract.t_years
    if sig and t > 0:
        s_avg = sum(sig) / len(sig)
        pop = prob_profit(trade.legs, trade.stock_units, S, mid, S, t, s_avg, cfg.risk_free - cfg.div_for(trade.underlying))
        pc = trade.primary_leg.contract
        if pc.iv:
            p_itm = prob_itm(pc.right, S, pc.strike, t, cfg.risk_free, cfg.div_for(trade.underlying), pc.iv)
    r["probability"] = {"profit_at_expiry": pop, "primary_leg_itm": p_itm,
                        "primary_leg_touch_approx": (min(1.0, 2.0 * p_itm) if p_itm is not None else None),
                        "basis": "risk-neutral lognormal model using the legs' IV; a model estimate, not a real-world forecast"}
    kinds["probability"] = "estimated"
    return r
