"""Existing-position management, preserved from the Options Suggester.

This adapter feeds the engine's provider snapshots into the legacy data structures and calls the legacy functions
UNCHANGED: `evaluate_short` (HOLD / CLOSE / ROLL / LET_EXPIRE with reasons) and `find_roll` (later expiration, same or
better strike, quality-gated, net credit). Nothing about that logic is re-implemented here.

The legacy rules use the legacy defaults (standard monthlies, 25-45 DTE window, 0.15-0.20 delta preference) so the
results match what `legacy/options_suggester.py` would print for the same quotes.
"""
from __future__ import annotations

import logging
from typing import Optional

from option_battle.legacy import options_suggester as L

LOG = logging.getLogger("option_battle.management")


def legacy_market(snap, cfg: L.Config, now_u, today) -> L.MarketData:
    """Rebuild legacy MarketData from a MarketSnapshot (whose RawQuote.raw holds the CBOE-shaped record)."""
    md = L.MarketData(symbol=snap.symbol)
    md._today = today  # type: ignore[attr-defined]
    md.feed_spot = snap.spot
    md.spot, md.spot_source = snap.spot, snap.spot_source
    md.chain_timestamp = snap.chain_timestamp
    bars = snap.bars
    md.history_source, md.history_bars = snap.history_source, len(bars)
    closes = [b.close for b in bars]
    md.rv20, md.rv60 = L.realized_vol(closes, 20), L.realized_vol(closes, 60)
    rvs = [v for v in (md.rv20, md.rv60) if v]
    md.rv_blend = sum(rvs) / len(rvs) if rvs else None
    md.regime = L.compute_regime(bars, md.spot)
    root = snap.symbol.replace(".", "")
    exps: set = set()
    for rq in snap.quotes:
        o = rq.raw if isinstance(rq.raw, dict) else None
        if not o:
            continue
        occ = L.parse_occ(str(o.get("option", "")))
        if occ is None or occ.root != root:
            continue
        exps.add(occ.expiration)
        md.rows_by_exp.setdefault(occ.expiration, []).append((occ, o))
        md.quote_index[(occ.expiration, occ.right, round(occ.strike, 3))] = o
    if not exps or not md.spot:
        md.error = "no legacy-parseable contracts"
        return md
    md.expirations = sorted(exps)
    md.selected_exps, md.window_note = L.select_expirations(md.expirations, today, cfg)
    for e in md.selected_exps:
        L.atm_stats_for(md, e, cfg, now_u, today)
    md.ok = True
    return md


def manage_positions(pf, snapshots: dict, now_u, today, assignment_ok: bool = False,
                     delta_lo: float = 0.15, delta_hi: float = 0.20) -> dict:
    """Evaluate every SHORT option in the portfolio with the legacy engine. snapshots: symbol -> MarketSnapshot."""
    shorts = [p for p in (pf.options if pf else []) if p.qty < 0]
    if not shorts:
        return {"available": True, "results": [], "note": "no short option positions to manage"}
    cfg = L.Config(delta_lo=delta_lo, delta_hi=delta_hi)
    bands = L.DeltaBands.build(delta_lo, delta_hi, cfg)
    markets: dict = {}
    for sym, snap in snapshots.items():
        try:
            md = legacy_market(snap, cfg, now_u, today)
            if md.ok:
                L.build_candidates(md, cfg, bands, now_u, today)
            markets[sym] = md
        except Exception as exc:  # pragma: no cover - defensive
            LOG.warning("legacy market build failed for %s: %s", sym, exc)
    lctx = L.PortfolioContext(cash=pf.liquid_cash, holdings=dict(pf.stocks),
                              shorts=[L.ShortOption(p.symbol, p.right, p.strike, p.expiration, abs(p.qty), p.entry)
                                      for p in shorts],
                              watchlist=[], delta_lo=delta_lo, delta_hi=delta_hi, assignment_ok=assignment_ok,
                              source="option battle engine")
    state = L.portfolio_state(lctx, markets)
    out = []
    for pos in lctx.shorts:
        try:
            res = L.evaluate_short(pos, markets.get(pos.symbol), lctx, state, cfg, bands, now_u, today)
        except Exception as exc:  # never let one position break the analysis
            out.append({"position": pos.label, "contracts": pos.contracts, "action": "REVIEW", "urgency": 0,
                        "reasons": [f"legacy evaluation failed: {exc}"]})
            continue
        row = {"position": pos.label, "contracts": pos.contracts, "action": res.action, "urgency": res.urgency,
               "reasons": res.reasons, "quote_source": res.quote_source, "contract": res.contract,
               "metrics": {k: v for k, v in res.metrics.items()}}
        if res.roll:
            rc = res.roll["candidate"]
            row["roll"] = {"to": rc.short_label, "open_mid": rc.mid, "open_bid": rc.bid, "delta": rc.delta, "dte": rc.dte,
                           "close_mid": res.roll["close_mid"], "close_ask": res.roll["close_ask"],
                           "net_mid_total": res.roll["net_mid_total"], "net_cons_total": res.roll["net_cons_total"]}
        if res.replacement:
            rp = res.replacement
            row["replacement"] = {"label": rp.short_label, "mid": rp.mid, "delta": rp.delta, "raw_score": rp.raw_score}
        out.append(row)
    out.sort(key=lambda r: -r.get("urgency", 0))
    return {"available": True, "results": out, "warnings": state.get("warnings", []),
            "assignment_ok": assignment_ok,
            "note": "Preserved legacy rules (Options Suggester v2): monthly expirations, 25-45 DTE rolls, "
                    f"delta preference {delta_lo:.2f}-{delta_hi:.2f}, CSP assignment "
                    f"{'acceptable' if assignment_ok else 'NOT acceptable'}."}
