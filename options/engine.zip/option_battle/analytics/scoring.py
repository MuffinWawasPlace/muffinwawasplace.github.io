"""Trade Quality Score (0-100). Deterministic, decomposable, configurable.

    TOTAL = sum_k weight_k * factor_k   (+ named penalties)      factor_k in [0, 1], weights normalized to 100

Components (default weights in config.ScoreWeights):
    regime_fit     how well the STRATEGY's intended exposure (direction, vega, structure) fits the detected regime
    liquidity      spread / open interest / volume / quote size (preserved legacy scales)
    vol_edge       ATM IV vs realized vol (preserved legacy 0.85->1.40 scale) + strike IV vs its own smile
    technical_fit  strike location vs expected move and support/resistance
    risk_reward    premium yield (preserved legacy yield scales) / payoff ratio, blended with model P(profit)
    theta_profile  time-decay shape for the structure (seller wants decay without gamma cliff; buyer wants low burn)
    delta_fit      primary-leg |delta| vs the configured band (preserved legacy DeltaBands tiers)
    entry_quality  timing (extension vs trend, nearby levels), spread cost and quote freshness

Hard gates (preserved legacy quality gates) DISQUALIFY a trade: it is still scored so the user can see why, but it is
never ranked as a setup. Penalties are listed by name. Nothing here is produced by an LLM.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

from option_battle.core.util import clamp, lin
from option_battle.legacy.options_suggester import YIELD_SCALE, Config as LegacyConfig, DeltaBands
from option_battle.strategies.base import META

LABELS = {
    "regime_fit": "Regime fit", "liquidity": "Liquidity", "vol_edge": "Volatility edge",
    "technical_fit": "Technical fit", "risk_reward": "Risk / reward", "theta_profile": "Theta profile",
    "delta_fit": "Delta fit", "entry_quality": "Entry quality",
}
_LEGACY_CFG = LegacyConfig()

# Structure adjustments to regime fit, by regime label and strategy family. Signed entries marked "aligned" flip
# sign when the strategy leans against the regime's direction (e.g. a put-selling bonus in a bullish pullback
# becomes a penalty for a call credit spread).
STRUCTURE = {
    "Sideways / Range": ({"short": 0.12, "credit_spread": 0.18, "long": -0.15, "debit_spread": -0.08, "hedge": 0.0}, False),
    "Low-Volatility Compression": ({"short": -0.12, "credit_spread": -0.06, "long": 0.10, "debit_spread": 0.05, "hedge": 0.05}, False),
    "High-Volatility Expansion": ({"short": -0.12, "credit_spread": 0.03, "long": -0.05, "debit_spread": 0.05, "hedge": 0.15}, False),
    "Breakout": ({"short": 0.0, "credit_spread": 0.03, "long": 0.12, "debit_spread": 0.15, "hedge": -0.05}, True),
    "Breakdown": ({"short": 0.0, "credit_spread": 0.03, "long": 0.12, "debit_spread": 0.15, "hedge": 0.10}, True),
    "Bullish Pullback": ({"short": 0.12, "credit_spread": 0.12, "long": 0.04, "debit_spread": 0.06, "hedge": 0.0}, True),
    "Bearish Rally": ({"short": 0.10, "credit_spread": 0.12, "long": 0.04, "debit_spread": 0.06, "hedge": 0.05}, True),
    "Overextended Trend": ({"short": 0.05, "credit_spread": 0.0, "long": -0.20, "debit_spread": -0.10, "hedge": 0.15}, False),
    "Mean Reversion": ({"short": 0.05, "credit_spread": 0.10, "long": -0.05, "debit_spread": 0.0, "hedge": 0.0}, False),
    "Event Risk": ({"short": -0.18, "credit_spread": -0.08, "long": -0.05, "debit_spread": 0.0, "hedge": 0.15}, False),
    "Bull Trend": ({}, True), "Bear Trend": ({}, True),
}
# covered calls are the classic overextension response (selling the stretch), protective puts are not "chasing"
SPECIAL = {("Overextended Trend", "covered_call"): 0.12, ("Overextended Trend", "collar"): 0.10}


@dataclass
class ScoreResult:
    total: float
    raw_total: float
    components: list
    penalties: list
    gates: list
    disqualified: bool
    battle: dict
    regime_fit_detail: dict
    notes: list = field(default_factory=list)

    def factor(self, key: str) -> float:
        for c in self.components:
            if c["key"] == key:
                return c["factor"]
        return 0.0

    def to_dict(self) -> dict:
        return dict(self.__dict__)


# ----------------------------------------------------------------------------- regime fit (strategy level)

def strategy_regime_fit(strategy: str, posture, label: str) -> dict:
    """Fit of a strategy's INTENDED exposure to the regime. 0..1 plus a sentence per component.

    direction  1 - |bias - D_eff| / 1.5                              (hedges: 0.4 + 0.6 * hedge_need)
    volatility 0.5 + 0.5 * V * (-vega_sign), shrunk toward 0.5 by the structure's vol_weight; +/-0.1 for vol trend
    structure  regime-label table above (signed for direction-aware labels)
    fit        clamp(0.55 * direction + 0.45 * volatility + structure), then shrunk toward 0.5 when regime
               confidence is low:  0.5 + (fit - 0.5) * (0.5 + 0.5 * confidence)
    """
    m = META[strategy]
    D, V, E = posture.D_eff, posture.V, posture.E
    reasons = []
    if m.family == "hedge":
        dir_f = clamp(0.4 + 0.6 * posture.hedge_need)
        reasons.append(f"hedge need {posture.hedge_need:.2f} (downside lean, stretch, events, vol expansion) -> {dir_f:.2f}")
    else:
        dir_f = clamp(1.0 - abs(m.bias - D) / 1.5)
        reasons.append(f"intended bias {m.bias:+.2f} vs regime lean {D:+.2f} -> {dir_f:.2f}")
    if m.vega_sign == 0:
        vol_f = 0.5
        reasons.append("vega-neutral structure: volatility pricing neutral (0.50)")
    else:
        raw = 0.5 + 0.5 * V * (-m.vega_sign)
        vol_f = 0.5 + (raw - 0.5) * m.vol_weight
        trend = 0.10 * E * m.vega_sign * m.vol_weight
        vol_f = clamp(vol_f + trend)
        side = "short" if m.vega_sign < 0 else "long"
        reasons.append(f"{side} vega with IV richness V {V:+.2f}, vol weight {m.vol_weight:.2f}"
                       + (f", vol {'expanding' if E > 0 else 'compressing'} {trend:+.2f}" if E else "") + f" -> {vol_f:.2f}")
    table, aligned = STRUCTURE.get(label, ({}, False))
    s_adj = table.get(m.family, 0.0)
    if aligned and s_adj and m.family != "hedge":
        regime_sign = 1 if posture.D > 0.05 else -1 if posture.D < -0.05 else 0
        strat_sign = 1 if m.bias > 0 else -1
        if regime_sign == 0 or strat_sign != regime_sign:
            s_adj = -abs(s_adj)
    s_adj += SPECIAL.get((label, strategy), 0.0)
    if s_adj:
        reasons.append(f"{label} structure adjustment for a {m.family.replace('_', ' ')} {s_adj:+.2f}")
    fit = clamp(0.55 * dir_f + 0.45 * vol_f + s_adj)
    shrink = 0.5 + 0.5 * posture.confidence
    final = clamp(0.5 + (fit - 0.5) * shrink)
    reasons.append(f"regime confidence {posture.confidence:.2f}: fit pulled toward neutral by x{shrink:.2f} -> {final:.2f}")
    return {"factor": final, "direction": dir_f, "volatility": vol_f, "structure": s_adj, "pre_confidence": fit,
            "reasons": reasons}


# ----------------------------------------------------------------------------- component helpers

def _dte_fit_short(dte: int) -> float:
    if 25 <= dte <= 45:
        return 1.0
    if dte < 25:
        return 0.25 + 0.75 * lin(dte, 5, 25)
    return 0.6 + 0.4 * lin(dte, 75, 45)


def _dte_fit_long(dte: int) -> float:
    if dte >= 45:
        return 1.0 if dte <= 120 else 0.85
    return 0.15 + 0.85 * lin(dte, 7, 45)


def _technical(trade, m, ctx) -> tuple:
    fam = META[trade.strategy].family
    p = trade.primary_leg.contract
    atr = ctx.atr or 0.0
    lv = ctx.levels
    S = trade.spot
    notes = []
    em = m.em
    sup = lv.supports[0].price if (lv.available and lv.supports) else None
    res = lv.resistances[0].price if (lv.available and lv.resistances) else None

    def em_cov(x) -> float:
        return lin(x, 0.5, 1.0) if x is not None else 0.5

    def below_support(k: float) -> Optional[float]:
        if sup is None or not atr:
            return None
        return lin((sup - k) / atr, -1.0, 0.75)   # strike 0.75 ATR under support = full credit

    def above_resistance(k: float) -> Optional[float]:
        if res is None or not atr:
            return None
        return lin((k - res) / atr, -1.0, 0.75)

    if fam in ("short", "credit_spread"):
        f_em = em_cov(m.em_ratio)
        notes.append(f"short strike {m.em_ratio:.2f}x expected move from spot -> {f_em:.2f}" if m.em_ratio is not None
                     else "expected move unavailable: coverage neutral")
        lvl = below_support(p.strike) if p.right == "P" else above_resistance(p.strike)
        if lvl is None:
            notes.append("no support/resistance level on that side: level check skipped")
            return f_em, notes
        ref = sup if p.right == "P" else res
        notes.append(f"strike {p.strike:g} vs nearest {'support' if p.right == 'P' else 'resistance'} {ref:.2f} -> {lvl:.2f}")
        return 0.6 * f_em + 0.4 * lvl, notes
    if fam in ("long", "debit_spread"):
        bullish = trade.delta > 0
        be = trade.breakevens[0] if trade.breakevens else p.strike
        f_be = 0.5
        if em:
            need = abs(be - S) * (1 if (be > S) == bullish else -1)
            f_be = lin(need / em, 1.2, 0.2)
            notes.append(f"breakeven {be:.2f} needs {need / em:+.2f} expected moves -> {f_be:.2f}")
        target = res if bullish else sup
        if target is None or not atr:
            notes.append("no level in the trade's direction (open space / at extremes): room 0.70")
            room = 0.70
        else:
            room = lin(((target - be) if bullish else (be - target)) / atr, -1.0, 1.5)
            notes.append(f"room from breakeven to {'resistance' if bullish else 'support'} {target:.2f} -> {room:.2f}")
        return 0.55 * f_be + 0.45 * room, notes
    # hedges: protection strike near support activates where the structure would have failed anyway
    if sup is None or not atr:
        notes.append("no support level: protection placement neutral")
        return 0.5, notes
    f = lin(abs(p.strike - sup) / atr, 3.0, 0.0)
    notes.append(f"protective strike {p.strike:g} vs support {sup:.2f} ({abs(p.strike - sup) / atr:.1f} ATR) -> {f:.2f}")
    return f, notes


def _risk_reward(trade, m) -> tuple:
    fam = META[trade.strategy].family
    pop = m.pop
    f_pop_short = lin(pop, 0.55, 0.88) if pop is not None else 0.5
    if trade.strategy in ("cash_secured_put", "covered_call"):
        y0, y1 = YIELD_SCALE["PUT" if trade.strategy == "cash_secured_put" else "CALL"]
        fy = lin(m.annualized_roc, y0, y1)
        return 0.7 * fy + 0.3 * f_pop_short, [f"annualized premium yield {m.annualized_roc * 100:.1f}% on "
                                               f"{'strike' if trade.strategy == 'cash_secured_put' else 'share'} value "
                                               f"(scale {y0:.1%}->{y1:.1%}) -> {fy:.2f}",
                                               f"model P(profit) {pop if pop is not None else float('nan'):.2f} -> {f_pop_short:.2f}"]
    if fam == "credit_spread":
        risk = max(1e-9, trade.width - trade.credit_mid)
        ratio = trade.credit_mid / risk
        fr = lin(ratio, 0.12, 0.45)
        return 0.6 * fr + 0.4 * f_pop_short, [f"credit / risk {ratio:.2f} (scale 0.12->0.45) -> {fr:.2f}",
                                              f"model P(profit) {pop:.2f} -> {f_pop_short:.2f}" if pop is not None
                                              else "P(profit) unavailable"]
    if fam == "debit_spread":
        ratio = (trade.max_gain / trade.max_loss) if (trade.max_gain and trade.max_loss) else 0.0
        fr = lin(ratio, 0.6, 2.5)
        fp = lin(pop, 0.25, 0.55) if pop is not None else 0.5
        return 0.6 * fr + 0.4 * fp, [f"max gain / max loss {ratio:.2f} (0.6->2.5) -> {fr:.2f}",
                                     f"model P(profit) {pop:.2f} -> {fp:.2f}" if pop is not None else "P(profit) unavailable"]
    if fam == "long":
        fr = lin(m.rr, 0.3, 1.5) if m.rr is not None else 0.4
        fp = lin(pop, 0.20, 0.50) if pop is not None else 0.5
        return 0.65 * fr + 0.35 * fp, [f"payoff at a 1-EM favourable move / loss at a 2-EM adverse move "
                                       f"{m.rr if m.rr is not None else float('nan'):.2f} (0.3->1.5) -> {fr:.2f}",
                                       f"model P(profit) {pop:.2f} -> {fp:.2f}" if pop is not None else "P(profit) unavailable"]
    # hedge: protection delivered in a 2-EM drop per dollar of net cost
    cost = max(1.0, trade.debit_mid * 100.0)
    ratio = m.target_profit_usd / cost if trade.debit_mid > 0 else 3.0
    fr = lin(ratio, 1.0, 6.0)
    return fr, [f"protection value in a 2-EM drop / net cost {ratio:.2f} (1->6) -> {fr:.2f}"
                + (" (zero or credit cost)" if trade.debit_mid <= 0 else "")]


def _theta(trade, m) -> tuple:
    fam = META[trade.strategy].family
    prem = max(0.01, abs(trade.price_mid) * 100.0)
    if fam in ("short", "credit_spread"):
        fd = _dte_fit_short(trade.dte)
        decay = (m.net_theta_usd / prem) if m.net_theta_usd > 0 else 0.0
        fdec = lin(decay, 0.008, 0.04)
        return 0.7 * fd + 0.3 * fdec, [f"{trade.dte} DTE decay window (best 25-45) -> {fd:.2f}",
                                       f"theta {m.net_theta_usd:+.2f}$/day = {decay * 100:.2f}% of premium/day -> {fdec:.2f}"]
    burn = abs(min(0.0, m.net_theta_usd)) * min(trade.dte, 21) / prem
    fb = lin(burn, 0.6, 0.12)
    fd = _dte_fit_long(trade.dte)
    return 0.6 * fb + 0.4 * fd, [f"3-week theta burn {burn * 100:.0f}% of premium (60%->12%) -> {fb:.2f}",
                                 f"{trade.dte} DTE runway (best >= 45) -> {fd:.2f}"]


def _vol_edge(trade, m, ctx) -> tuple:
    meta = META[trade.strategy]
    notes = []
    if m.iv_rv is None:
        notes.append("IV/RV unavailable: neutral 0.50")
        base = 0.5
    else:
        sell = lin(m.iv_rv, 0.85, 1.40)
        base = sell if meta.vega_sign < 0 else (1.0 - sell) if meta.vega_sign > 0 else 0.5
        notes.append(f"ATM IV / realized {m.iv_rv:.2f} (0.85->1.40 favours sellers) -> {base:.2f} for "
                     f"{'short' if meta.vega_sign < 0 else 'long' if meta.vega_sign > 0 else 'neutral'} vega")
    smile = 0.5
    if m.smile_ratio is not None:
        s = lin(m.smile_ratio, 0.95, 1.08)
        smile = s if meta.vega_sign < 0 else (1 - s) if meta.vega_sign > 0 else 0.5
        notes.append(f"strike IV / neighbouring-strike IV {m.smile_ratio:.3f} -> {smile:.2f}")
    f = 0.8 * base + 0.2 * smile
    f = 0.5 + (f - 0.5) * max(0.35, meta.vol_weight)
    notes.append(f"scaled by how much vol pricing matters to this structure ({max(0.35, meta.vol_weight):.2f})")
    return f, notes


def _delta(trade, m, ctx) -> tuple:
    lo, hi = ctx.cfg.delta_bands.get(trade.strategy, (0.15, 0.30))
    bands = DeltaBands.build(lo, hi, _LEGACY_CFG)
    d = m.primary_delta_abs
    f = bands.fit(d)
    return f, [f"|delta| {d:.3f} vs band {lo:.2f}-{hi:.2f} (tier {bands.tier(d)}; fallbacks "
               f"{bands.fb_lo:.2f}-{bands.fb_hi:.2f}, {bands.fin_lo:.2f}-{bands.fin_hi:.2f}) -> {f:.2f}"], bands


# ----------------------------------------------------------------------------- gates + penalties

def hard_gates(trade, m, cfg) -> list:
    out = []
    fam = META[trade.strategy].family
    for l in trade.legs:
        c = l.contract
        if not c.usable:
            out.append(f"{c.label}: unusable quote ({', '.join(c.flags) or 'invalid'})")
        if l.side < 0 and not c.sellable:
            out.append(f"{c.label}: no valid bid to sell into")
        if c.open_interest < cfg.min_open_interest:
            out.append(f"{c.label}: open interest {c.open_interest} < {cfg.min_open_interest}")
        if c.spread_pct > cfg.max_spread_pct and c.spread > cfg.spread_abs_ok:
            out.append(f"{c.label}: spread {c.spread_pct * 100:.0f}% > {cfg.max_spread_pct * 100:.0f}%")
        if c.iv is None:
            out.append(f"{c.label}: no implied volatility (feed or solved)")
    if fam == "short":
        p = trade.primary_leg.contract
        if p.mid < cfg.min_short_mid:
            out.append(f"premium {p.mid:.2f} < minimum {cfg.min_short_mid:.2f}")
    if fam in ("short", "credit_spread") and m.em_ratio is not None and m.em_ratio < cfg.min_em_ratio_short:
        out.append(f"short strike only {m.em_ratio:.2f}x expected move away (< {cfg.min_em_ratio_short:.2f})")
    if fam == "credit_spread" and trade.credit_mid <= 0:
        out.append("spread does not produce a credit at mid")
    if fam == "debit_spread" and trade.debit_mid <= 0:
        out.append("spread does not cost a debit at mid (stale or crossed quotes)")
    return out


def penalties(trade, m, ctx, bands) -> list:
    out = []
    fam = META[trade.strategy].family
    if fam in ("short", "credit_spread"):
        if m.em_ratio is not None and m.em_ratio < 0.75:
            out.append({"key": "poor_em_coverage", "points": -(0.75 - m.em_ratio) * 30.0,
                        "why": f"short strike {m.em_ratio:.2f}x EM (< 0.75)"})
        if m.primary_delta_abs > bands.hi:
            out.append({"key": "excessive_delta", "points": -min(12.0, (m.primary_delta_abs - bands.hi) * 120.0),
                        "why": f"|delta| {m.primary_delta_abs:.2f} above band {bands.hi:.2f}"})
        if m.event_exposure > 0:
            out.append({"key": "event_gap_risk", "points": -10.0 * m.event_exposure,
                        "why": f"scheduled event inside the option's life (exposure {m.event_exposure:.2f})"})
    if fam == "short":
        mid = trade.primary_leg.contract.mid
        if mid < 0.30:
            out.append({"key": "low_premium", "points": -5.0 * (1.0 - mid / 0.30), "why": f"premium ${mid:.2f}/sh"})
    if fam in ("long", "debit_spread", "hedge") and m.event_exposure > 0:
        out.append({"key": "event_iv_crush", "points": -4.0 * m.event_exposure,
                    "why": "event inside the option's life: long premium may be paying event-inflated IV"})
    q = min(l.contract.quality for l in trade.legs)
    if q < 0.8:
        out.append({"key": "quote_quality", "points": -6.0 * (0.8 - q) / 0.8,
                    "why": f"weakest leg quote quality {q:.2f}"})
    for p in out:
        p["points"] = round(p["points"], 2)
    return out


# ----------------------------------------------------------------------------- battle stats

def battle_stats(trade, m, comp: dict) -> dict:
    """Conceptual 0-100 visualisation attributes, each mapped from a named calculation (shown in the UI legend)."""
    pop = m.pop if m.pop is not None else 0.5
    return {
        "attack": round(100 * comp["risk_reward"]),                         # return potential / premium efficiency
        "armor": round(100 * clamp(0.5 * comp["technical_fit"] + 0.5 * pop)),  # distance from danger, P(profit)
        "speed": round(100 * comp["theta_profile"]),                        # decay profile
        "shield": round(100 * comp["vol_edge"]),                            # volatility environment
        "supply": round(100 * comp["liquidity"]),                           # liquidity
        "power": round(min(100.0, abs(m.net_delta_shares))),                # |net delta| in shares per unit
        "power_sign": 1 if m.net_delta_shares > 0.5 else -1 if m.net_delta_shares < -0.5 else 0,
    }


# ----------------------------------------------------------------------------- main

def score_trade(trade, m, ctx, weights: Optional[dict] = None, timing: Optional[dict] = None) -> ScoreResult:
    from option_battle.analytics.entry import timing_assessment  # local: entry imports scoring helpers
    cfg = ctx.cfg
    w = weights or cfg.weights.normalized()
    rf = strategy_regime_fit(trade.strategy, ctx.posture, ctx.regime.label)
    tech_f, tech_n = _technical(trade, m, ctx)
    rr_f, rr_n = _risk_reward(trade, m)
    th_f, th_n = _theta(trade, m)
    ve_f, ve_n = _vol_edge(trade, m, ctx)
    de_f, de_n, bands = _delta(trade, m, ctx)
    liq = m.liquidity
    wk = next((x for x in liq["legs"] if x["label"] == liq["weakest"]), liq["legs"][0])
    liq_n = [f"weakest leg {liq['weakest']}: spread {wk['spread_pct'] * 100:.1f}%, OI {wk['oi']:,}, volume {wk['volume']:,}",
             "0.7 x weakest leg + 0.3 x average (spread 45%, OI 30%, volume 15%, size 10%)"]
    tm = timing or timing_assessment(trade, m, ctx)
    sc_q = lin(m.spread_cost_pct, 0.20, 0.02)
    fresh = ctx.freshness or {}
    fr_q = 1.0 if (ctx.is_mock or fresh.get("market_session") == "open") and not fresh.get("stale") else \
        0.2 if fresh.get("stale") else 0.6
    ent_f = 0.5 * tm["factor"] + 0.3 * sc_q + 0.2 * fr_q
    ent_n = [f"timing {tm['factor']:.2f}: " + ("; ".join(tm["notes"]) or "no timing flags"),
             f"crossing the spread costs {m.spread_cost_pct * 100:.1f}% of premium -> {sc_q:.2f}",
             f"quote freshness ({'mock' if ctx.is_mock else fresh.get('market_session', '?')}) -> {fr_q:.2f}"]
    facs = {"regime_fit": (rf["factor"], rf["reasons"]), "liquidity": (liq["score"], liq_n),
            "vol_edge": (ve_f, ve_n), "technical_fit": (tech_f, tech_n), "risk_reward": (rr_f, rr_n),
            "theta_profile": (th_f, th_n), "delta_fit": (de_f, de_n), "entry_quality": (ent_f, ent_n)}
    comps = []
    for k, (f, n) in facs.items():
        f = clamp(f if math.isfinite(f) else 0.5)
        comps.append({"key": k, "label": LABELS[k], "factor": round(f, 4), "weight": round(w.get(k, 0.0), 2),
                      "points": round(f * w.get(k, 0.0), 2), "explain": n})
    pens = penalties(trade, m, ctx, bands)
    gates = hard_gates(trade, m, cfg)
    raw = sum(c["points"] for c in comps)
    total = clamp(raw + sum(p["points"] for p in pens), 0.0, 100.0)
    comp_f = {c["key"]: c["factor"] for c in comps}
    return ScoreResult(total=round(total, 1), raw_total=round(raw, 2), components=comps, penalties=pens, gates=gates,
                       disqualified=bool(gates), battle=battle_stats(trade, m, comp_f), regime_fit_detail=rf,
                       notes=[f"timing checks: {len(tm['notes'])}"])
