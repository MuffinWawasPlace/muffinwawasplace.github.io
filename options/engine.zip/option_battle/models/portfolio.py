"""What the user already owns. Held in the browser (localStorage) and POSTed with each analysis; the server keeps no
portfolio state, matching the legacy rule that portfolio context is never written to disk by the engine.

Text grammar (items separated by newlines, ';' or ','; a comma used as a thousands separator, as in 25,000,
is NOT an item separator):
    cash 25000                       |  $25,000 cash
    100 SPY shares                   |  SPY 100            |  100 SPY      |  1.579 GLD shares   (fractional shares kept)
    SPAXX 2538.27                    money-market sweep funds listed in CASH_EQUIVALENTS are recorded as cash
                                     equivalents at an assumed $1.00 NAV, with a visible note; any other 5-letter
                                     ...XX money-market ticker is rejected with instructions rather than guessed
    -1 SPY C 600 2026-12-18 [1.20]   |  +2 QQQ P 480 2027-01-15 [@2.4]    (sign: + long, - short; optional entry/share)
    short 2 QQQ put 480 2026-12-18   |  long 1 SPY call 500 2027-01-15
"""
from __future__ import annotations

import datetime as dt
import math
import re
from dataclasses import dataclass, field
from typing import Optional

from option_battle.legacy.options_suggester import parse_date, parse_money, parse_ticker


class PortfolioParseError(ValueError):
    pass


# $1.00-NAV money-market / core sweep funds. They have no option chain and no CBOE quote, so treating them as stock
# would make the engine try (and fail) to price them. They are recorded separately as cash equivalents.
CASH_EQUIVALENTS = {
    "SPAXX": "Fidelity Government Money Market", "FDRXX": "Fidelity Government Cash Reserves",
    "SPRXX": "Fidelity Money Market", "FZFXX": "Fidelity Treasury Money Market", "FCASH": "Fidelity core cash",
    "VMFXX": "Vanguard Federal Money Market", "VMRXX": "Vanguard Cash Reserves Federal Money Market",
    "VUSXX": "Vanguard Treasury Money Market", "SWVXX": "Schwab Value Advantage Money Fund",
    "SNVXX": "Schwab Government Money Fund", "SNOXX": "Schwab Treasury Obligations Money Fund",
}

# Item separators: newline, ';', or a comma NOT followed by exactly three digits (that comma is a thousands separator).
_ITEM_SPLIT = re.compile(r"[\n;]+|,(?!\d{3}(?!\d))")
# Quantity: integer, thousands-grouped integer, or decimal (fractional shares).
_QTY = r"([0-9][0-9,]*(?:\.[0-9]+)?|\.[0-9]+)"


def _qty(raw: str):
    """'1,000' -> 1000, '89' -> 89, '1.579' -> 1.579 (int when whole, so whole-share counts display unchanged)."""
    try:
        v = float(raw.replace(",", ""))
    except ValueError:
        raise PortfolioParseError(f"bad quantity '{raw}'") from None
    if not math.isfinite(v) or v < 0:
        raise PortfolioParseError(f"bad quantity '{raw}'")
    return int(v) if v == int(v) else v


@dataclass
class OptionPosition:
    symbol: str
    right: str                   # C | P
    strike: float
    expiration: dt.date
    qty: int                     # signed contracts: + long, - short
    entry: Optional[float] = None

    @property
    def label(self) -> str:
        return f"{self.symbol} {self.expiration.isoformat()} {self.strike:g}{self.right}"

    def to_dict(self) -> dict:
        return {"symbol": self.symbol, "right": self.right, "strike": self.strike,
                "expiration": self.expiration.isoformat(), "qty": self.qty, "entry": self.entry}


@dataclass
class PortfolioContext:
    cash: float = 0.0
    stocks: dict = field(default_factory=dict)         # symbol -> shares (fractional allowed)
    options: list = field(default_factory=list)        # list[OptionPosition]
    source: str = "user"
    cash_equivalents: dict = field(default_factory=dict)   # symbol -> dollars (money-market funds, $1.00 NAV assumed)
    notes: list = field(default_factory=list)              # parse-time assumptions, surfaced to the user

    @property
    def cash_equivalent_total(self) -> float:
        return float(sum(self.cash_equivalents.values()))

    @property
    def liquid_cash(self) -> float:
        """Cash plus money-market cash equivalents (usable to secure puts, subject to your broker's rules)."""
        return self.cash + self.cash_equivalent_total

    @property
    def empty(self) -> bool:
        return self.liquid_cash <= 0 and not self.stocks and not self.options

    def shares(self, sym: str) -> float:
        return self.stocks.get(sym.upper(), 0)

    def symbols(self) -> list:
        out = list(self.stocks) + [p.symbol for p in self.options]
        seen: list = []
        for s in out:
            if s not in seen:
                seen.append(s)
        return seen

    def to_dict(self) -> dict:
        return {"cash": self.cash, "stocks": dict(self.stocks), "options": [p.to_dict() for p in self.options],
                "cash_equivalents": dict(self.cash_equivalents), "notes": list(self.notes)}

    @staticmethod
    def from_dict(d: Optional[dict]) -> "PortfolioContext":
        """Structured input (what the portfolio form sends). Every error names the row and field so the form can
        point at it; nothing is guessed. Stocks may be a {symbol: shares} dict or a list of {symbol, qty} rows;
        cash_equivalents likewise. Blank rows are ignored."""
        d = d or {}
        pf = PortfolioContext(source=str(d.get("source", "user")))

        def num(v, what: str) -> float:
            s = str(v).replace(",", "").replace("$", "").strip()
            try:
                x = float(s)
            except ValueError:
                raise PortfolioParseError(f"{what}: '{v}' is not a number") from None
            if not math.isfinite(x):
                raise PortfolioParseError(f"{what}: '{v}' is not a number")
            return x

        def rows(obj, key_name: str, val_name: str) -> list:
            if isinstance(obj, dict):
                return [{"symbol": k, key_name: v} for k, v in obj.items()]
            return [r for r in (obj or []) if isinstance(r, dict)]

        def blank(v) -> bool:
            return v is None or str(v).strip() == ""

        def ticker(v, what: str) -> str:
            try:
                return parse_ticker(str(v))
            except ValueError as exc:
                raise PortfolioParseError(f"{what}: {exc}") from None

        cash = d.get("cash")
        if not blank(cash):
            c = num(cash, "Cash")
            if c < 0:
                raise PortfolioParseError("Cash: cannot be negative")
            pf.cash = c

        for i, r in enumerate(rows(d.get("cash_equivalents"), "amount", "amount"), 1):
            sym, amt = r.get("symbol"), r.get("amount")
            if blank(sym) and blank(amt):
                continue
            if blank(sym):
                raise PortfolioParseError(f"Money-market row {i}: pick the fund")
            if blank(amt):
                raise PortfolioParseError(f"Money-market row {i} ({sym}): enter the dollar amount")
            a = num(amt, f"Money-market row {i} ({sym}) amount")
            if a < 0:
                raise PortfolioParseError(f"Money-market row {i} ({sym}): amount cannot be negative")
            if a > 0:
                s = ticker(sym, f"Money-market row {i}")
                pf.cash_equivalents[s] = pf.cash_equivalents.get(s, 0.0) + a

        for i, r in enumerate(rows(d.get("stocks"), "qty", "qty"), 1):
            sym, q = r.get("symbol"), r.get("qty", r.get("shares"))
            if blank(sym) and blank(q):
                continue
            if blank(sym):
                raise PortfolioParseError(f"Stock row {i}: enter the ticker")
            s = ticker(sym, f"Stock row {i}")
            if blank(q):
                raise PortfolioParseError(f"Stock row {i} ({s}): enter how many shares")
            n = num(q, f"Stock row {i} ({s}) shares")
            if n < 0:
                raise PortfolioParseError(f"Stock row {i} ({s}): shares cannot be negative (short stock is not supported)")
            n = int(n) if n == int(n) else n
            if n == 0:
                continue
            if s in CASH_EQUIVALENTS:          # typed a sweep fund into the stock list: same rule as the text parser
                pf.cash_equivalents[s] = pf.cash_equivalents.get(s, 0.0) + float(n)
                pf.notes.append(f"{s} ({CASH_EQUIVALENTS[s]}) recorded as a cash equivalent, not a stock: "
                                f"${float(n):,.2f} at an assumed $1.00 NAV.")
                continue
            pf.stocks[s] = pf.stocks.get(s, 0) + n

        for i, o in enumerate(d.get("options") or [], 1):
            if not isinstance(o, dict):
                continue
            if all(blank(o.get(k)) for k in ("symbol", "strike", "expiration", "qty")):
                continue
            where = f"Option row {i}"
            if blank(o.get("symbol")):
                raise PortfolioParseError(f"{where}: enter the ticker")
            s = ticker(o["symbol"], where)
            where = f"Option row {i} ({s})"
            right = str(o.get("right", "")).strip().upper()[:1]
            if right not in ("C", "P"):
                raise PortfolioParseError(f"{where}: choose Call or Put")
            if blank(o.get("strike")):
                raise PortfolioParseError(f"{where}: enter the strike")
            strike = num(o["strike"], f"{where} strike")
            if strike <= 0:
                raise PortfolioParseError(f"{where}: strike must be above 0")
            e = o.get("expiration")
            if blank(e):
                raise PortfolioParseError(f"{where}: pick the expiration date")
            if isinstance(e, dt.date):
                exp = e
            else:
                try:
                    exp = dt.date.fromisoformat(str(e).strip()[:10])
                except ValueError:
                    raise PortfolioParseError(f"{where}: expiration '{e}' must be a date (YYYY-MM-DD)") from None
            if blank(o.get("qty")):
                raise PortfolioParseError(f"{where}: enter the number of contracts")
            qf = num(o["qty"], f"{where} contracts")
            if qf != int(qf) or qf == 0:
                raise PortfolioParseError(f"{where}: contracts must be a whole number other than 0")
            qty = int(qf)
            side = str(o.get("side", "")).strip().lower()
            if side in ("short", "sell", "sold", "-"):
                qty = -abs(qty)
            elif side in ("long", "buy", "bought", "+"):
                qty = abs(qty)
            entry = None
            if not blank(o.get("entry")):
                entry = num(o["entry"], f"{where} entry price")
                if entry < 0:
                    raise PortfolioParseError(f"{where}: entry price is per share and cannot be negative")
                entry = entry or None
            pf.options.append(OptionPosition(s, right, strike, exp, qty, entry))
        return pf


_RIGHTS = {"C": "C", "CALL": "C", "CALLS": "C", "P": "P", "PUT": "P", "PUTS": "P"}


def _parse_option_line(line: str) -> Optional[OptionPosition]:
    toks = [t for t in re.split(r"[\s,]+", line.strip()) if t]
    if not toks:
        return None
    sign = 0
    clean: list = []
    for t in toks:
        u = t.lower()
        if u == "long":
            sign = sign or 1
        elif u == "short":
            sign = sign or -1
        else:
            clean.append(t)
    toks = clean
    qty = None
    right = None
    exp = None
    nums: list = []
    sym = None
    for t in toks:
        u = t.upper().lstrip("@$")
        if u in _RIGHTS and right is None:
            right = _RIGHTS[u]
            continue
        try:
            exp_try = parse_date(t)
            if exp is None and ("-" in t or "/" in t or len(t) in (6, 8)) and not re.fullmatch(r"[+-]?\d+(\.\d+)?", t):
                exp = exp_try
                continue
        except ValueError:
            pass
        if re.fullmatch(r"[+-]?\d+(\.\d+)?", u):
            if qty is None and re.fullmatch(r"[+-]?\d+", t.lstrip("@$")) and not t.startswith("@") and not t.startswith("$"):
                qty = int(t)
            else:
                nums.append(float(u))
            continue
        if sym is None and re.fullmatch(r"[A-Za-z][A-Za-z0-9.]{0,9}", t):
            sym = parse_ticker(t)
            continue
        raise PortfolioParseError(f"cannot read '{t}' in option line '{line}'")
    if None in (sym, right, exp, qty) or not nums:
        return None
    if sign and qty is not None:
        qty = abs(qty) * sign
    strike = nums[0]
    entry = nums[1] if len(nums) > 1 else None
    if qty == 0 or strike <= 0:
        raise PortfolioParseError(f"bad option line '{line}'")
    return OptionPosition(sym, right, strike, exp, qty, entry if (entry and entry > 0) else None)


def parse_portfolio_text(text: str) -> PortfolioContext:
    pf = PortfolioContext(source="text")
    if not text or not text.strip():
        return pf
    for raw in _ITEM_SPLIT.split(text):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        low = line.lower()
        m = re.fullmatch(r"(?:cash[:=\s]*)?\$?\s*([0-9][0-9,._]*\s*[kKmM]?)(?:\s*cash)?", line.strip())
        if low.startswith("cash") or low.endswith("cash"):
            amt = re.sub(r"cash", "", low).strip(" :=")
            try:
                pf.cash += parse_money(amt)
            except ValueError as exc:
                raise PortfolioParseError(f"cash line '{line}': {exc}") from None
            continue
        opt = None
        if re.search(r"\b(C|P|CALLS?|PUTS?)\b", line, re.I) and re.search(r"\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{2,4}", line):
            opt = _parse_option_line(line)
            if opt is None:
                raise PortfolioParseError(f"cannot parse option position '{line}' "
                                          "(use: -1 SPY C 600 2026-12-18 [entry])")
            pf.options.append(opt)
            continue
        m = re.fullmatch(r"\$?([A-Za-z][A-Za-z0-9.]*)[\s:=]+\$?" + _QTY + r"(?:\s*(?:sh|shares?))?", line, re.I)
        m2 = re.fullmatch(_QTY + r"\s*(?:sh|shares?)?\s+\$?([A-Za-z][A-Za-z0-9.]*)(?:\s+shares?)?", line, re.I)
        if m:
            sym, qty = parse_ticker(m.group(1)), _qty(m.group(2))
        elif m2:
            sym, qty = parse_ticker(m2.group(2)), _qty(m2.group(1))
        else:
            raise PortfolioParseError(f"cannot parse '{line}' (examples: 'cash 25000', '100 SPY shares', "
                                      "'1.579 GLD shares', '-1 SPY C 600 2026-12-18 1.20')")
        if sym in CASH_EQUIVALENTS:
            if qty > 0:
                pf.cash_equivalents[sym] = pf.cash_equivalents.get(sym, 0.0) + float(qty)
                pf.notes.append(f"{sym} ({CASH_EQUIVALENTS[sym]}) recorded as a cash equivalent, not a stock: "
                                f"{qty:,} at an assumed $1.00 NAV = ${float(qty):,.2f}. Counted toward cash available "
                                "to secure puts; confirm your broker treats it that way.")
            continue
        if len(sym) == 5 and sym.endswith("XX"):
            raise PortfolioParseError(f"'{sym}' looks like a money-market fund that is not in the known list, so it was "
                                      f"not guessed. If it is a $1.00-NAV sweep fund, enter it as 'cash {qty}'.")
        if qty > 0:
            pf.stocks[sym] = pf.stocks.get(sym, 0) + qty
    return pf
