"""Trade = one or more option legs (plus optional owned shares) evaluated as a single idea."""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Optional

from option_battle.models.option import OptionContract

STRATEGY_NAMES = {
    "long_call": "Long Call", "long_put": "Long Put",
    "covered_call": "Covered Call", "cash_secured_put": "Cash-Secured Put",
    "bull_call_spread": "Bull Call Spread", "bear_put_spread": "Bear Put Spread",
    "call_credit_spread": "Call Credit Spread", "put_credit_spread": "Put Credit Spread",
    "protective_put": "Protective Put", "collar": "Collar",
}


@dataclass
class Leg:
    contract: OptionContract
    side: int            # +1 long, -1 short
    qty: int = 1

    @property
    def action(self) -> str:
        return "BUY" if self.side > 0 else "SELL"


@dataclass
class Trade:
    id: str
    strategy: str
    title: str
    underlying: str
    expiration: dt.date
    dte: int
    spot: float
    legs: list
    primary: int                 # index of the leg that defines the trade (short leg for credit, long leg for debit)
    stock_units: float = 0.0     # +1.0 == 100 shares owned alongside the options
    hypothetical_shares: bool = False
    # per-share net price: positive = debit paid, negative = credit received
    price_mid: float = 0.0
    price_natural: float = 0.0   # worst-case fill (buy at ask, sell at bid)
    price_best: float = 0.0      # best-case fill (buy at bid, sell at ask)
    # position greeks per share of underlying (stock counts 1.0 delta per unit)
    delta: float = 0.0
    gamma: float = 0.0
    theta: float = 0.0
    vega: float = 0.0
    # exact expiry payoff facts (per share)
    max_gain: Optional[float] = None      # None => unbounded
    max_loss: Optional[float] = None      # None => unbounded
    breakevens: list = field(default_factory=list)
    width: float = 0.0
    legs_ok: bool = True
    notes: list = field(default_factory=list)

    @property
    def is_credit(self) -> bool:
        return self.price_mid < 0

    @property
    def credit_mid(self) -> float:
        return max(0.0, -self.price_mid)

    @property
    def debit_mid(self) -> float:
        return max(0.0, self.price_mid)

    @property
    def primary_leg(self) -> Leg:
        return self.legs[self.primary]

    @property
    def strikes_label(self) -> str:
        return "/".join(f"{l.contract.strike:g}{l.contract.right}" for l in self.legs)

    def pnl_expiry(self, s_t: float, price: Optional[float] = None) -> float:
        """Exact per-share P&L at expiry for underlying price s_t (stock measured from entry spot)."""
        p = self.price_mid if price is None else price
        total = 0.0
        for l in self.legs:
            c = l.contract
            intr = max(0.0, s_t - c.strike) if c.right == "C" else max(0.0, c.strike - s_t)
            total += l.side * l.qty * intr
        total += self.stock_units * (s_t - self.spot)
        return total - p
