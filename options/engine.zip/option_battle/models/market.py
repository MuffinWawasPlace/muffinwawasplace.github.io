"""Provider-neutral market data containers."""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Any, Optional

# Bar is reused from the preserved legacy implementation (single definition for the whole project).
from option_battle.legacy.options_suggester import Bar  # noqa: F401


@dataclass
class RawQuote:
    """One option quote in a provider-neutral shape. Providers map their fields into this and nothing else."""
    symbol: str                      # OCC-style contract symbol
    underlying: str
    expiration: dt.date
    right: str                       # "C" | "P"
    strike: float
    bid: float = 0.0
    ask: float = 0.0
    last: float = 0.0
    volume: int = 0
    open_interest: int = 0
    iv: Optional[float] = None
    delta: Optional[float] = None
    gamma: Optional[float] = None
    theta: Optional[float] = None
    vega: Optional[float] = None
    bid_size: int = 0
    ask_size: int = 0
    last_trade_time: str = ""
    raw: dict = field(default_factory=dict)   # untouched provider record (for the analytics debugger)


@dataclass
class MarketSnapshot:
    symbol: str
    provider: str
    spot: Optional[float]
    spot_source: str
    fetched_at_utc: dt.datetime
    chain_timestamp: str = ""
    bars: list = field(default_factory=list)
    history_source: Optional[str] = None
    quotes: list = field(default_factory=list)
    events: list = field(default_factory=list)       # list of dicts, see analytics/events.py
    warnings: list = field(default_factory=list)
    is_mock: bool = False
    dropped_records: dict = field(default_factory=dict)  # reason -> count (malformed provider rows)
    spot_quote: dict = field(default_factory=dict)       # underlying bid / ask / last as observed, and which one was used
    quotes_missing: bool = False                         # chain arrived without usable bid/ask (e.g. around the open)
