"""Normalized internal option representation. All analytics consume this, never provider fields."""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class OptionContract:
    symbol: str
    underlying: str
    expiration: dt.date
    dte: int
    strike: float
    right: str                      # "C" | "P"
    spot: float
    bid: float
    ask: float
    mid: float
    last: float
    volume: int
    open_interest: int
    t_years: float
    iv: Optional[float]
    iv_source: str                  # feed | solved | none
    delta: Optional[float]          # signed, model (Black-Scholes) unless noted by greeks_source
    gamma: Optional[float]
    theta: Optional[float]          # per calendar day, per share
    vega: Optional[float]           # per 1 vol point, per share
    greeks_source: str              # model | feed | none
    feed_iv: Optional[float] = None
    feed_delta: Optional[float] = None
    feed_gamma: Optional[float] = None
    feed_theta: Optional[float] = None
    feed_vega: Optional[float] = None
    solved_iv: Optional[float] = None
    bid_size: int = 0
    ask_size: int = 0
    last_trade_time: str = ""
    intrinsic: float = 0.0
    extrinsic: float = 0.0
    flags: list = field(default_factory=list)
    quality: float = 1.0            # 0..1 quote quality
    usable: bool = True             # False => never used in any candidate
    sellable: bool = True           # False => no valid bid, cannot be a short leg
    raw: dict = field(default_factory=dict)

    @property
    def spread(self) -> float:
        return max(0.0, self.ask - self.bid)

    @property
    def spread_pct(self) -> float:
        return self.spread / self.mid if self.mid > 0 else 1.0

    @property
    def kind(self) -> str:
        return "CALL" if self.right == "C" else "PUT"

    @property
    def label(self) -> str:
        return f"{self.underlying} {self.expiration.isoformat()} {self.strike:g}{self.right}"

    @property
    def abs_delta(self) -> float:
        return abs(self.delta) if self.delta is not None else 0.0

    def to_dict(self, include_raw: bool = False) -> dict:
        d = {k: v for k, v in self.__dict__.items() if k != "raw"}
        d["expiration"] = self.expiration.isoformat()
        d["spread"] = self.spread
        d["spread_pct"] = self.spread_pct
        d["label"] = self.label
        if include_raw:
            d["raw"] = self.raw
        return d


class NormalizedChain:
    """Indexed collection of OptionContract objects for one underlying."""

    def __init__(self, symbol: str, spot: float, contracts: list):
        self.symbol = symbol
        self.spot = spot
        self.contracts = contracts
        self._idx: dict = {}
        for c in contracts:
            self._idx.setdefault((c.expiration, c.right), []).append(c)
        for lst in self._idx.values():
            lst.sort(key=lambda c: c.strike)
        self._by_key = {(c.expiration, c.right, round(c.strike, 3)): c for c in contracts}
        self.diag: dict = {}

    def expirations(self) -> list:
        return sorted({c.expiration for c in self.contracts})

    def get(self, exp: dt.date, right: str, strike: float) -> Optional[OptionContract]:
        return self._by_key.get((exp, right, round(strike, 3)))

    def by_exp_right(self, exp: dt.date, right: str, usable_only: bool = True) -> list:
        lst = self._idx.get((exp, right), [])
        return [c for c in lst if c.usable] if usable_only else list(lst)

    def strikes(self, exp: dt.date, right: str) -> list:
        return [c.strike for c in self._idx.get((exp, right), [])]

    def nearest(self, exp: dt.date, right: str, strike: float, usable_only: bool = True) -> Optional[OptionContract]:
        lst = self.by_exp_right(exp, right, usable_only)
        return min(lst, key=lambda c: abs(c.strike - strike)) if lst else None
