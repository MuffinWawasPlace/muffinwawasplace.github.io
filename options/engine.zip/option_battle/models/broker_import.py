"""Import a broker "positions" CSV export so nobody has to retype holdings.

Columns are found by their header names, never by position, and every row that is not used is listed back to the
user with the reason. Supported:
  * Fidelity  (Accounts > Positions > Download):  Account Name, Symbol, Quantity, Current Value ...
               core/sweep positions are marked with '**' (SPAXX**, FCASH**) and become cash equivalents;
               options look like ' -SPY261218C600' (short sign in Quantity).
  * Any other export with a Symbol (or Ticker) column and a Quantity (or Qty / Shares) column, including
    Schwab, Robinhood, E*TRADE and Vanguard downloads. Title lines above the header row are skipped.
Option symbols are read in Fidelity style (SPY261218C600, -SPY261218C22.5), OCC style (SPY   261218C00600000)
and Schwab style (QQQ 11/20/2026 480.00 P). Anything else is listed as skipped, not guessed.
"""
from __future__ import annotations

import csv
import datetime as dt
import io
import re
from typing import Optional

from option_battle.models.portfolio import CASH_EQUIVALENTS, PortfolioParseError

_SYM = {"symbol", "ticker", "symbolcusip", "instrument"}
_QTY = {"quantity", "qty", "shares", "quantityshares", "units"}
_VAL = {"currentvalue", "marketvalue", "value", "mktval", "marketvaluemktval", "totalvalue", "equity"}

_CASH_WORDS = {"CASH", "CASHCASHINVESTMENTS", "CASHANDCASHINVESTMENTS", "CASHSWEEP", "MONEYMARKET", "CORE"}
_SKIP_WORDS = {"PENDINGACTIVITY", "ACCOUNTTOTAL", "TOTAL", "TOTALS", "GRANDTOTAL"}

_FID_OPT = re.compile(r"^-?\s*([A-Z]{1,6})(\d{2})(\d{2})(\d{2})([CP])(\d+(?:\.\d+)?)$")
_OCC_OPT = re.compile(r"^([A-Z]{1,6})\s*(\d{2})(\d{2})(\d{2})([CP])(\d{8})$")
_SCHWAB_OPT = re.compile(r"^([A-Z]{1,6})\s+(\d{1,2})/(\d{1,2})/(\d{4})\s+(\d+(?:\.\d+)?)\s+([CP])$")
_TICKER = re.compile(r"^[A-Z][A-Z0-9.\-/]{0,9}$")


def _key(s: str) -> str:
    return re.sub(r"[^a-z]", "", str(s).lower())


def _money(s) -> Optional[float]:
    t = str(s or "").strip()
    if t in ("", "--", "-", "n/a", "N/A"):
        return None
    neg = t.startswith("(") and t.endswith(")")
    t = re.sub(r"[,$+()\s]", "", t)
    try:
        v = float(t)
    except ValueError:
        return None
    return -v if neg else v


def parse_option_symbol(sym: str) -> Optional[dict]:
    s = sym.strip().upper()
    m = _SCHWAB_OPT.match(s)
    if m:
        try:
            exp = dt.date(int(m.group(4)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None
        return {"symbol": m.group(1), "right": m.group(6), "strike": float(m.group(5)), "expiration": exp.isoformat()}
    m = _OCC_OPT.match(s)
    if m:
        strike = int(m.group(6)) / 1000.0
    else:
        m = _FID_OPT.match(s)
        if not m:
            return None
        strike = float(m.group(6))
    try:
        exp = dt.date(2000 + int(m.group(2)), int(m.group(3)), int(m.group(4)))
    except ValueError:
        return None
    return {"symbol": m.group(1), "right": m.group(5), "strike": strike, "expiration": exp.isoformat()}


def _is_sym(k: str) -> bool:
    return k in _SYM


def _is_qty(k: str) -> bool:
    return k in _QTY or k.startswith("qty") or k.startswith("quantity")


def _is_val(k: str) -> bool:
    return k in _VAL or "marketvalue" in k or "currentvalue" in k or k.startswith("mktval")


def _find_header(rows: list):
    for i, r in enumerate(rows[:40]):
        keys = [_key(c) for c in r]
        si = next((j for j, k in enumerate(keys) if _is_sym(k)), None)
        qi = next((j for j, k in enumerate(keys) if _is_qty(k)), None)
        if si is not None and qi is not None:
            vi = next((j for j, k in enumerate(keys) if _is_val(k)), None)
            ai = next((keys.index(n) for n in ("accountname", "accountnickname", "account", "accountnumber") if n in keys), None)
            return i, {"sym": si, "qty": qi, "val": vi, "acct": ai}
    return None, None


def _new() -> dict:
    return {"cash": 0.0, "stocks": {}, "options": [], "cash_equivalents": {}}


def parse_positions_csv(text: str) -> dict:
    if not text or not text.strip():
        raise PortfolioParseError("The file is empty.")
    text = text.lstrip("﻿")
    rows = list(csv.reader(io.StringIO(text)))
    hi, col = _find_header(rows)
    if hi is None:
        raise PortfolioParseError("Could not find the column headers. The file needs a 'Symbol' column and a "
                                  "'Quantity' column (a positions download from your broker has both). "
                                  "Or close this and type your holdings into the form instead.")
    fidelity = col["acct"] is not None and any("**" in (r[col["sym"]] if len(r) > col["sym"] else "") for r in rows[hi + 1:])
    accounts: dict = {}
    skipped: list = []
    notes: list = []
    used = 0
    for n, r in enumerate(rows[hi + 1:], hi + 2):
        if len(r) <= max(col["sym"], col["qty"]):
            continue                                      # footer / disclaimer / blank line
        raw = r[col["sym"]].strip()
        if not raw:
            continue
        acct = (r[col["acct"]].strip() if col["acct"] is not None and len(r) > col["acct"] else "") or "Account"
        pf = accounts.setdefault(acct, _new())
        qty = _money(r[col["qty"]])
        val = _money(r[col["val"]]) if col["val"] is not None and len(r) > col["val"] else None
        word = _key(raw).upper()
        if word in _SKIP_WORDS:
            continue
        core = raw.endswith("**")
        sym = raw.rstrip("*").strip().upper()
        if core or sym in CASH_EQUIVALENTS or word in _CASH_WORDS:
            amt = val if val is not None else qty
            if amt is None or amt <= 0:
                skipped.append(f"line {n}: {raw} (no dollar amount)")
                continue
            if word in _CASH_WORDS and not core:
                pf["cash"] += amt
            else:
                pf["cash_equivalents"][sym] = pf["cash_equivalents"].get(sym, 0.0) + amt
            used += 1
            continue
        opt = parse_option_symbol(sym)
        if opt:
            if qty is None or qty == 0 or qty != int(qty):
                skipped.append(f"line {n}: {raw} (contract count '{r[col['qty']]}' not a whole number)")
                continue
            opt["qty"] = int(qty)
            opt["side"] = "short" if qty < 0 else "long"
            opt["contracts"] = abs(int(qty))
            opt["entry"] = None
            pf["options"].append(opt)
            used += 1
            continue
        if not _TICKER.match(sym):
            skipped.append(f"line {n}: {raw} (not a ticker)")
            continue
        if qty is None or qty <= 0:
            skipped.append(f"line {n}: {raw} (quantity '{r[col['qty']]}')")
            continue
        q = int(qty) if qty == int(qty) else qty
        pf["stocks"][sym] = pf["stocks"].get(sym, 0) + q
        used += 1
    if not used:
        raise PortfolioParseError("Found the headers but no holdings under them."
                                  + (" Skipped: " + "; ".join(skipped[:5]) if skipped else ""))
    accounts = {k: v for k, v in accounts.items() if v["stocks"] or v["options"] or v["cash"] or v["cash_equivalents"]}
    combined = _new()
    for pf in accounts.values():
        combined["cash"] += pf["cash"]
        for k, v in pf["stocks"].items():
            combined["stocks"][k] = combined["stocks"].get(k, 0) + v
        for k, v in pf["cash_equivalents"].items():
            combined["cash_equivalents"][k] = combined["cash_equivalents"].get(k, 0.0) + v
        combined["options"].extend(pf["options"])
    if any(o for pf in accounts.values() for o in pf["options"]):
        notes.append("Option entry prices are not in broker exports. Add them in the form if you want P&L.")
    if len(accounts) > 1:
        notes.append("More than one account in the file. Pick one, or keep 'All accounts' to combine them.")
    return {"broker": "Fidelity" if fidelity else "CSV", "accounts": [{"name": k, "portfolio": v} for k, v in accounts.items()],
            "combined": combined, "skipped": skipped, "notes": notes, "rows_used": used}
