"""Request handlers shared by the local server (app.py) and the in-browser site build (webapi.py).
No server or network imports here, so it also runs under Pyodide."""
from __future__ import annotations

from option_battle import ENGINE_NAME, VERSION
from option_battle.backtest.framework import BTParams, run_backtest
from option_battle.core.util import sanitize
from option_battle.data.providers import PROVIDERS, ProviderError
from option_battle.data.providers.mock import MockProvider
from option_battle.engine import AnalysisError, Engine
from option_battle.models.broker_import import parse_positions_csv
from option_battle.models.portfolio import CASH_EQUIVALENTS, PortfolioContext, PortfolioParseError, parse_portfolio_text
from option_battle.models.trade import STRATEGY_NAMES


class Api:
    def __init__(self, engine: Engine) -> None:
        self.engine = engine

    def meta(self) -> dict:
        cfg = self.engine.config()
        return {"engine": ENGINE_NAME, "version": VERSION, "providers": list(PROVIDERS),
                "default_provider": self.engine.default_provider, "scenarios": MockProvider.scenarios(),
                "strategies": STRATEGY_NAMES, "defaults": sanitize(cfg.to_dict()),
                "weights": cfg.weights.normalized(), "money_market_funds": CASH_EQUIVALENTS}

    def analyze(self, body: dict) -> dict:
        return self.engine.analyze(body)

    def trade(self, q: dict) -> dict:
        return self.engine.trade_detail(q.get("aid", ""), q.get("id", ""))

    def compare(self, body: dict) -> dict:
        return self.engine.compare(str(body.get("aid", "")), list(body.get("ids") or []))

    def parse_portfolio(self, body: dict) -> dict:
        try:
            pf = parse_portfolio_text(str(body.get("text", "")))
        except PortfolioParseError as exc:
            return {"ok": False, "error": str(exc)}
        return {"ok": True, "portfolio": sanitize(pf.to_dict())}

    def check_portfolio(self, body: dict) -> dict:
        """Validate the structured form without running an analysis."""
        try:
            pf = PortfolioContext.from_dict(body.get("portfolio"))
        except PortfolioParseError as exc:
            return {"ok": False, "error": str(exc)}
        return {"ok": True, "portfolio": sanitize(pf.to_dict())}

    def import_csv(self, body: dict) -> dict:
        try:
            return {"ok": True, **sanitize(parse_positions_csv(str(body.get("text", ""))))}
        except PortfolioParseError as exc:
            return {"ok": False, "error": str(exc)}

    def backtest(self, body: dict) -> dict:
        symbol = str(body.get("symbol") or "SPY").upper()
        pname = str(body.get("provider") or self.engine.default_provider)
        cfg = self.engine.config(body.get("config"))
        prov = self.engine.provider(pname, cfg, str(body.get("scenario") or "bull_pullback"), int(body.get("seed") or 7))
        try:
            snap = prov.fetch_snapshot(symbol)
        except ProviderError as exc:
            raise AnalysisError(str(exc), "Switch to MOCK to test the framework offline.", 502) from None
        params = BTParams()
        for k, v in (body.get("params") or {}).items():
            if hasattr(params, k) and v not in (None, ""):
                cur = getattr(params, k)
                try:
                    setattr(params, k, type(cur)(v))
                except (TypeError, ValueError):
                    raise AnalysisError(f"bad backtest parameter {k}={v!r}") from None
        try:
            return sanitize(run_backtest(snap.bars, params, symbol, snap.is_mock))
        except ValueError as exc:
            raise AnalysisError(str(exc)) from None
