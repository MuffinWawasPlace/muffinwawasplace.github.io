"""Walk-forward historical validation of the regime gate. Designed to be hard to fool.

What it tests: does skipping new short-premium entries when the regime engine says "hostile" improve outcomes versus
entering every time, holding everything else fixed?

Honesty constraints (all reported with the results):
  * NO historical option quotes exist in the free CBOE/Yahoo/Stooq endpoints. Option prices are MODELLED:
    Black-Scholes with IV = trailing 20d realized vol x `iv_premium` (an ASSUMPTION, default 1.10) and a fixed put
    skew. The test therefore measures the regime gate's effect on timing, not real-world option P&L.
  * Point-in-time: each decision sees `bars[: i + 1]` only (a `PointInTimeView` that raises on any access beyond
    the decision bar). Settlement uses the close of the first bar on/after expiration, which is strictly later.
  * Fills: seller receives mid minus half the assumed spread, buyer pays mid plus half; commission per leg; settlement
    at intrinsic (no early assignment, no dividends).
  * No parameter search. Fixed defaults; the report splits results into first/second half to expose instability.
  * Survivorship: the symbol was chosen today, so its history is conditioned on it still trading.
"""
from __future__ import annotations

import datetime as dt
import math
from dataclasses import asdict, dataclass, field
from typing import Optional

from option_battle.analytics.posture import compute_posture
from option_battle.analytics.regime import classify_regime
from option_battle.analytics.volatility import iv_regime
from option_battle.core.util import mean, median
from option_battle.legacy.options_suggester import bs_delta, bs_price, realized_vol


class LookAheadError(RuntimeError):
    pass


class PointInTimeView:
    """Read-only window onto bars[0..i]. Indexing past the decision bar raises LookAheadError."""

    def __init__(self, bars: list, i: int) -> None:
        self._bars, self._i = bars, i

    def __len__(self) -> int:
        return self._i + 1

    def __getitem__(self, k):
        if isinstance(k, slice):
            if k.stop is not None and k.stop > self._i + 1:
                raise LookAheadError(f"slice to {k.stop} requested at decision bar {self._i}")
            start, stop, step = k.indices(self._i + 1)
            return self._bars[start:stop:step]
        idx = k if k >= 0 else self._i + 1 + k
        if idx < 0 or idx > self._i:
            raise LookAheadError(f"bar {idx} requested at decision bar {self._i}")
        return self._bars[idx]

    def all(self) -> list:
        return self._bars[: self._i + 1]

    @property
    def last_date(self) -> dt.date:
        return self._bars[self._i].date


@dataclass
class BTParams:
    policy: str = "cash_secured_put"      # cash_secured_put | put_credit_spread | covered_call
    dte: int = 30
    target_delta: float = 0.20
    width_pct: float = 0.02               # credit spread width as a fraction of spot
    iv_premium: float = 1.10              # ASSUMPTION: implied = realized x this
    skew: float = 0.10                    # put-skew slope per standard deviation of moneyness
    spread_pct: float = 0.05              # assumed full bid/ask width as a fraction of mid
    min_spread: float = 0.02              # dollars, per leg
    commission: float = 0.65              # per contract per leg
    risk_free: float = 0.043
    warmup: int = 260                     # bars before the first decision (regime needs SMA200 + weekly view)
    recheck_days: int = 5                 # after a skipped (gated) decision, look again this many bars later
    window: int = 400                     # trailing bars passed to the regime engine (speed; still point-in-time)


HOSTILE = {"cash_secured_put": {"Bear Trend", "Breakdown", "High-Volatility Expansion", "Event Risk"},
           "put_credit_spread": {"Bear Trend", "Breakdown", "High-Volatility Expansion", "Event Risk"},
           "covered_call": {"Breakout"}}


def _iv_at(sig: float, S: float, K: float, t: float, skew: float) -> float:
    sd = sig * math.sqrt(max(t, 1e-6))
    x = math.log(K / S) / sd
    return max(0.05, sig * (1.0 - skew * x))


def _strike_for_delta(right: str, S: float, t: float, r: float, sig: float, skew: float, target: float, inc: float) -> float:
    lo, hi = (S * 0.5, S) if right == "P" else (S, S * 1.5)
    for _ in range(60):
        k = 0.5 * (lo + hi)
        d = abs(bs_delta(right, S, k, t, r, 0.0, _iv_at(sig, S, k, t, skew)))
        if right == "P":
            lo, hi = (k, hi) if d < target else (lo, k)
        else:
            lo, hi = (lo, k) if d < target else (k, hi)
    return max(inc, round(0.5 * (lo + hi) / inc) * inc)


def _gate(view: PointInTimeView, p: BTParams) -> tuple:
    bars = view.all()[-p.window:]
    reg = classify_regime(bars, bars[-1].close, None, None)
    closes = [b.close for b in bars]
    rv20 = realized_vol(closes, 20)
    ivr = iv_regime((rv20 or 0) * p.iv_premium if rv20 else None, rv20, realized_vol(closes, 60))
    post = compute_posture(reg, ivr)
    hostile = reg.label in HOSTILE[p.policy]
    if p.policy in ("cash_secured_put", "put_credit_spread") and post.D_eff < -0.10:
        hostile = True
    return (not hostile), reg.label, post.D_eff


def _trade(bars: list, i: int, j: int, p: BTParams) -> Optional[dict]:
    S = bars[i].close
    closes = [b.close for b in bars[: i + 1]]
    rv = realized_vol(closes, 20)
    if not rv:
        return None
    sig = rv * p.iv_premium
    t = p.dte / 365.0
    inc = 1.0 if S >= 100 else 0.5
    S_T = bars[j].close
    cost = lambda mid: max(p.min_spread, p.spread_pct * mid) / 2.0
    if p.policy in ("cash_secured_put", "put_credit_spread"):
        K = _strike_for_delta("P", S, t, p.risk_free, sig, p.skew, p.target_delta, inc)
        mid_s = bs_price("P", S, K, t, p.risk_free, 0.0, _iv_at(sig, S, K, t, p.skew))
        credit = mid_s - cost(mid_s)
        legs = 1
        payout = max(0.0, K - S_T)
        capital = K * 100.0
        if p.policy == "put_credit_spread":
            K2 = max(inc, K - max(inc, round(S * p.width_pct / inc) * inc))
            mid_l = bs_price("P", S, K2, t, p.risk_free, 0.0, _iv_at(sig, S, K2, t, p.skew))
            credit -= mid_l + cost(mid_l)
            legs = 2
            payout -= max(0.0, K2 - S_T)
            capital = (K - K2) * 100.0 - credit * 100.0
            if credit <= 0:
                return None
        pnl = (credit - payout) * 100.0 - p.commission * legs
        strikes = [K] if legs == 1 else [K, K2]
    else:
        K = _strike_for_delta("C", S, t, p.risk_free, sig, p.skew, p.target_delta, inc)
        mid_c = bs_price("C", S, K, t, p.risk_free, 0.0, _iv_at(sig, S, K, t, p.skew))
        credit = mid_c - cost(mid_c)
        pnl = ((S_T - S) + credit - max(0.0, S_T - K)) * 100.0 - p.commission
        capital = S * 100.0
        strikes = [K]
    return {"entry_date": bars[i].date.isoformat(), "settle_date": bars[j].date.isoformat(), "spot": S, "settle": S_T,
            "strikes": strikes, "credit": credit, "iv_used": sig, "pnl": pnl, "capital": capital,
            "roc": pnl / capital if capital > 0 else None}


def _settle_index(bars: list, i: int, dte: int) -> Optional[int]:
    target = bars[i].date + dt.timedelta(days=dte)
    for j in range(i + 1, len(bars)):
        if bars[j].date >= target:
            return j
    return None


def _stats(trades: list, years: float) -> dict:
    if not trades:
        return {"n": 0}
    pnl = [t["pnl"] for t in trades]
    cum, peak, mdd = 0.0, 0.0, 0.0
    curve = []
    for t in trades:
        cum += t["pnl"]
        peak = max(peak, cum)
        mdd = min(mdd, cum - peak)
        curve.append({"date": t["settle_date"], "cum": cum})
    cap = mean([t["capital"] for t in trades]) or 0.0
    return {"n": len(trades), "win_rate": sum(1 for x in pnl if x > 0) / len(pnl), "avg_pnl": mean(pnl),
            "median_pnl": median(pnl), "worst": min(pnl), "best": max(pnl), "total": sum(pnl),
            "max_drawdown": mdd, "avg_capital": cap,
            "return_on_avg_capital_annualized": (sum(pnl) / cap / years) if (cap > 0 and years > 0) else None,
            "curve": curve}


def run_backtest(bars: list, params: Optional[BTParams] = None, symbol: str = "", is_mock: bool = False) -> dict:
    p = params or BTParams()
    if p.policy not in HOSTILE:
        raise ValueError(f"unknown policy {p.policy}")
    n = len(bars)
    if n < p.warmup + p.dte + 30:
        return {"available": False, "note": f"{n} bars: need at least {p.warmup + p.dte + 30} for a {p.dte}-DTE walk-forward"}
    out: dict = {"available": True, "symbol": symbol, "params": asdict(p), "is_mock": is_mock}
    runs: dict = {}
    for mode in ("gated", "always"):
        i, trades, skipped = p.warmup, [], []
        while i < n:
            j = _settle_index(bars, i, p.dte)
            if j is None:
                break
            view = PointInTimeView(bars, i)
            ok, label, d_eff = _gate(view, p) if mode == "gated" else (True, None, None)
            if not ok:
                skipped.append({"date": bars[i].date.isoformat(), "regime": label, "D_eff": d_eff})
                i += p.recheck_days
                continue
            tr = _trade(bars, i, j, p)
            if tr:
                tr["regime_at_entry"] = label
                tr["information_cutoff"] = bars[i].date.isoformat()
                trades.append(tr)
            i = j                                    # non-overlapping: next decision on the settlement bar
        runs[mode] = {"trades": trades, "skipped": skipped}
    span_years = max(1e-9, (bars[-1].date - bars[p.warmup].date).days / 365.25)
    for mode, rr in runs.items():
        tr = rr["trades"]
        half = len(tr) // 2
        rr["stats"] = _stats(tr, span_years)
        rr["first_half"] = {k: v for k, v in _stats(tr[:half], span_years / 2).items() if k != "curve"}
        rr["second_half"] = {k: v for k, v in _stats(tr[half:], span_years / 2).items() if k != "curve"}
    out["runs"] = runs
    g, a = runs["gated"]["stats"], runs["always"]["stats"]
    verdict = "insufficient trades to compare (< 8 in either run)"
    if g.get("n", 0) >= 8 and a.get("n", 0) >= 8:
        dv = (g["avg_pnl"] - a["avg_pnl"])
        verdict = (f"gate changed average P&L per trade by ${dv:+,.0f} and max drawdown from ${a['max_drawdown']:,.0f} "
                   f"to ${g['max_drawdown']:,.0f}; with n={g['n']}/{a['n']} this is weak evidence either way")
    out["verdict"] = verdict
    out["caveats"] = [
        "Option prices are MODELLED (Black-Scholes, IV = trailing RV20 x iv_premium assumption, fixed skew): no "
        "historical option quotes are available from the configured endpoints.",
        "Fills assume half of a modelled bid/ask spread plus commission; real fills on illiquid strikes are worse.",
        "Settlement at intrinsic on the first close on/after expiration; early assignment and dividends ignored.",
        "Point-in-time: each decision uses only bars up to that day (enforced by PointInTimeView).",
        "No parameter optimisation was performed; first/second-half splits are shown to expose instability.",
        "Survivorship: the symbol was chosen today; delisted or collapsed names are not in the sample.",
    ] + (["MOCK DATA: synthetic price history; results describe the simulator, not any market."] if is_mock else [])
    return out
