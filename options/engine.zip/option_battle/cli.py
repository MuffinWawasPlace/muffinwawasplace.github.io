"""Terminal battle board (phone-width text) for quick checks in Termux without a browser."""
from __future__ import annotations

import textwrap

W = 60


def _bar(score: float, width: int = 17) -> str:
    n = int(round(max(0.0, min(100.0, score)) / 100.0 * width))
    return "█" * n + "░" * (width - n)


def print_board(engine, symbol: str, provider: str, scenario: str = "bull_pullback") -> int:
    from option_battle.engine import AnalysisError
    try:
        r = engine.analyze({"symbol": symbol, "provider": provider, "scenario": scenario})
    except AnalysisError as exc:
        print(f"ERROR: {exc}\n{exc.hint}")
        return 2
    u, rg, h = r["underlying"], r["regime"], r["headline"]
    em = rg["expected_move"]
    L = ["=" * W, f" WAWAS OPTIONS SUGGESTER   {u['symbol']} ${u['spot']:,.2f}" + ("  [MOCK]" if u["is_mock"] else ""), "=" * W,
         f" REGIME        {rg['label']}", f" CONFIDENCE    {rg['confidence'] * 100:.0f}%  (agreement index)",
         f" IV REGIME     {rg['iv_regime']['level']}",
         f" EXPECTED MOVE " + (f"+/-{em['pct'] * 100:.1f}% to {em['focus_expiration']} ({em['dte']} DTE)" if em.get("pct") else "n/a")]
    for ar in r["arenas"]:
        k = ar["default"]
        parts = [p for p in ar["participants"].get(k, []) if not p["disqualified"]]
        exp = next((s["best_expiration"] for s in ar["strategies"] if s["key"] == k), None)
        parts = [p for p in parts if p["expiration"] == exp][:4]
        L += ["", f" {ar['title'].upper()}  ({k.replace('_', ' ')}, {exp})"]
        for p in parts:
            L.append(f"  {p['label']:<12}{_bar(p['score'])} {p['score']:5.1f} {p['status']}")
    if h:
        z = h.get("zone") or {}
        L += ["", "-" * W, " HIGHEST-RANKED SETUP", f"  {h['action']}  {h['expiration']} ({h['dte']} DTE)",
              f"  TRADE QUALITY {h['score']:.0f}/100   ENTRY STATUS {h['status']}",
              f"  CURRENT MID   ${z.get('mid', 0):.2f}   PREFERRED LIMIT ${z.get('preferred', 0):.2f}"]
        if z.get("acceptable"):
            L.append(f"  ACCEPTABLE    ${z['acceptable'][0]:.2f}-${z['acceptable'][1]:.2f}")
        if z.get("worst_acceptable") is not None:
            L.append(f"  {z['label_worst'].upper()} ${z['worst_acceptable']:.2f}")
        L.append(f"  INVALIDATION  {h['invalidation']['text']}")
        L += ["", "  WHY IT RANKED HIGH"] + [textwrap.fill(w, W, initial_indent="   * ", subsequent_indent="     ") for w in h["why"]]
        L += ["", "  WHAT COULD BREAK IT"] + [textwrap.fill(w, W, initial_indent="   * ", subsequent_indent="     ") for w in h["breaks"][:5]]
        if h.get("wait_condition"):
            L += ["", textwrap.fill(h["wait_condition"], W, initial_indent="  ", subsequent_indent="  ")]
    L += ["", textwrap.fill(r["meta"]["disclaimer"], W, initial_indent=" ", subsequent_indent=" "), "=" * W]
    print("\n".join(L))
    return 0
