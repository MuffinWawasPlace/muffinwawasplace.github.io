"""Central configuration. Everything tunable lives here; nothing is hidden in the analytics code.

Overrides can come from a JSON file (env OPTION_BATTLE_CONFIG) or from the UI/API at runtime.
"""
from __future__ import annotations

import dataclasses
import json
import logging
import os
from dataclasses import asdict, dataclass, field
from typing import Any

LOG = logging.getLogger("option_battle.config")


@dataclass
class ScoreWeights:
    """Trade Quality Score weights. Normalized to sum to 100 at scoring time."""
    regime_fit: float = 18.0
    liquidity: float = 14.0
    vol_edge: float = 14.0
    technical_fit: float = 14.0
    risk_reward: float = 14.0
    theta_profile: float = 8.0
    delta_fit: float = 10.0
    entry_quality: float = 8.0

    def normalized(self) -> dict[str, float]:
        d = {k: max(0.0, float(v)) for k, v in asdict(self).items()}
        tot = sum(d.values())
        if tot <= 0:
            d = asdict(ScoreWeights())
            tot = sum(d.values())
        return {k: v * 100.0 / tot for k, v in d.items()}


@dataclass
class Limits:
    """Position-sizing / portfolio guard rails. Percentages are fractions of portfolio equity."""
    max_trade_risk_pct: float = 0.05        # capital at risk per trade
    max_trade_risk_usd: float = 0.0         # optional absolute cap (0 = off)
    max_underlying_conc_broad: float = 0.60  # delta-dollar exposure, broad index groups
    max_underlying_conc_other: float = 0.25  # single names / sector funds
    max_expiration_conc: float = 0.30       # capital at risk expiring on the same date
    max_portfolio_delta_pct: float = 1.00   # |delta dollars| / equity
    max_portfolio_vega_pct: float = 0.005   # |vega dollars per vol point| / equity
    max_contracts_table: int = 10           # rows in the sizing table


def _default_delta_bands() -> dict[str, tuple[float, float]]:
    return {
        "cash_secured_put": (0.15, 0.30), "covered_call": (0.15, 0.30),
        "put_credit_spread": (0.15, 0.30), "call_credit_spread": (0.15, 0.30),
        "long_call": (0.45, 0.70), "long_put": (0.45, 0.70),
        "bull_call_spread": (0.45, 0.65), "bear_put_spread": (0.45, 0.65),
        "protective_put": (0.20, 0.40), "collar": (0.15, 0.30),
    }


@dataclass
class Config:
    # pricing model inputs (CBOE does not supply these; user can override)
    risk_free: float = 0.043
    div_yield: float = 0.0
    div_yields: dict = field(default_factory=dict)  # per-symbol override, e.g. {"SPY": 0.012}
    pricing_model: str = "black_scholes"
    # expiration window / selection
    dte_min: int = 7
    dte_max: int = 60
    max_expirations: int = 4
    allow_weeklies: bool = True
    # candidate generation (absolute delta ranges of the primary leg)
    short_delta_range: tuple = (0.05, 0.40)
    long_delta_range: tuple = (0.30, 0.80)
    delta_bands: dict = field(default_factory=_default_delta_bands)
    max_candidates_per_strategy: int = 60
    # hard quality gates
    min_open_interest: int = 10
    max_spread_pct: float = 0.30
    spread_abs_ok: float = 0.05
    min_short_mid: float = 0.10
    min_em_ratio_short: float = 0.40
    extreme_spread_pct: float = 0.60
    # decision thresholds (on 0-100 Trade Quality)
    enter_threshold: float = 62.0
    avoid_threshold: float = 45.0
    wide_spread_pct: float = 0.08
    better_peer_margin: float = 8.0
    low_regime_confidence: float = 0.45
    # entry-price engine
    tick: float = 0.01                     # minimum price increment used when rounding limit prices
    fair_vol_multiple: float = 1.10        # "fair" vol = realized-vol blend x this (tolerates a normal ~10% vol premium)
    closed_market_wait: bool = False       # True: any analysis run while the market is closed reports WAIT
    include_hypothetical: bool = True      # rank share/cash-requiring strategies even when the portfolio can't fund them
    max_ranked_rows: int = 40
    # misc
    cache_ttl_seconds: int = 90
    stale_minutes: float = 30.0            # chain older than this while the market is open is flagged STALE
    preferred_dte: int = 30                # headline expected-move horizon
    events_file: str = ""
    weights: ScoreWeights = field(default_factory=ScoreWeights)
    limits: Limits = field(default_factory=Limits)

    def div_for(self, symbol: str) -> float:
        return float(self.div_yields.get(symbol.upper(), self.div_yield))

    def to_dict(self) -> dict:
        return asdict(self)


def _merge(obj: Any, overrides: dict) -> Any:
    """Apply a nested override dict onto a dataclass instance (unknown keys ignored, types coerced)."""
    if not dataclasses.is_dataclass(obj):
        return overrides
    names = {f.name: f for f in dataclasses.fields(obj)}
    for k, v in (overrides or {}).items():
        if k not in names:
            LOG.warning("ignoring unknown config key %r", k)
            continue
        cur = getattr(obj, k)
        try:
            if dataclasses.is_dataclass(cur) and isinstance(v, dict):
                _merge(cur, v)
            elif isinstance(cur, bool):
                setattr(obj, k, bool(v))
            elif isinstance(cur, int) and not isinstance(cur, bool):
                setattr(obj, k, int(v))
            elif isinstance(cur, float):
                setattr(obj, k, float(v))
            elif isinstance(cur, tuple):
                setattr(obj, k, tuple(float(x) for x in v))
            elif isinstance(cur, dict) and isinstance(v, dict):
                if k == "delta_bands":
                    cur.update({kk: (float(vv[0]), float(vv[1])) for kk, vv in v.items()})
                else:
                    cur.update(v)
            else:
                setattr(obj, k, v)
        except (TypeError, ValueError):
            LOG.warning("bad value for config key %r: %r", k, v)
    return obj


def load_config(overrides: dict | None = None, path: str | None = None) -> Config:
    cfg = Config()
    path = path or os.environ.get("OPTION_BATTLE_CONFIG", "")
    if path and os.path.exists(path):
        try:
            with open(path, "r", encoding="utf-8") as fh:
                _merge(cfg, json.load(fh))
        except (OSError, ValueError) as exc:
            LOG.warning("could not read config %s: %s", path, exc)
    if overrides:
        _merge(cfg, overrides)
    return cfg
