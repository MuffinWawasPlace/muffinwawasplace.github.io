"""Small numeric helpers. Basic safe-math primitives are reused from the preserved legacy script
(single definition for the whole project); statistics helpers are added here (pure Python, no numpy)."""
from __future__ import annotations

import math
from typing import Iterable, Optional, Sequence

from option_battle.legacy.options_suggester import clamp, lin, safe_float, safe_int  # noqa: F401


def finite(x: object) -> bool:
    try:
        return x is not None and math.isfinite(float(x))  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return False


def mean(xs: Sequence[float]) -> Optional[float]:
    return sum(xs) / len(xs) if xs else None


def median(xs: Iterable[float]) -> Optional[float]:
    s = sorted(xs)
    n = len(s)
    if n == 0:
        return None
    return s[n // 2] if n % 2 else 0.5 * (s[n // 2 - 1] + s[n // 2])


def stdev(xs: Sequence[float]) -> Optional[float]:
    n = len(xs)
    if n < 2:
        return None
    m = sum(xs) / n
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (n - 1))


def percentile(xs: Iterable[float], p: float) -> Optional[float]:
    """Linear-interpolated percentile, p in [0, 100]."""
    s = sorted(xs)
    if not s:
        return None
    if len(s) == 1:
        return s[0]
    k = (len(s) - 1) * clamp(p / 100.0)
    lo, hi = int(math.floor(k)), int(math.ceil(k))
    return s[lo] if lo == hi else s[lo] + (s[hi] - s[lo]) * (k - lo)


def rank_of(xs: Sequence[float], value: float) -> Optional[float]:
    """Fraction of observations <= value (empirical percentile rank, 0..1)."""
    if not xs:
        return None
    return sum(1 for v in xs if v <= value) / len(xs)


def autocorr(xs: Sequence[float], lag: int = 1) -> Optional[float]:
    n = len(xs)
    if n < lag + 5:
        return None
    m = sum(xs) / n
    den = sum((x - m) ** 2 for x in xs)
    if den <= 0:
        return None
    num = sum((xs[i] - m) * (xs[i - lag] - m) for i in range(lag, n))
    return num / den


def round_or_none(x: Optional[float], d: int = 4) -> Optional[float]:
    return None if not finite(x) else round(float(x), d)  # type: ignore[arg-type]


def sanitize(obj):
    """Recursively make an object JSON-safe: NaN/Inf -> None, dates -> ISO strings, dataclasses -> dicts."""
    import dataclasses
    import datetime as dt

    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return sanitize(dataclasses.asdict(obj))
    if isinstance(obj, dict):
        return {str(k): sanitize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [sanitize(v) for v in obj]
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, (dt.date, dt.datetime)):
        return obj.isoformat()
    return obj
