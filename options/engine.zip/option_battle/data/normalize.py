"""RawQuote -> OptionContract normalization + data-integrity safeguards.

This is the only layer that interprets raw numbers. Everything downstream consumes `OptionContract` and may assume:
  * all numeric fields are finite
  * `usable` is False for anything that must never appear in a candidate (crossed, no ask, expired, impossible
    price, extreme spread)
  * `sellable` is False when there is no valid bid (cannot be a short leg)
  * every irregularity is named in `flags`, nothing is silently repaired

Greeks policy: feed Greeks are KEPT (`feed_*`) but the Greeks used by the engine are model values computed from the
resolved IV (feed IV preferred, otherwise solved from the mid), so scoring never trusts an unverified feed number.
Disagreement between feed and model delta beyond 0.08 is flagged.
"""
from __future__ import annotations

import datetime as dt
import math
from typing import Optional

from option_battle.analytics.greeks import BlackScholes, solve_iv
from option_battle.config import Config
from option_battle.core.util import clamp, lin
from option_battle.legacy.options_suggester import to_et, utc_now, years_to_expiry
from option_battle.models.market import MarketSnapshot, RawQuote
from option_battle.models.option import NormalizedChain, OptionContract

_BS = BlackScholes()


def _finite(x) -> bool:
    return isinstance(x, (int, float)) and math.isfinite(x)


def market_session(now_u: dt.datetime) -> str:
    """'open' during regular US hours (09:30-16:00 ET, Mon-Fri; exchange holidays are not modelled)."""
    et = to_et(now_u)
    if et.weekday() >= 5:
        return "closed"
    mins = et.hour * 60 + et.minute
    return "open" if 9 * 60 + 30 <= mins < 16 * 60 else "closed"


def _parse_ts(s: str, now_u: dt.datetime) -> Optional[dt.datetime]:
    s = (s or "").strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%d %H:%M"):
        try:
            naive = dt.datetime.strptime(s[:26], fmt)
        except ValueError:
            continue
        et_now = to_et(now_u)
        return naive.replace(tzinfo=et_now.tzinfo).astimezone(dt.timezone.utc)
    try:
        d = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=dt.timezone.utc)
    except ValueError:
        return None


def snapshot_freshness(snap: MarketSnapshot, cfg: Config, now_u: dt.datetime) -> dict:
    sess = market_session(now_u)
    ts = _parse_ts(snap.chain_timestamp, now_u)
    age = (now_u - ts).total_seconds() / 60.0 if ts else None
    out = {"market_session": sess, "chain_timestamp": snap.chain_timestamp, "age_minutes": age, "stale": False,
           "note": ""}
    if snap.is_mock:
        out["note"] = "MOCK data: freshness not applicable"
    elif age is None:
        out["note"] = "chain timestamp missing or unparseable: freshness UNKNOWN"
    elif sess == "open" and age > cfg.stale_minutes:
        out["stale"] = True
        out["note"] = f"chain is {age:.0f} min old while the market is open (> {cfg.stale_minutes:.0f} min): STALE"
    elif sess == "closed":
        out["note"] = "market closed: quotes reflect the last session, not live prices"
    else:
        out["note"] = f"chain age {age:.0f} min (delayed feed)"
    return out


def normalize_quote(rq: RawQuote, spot: float, cfg: Config, now_u: dt.datetime, today: dt.date,
                    stale_chain: bool = False) -> OptionContract:
    flags: list = []
    right = rq.right
    S, K = spot, rq.strike
    bid, ask = rq.bid, rq.ask
    for nm, v in (("bid", bid), ("ask", ask)):
        if not _finite(v):
            flags.append("nan_field:" + nm)
    bid = bid if _finite(bid) else 0.0
    ask = ask if _finite(ask) else 0.0
    if bid < 0 or ask < 0:
        flags.append("negative_price")
        bid, ask = max(0.0, bid), max(0.0, ask)
    last = rq.last if _finite(rq.last) and rq.last > 0 else 0.0

    dte = (rq.expiration - today).days
    usable = True
    if dte < 0:
        flags.append("expired")
        usable = False
    t = years_to_expiry(rq.expiration, now_u) if dte >= 0 else 0.0

    crossed = 0 < ask < bid
    if crossed:
        flags.append("crossed_market")
        usable = False
    if ask <= 0:
        flags.append("no_ask" if bid > 0 else "no_quote")
        usable = False
    sellable = bid > 0 and not crossed
    if bid <= 0 < ask:
        flags.append("zero_bid")
    mid = (bid + ask) / 2.0 if (ask > 0 and not crossed) else 0.0
    spread = max(0.0, ask - bid)
    spread_pct = spread / mid if mid > 0 else 1.0
    if mid > 0 and spread_pct > cfg.extreme_spread_pct and spread > cfg.spread_abs_ok:
        flags.append("extreme_spread")
        usable = False
    elif mid > 0 and spread_pct > cfg.max_spread_pct and spread > cfg.spread_abs_ok:
        flags.append("wide_spread")

    intrinsic = max(0.0, S - K) if right == "C" else max(0.0, K - S)
    cap = S * 1.0 if right == "C" else K                   # a call can never be worth more than the stock; a put more than K
    if ask > cap * 1.02 and ask > 0:
        flags.append("impossible_price")
        usable = False
    if mid > 0 and bid > 0 and mid < intrinsic - max(0.05, 0.003 * K):
        flags.append("below_intrinsic")
    extrinsic = max(0.0, mid - intrinsic)

    iv, iv_src, solved = None, "none", None
    feed_iv = rq.iv if (rq.iv is not None and _finite(rq.iv)) else None
    if feed_iv is not None and 0.01 < feed_iv < 5.0:
        iv, iv_src = feed_iv, "feed"
    elif "nan_field:iv" in flags:
        pass
    if iv is None and mid > 0 and bid > 0 and t > 0 and not crossed:
        solved = solve_iv(right, mid, S, K, t, cfg.risk_free, cfg.div_for(rq.underlying))
        if solved and 0.01 < solved < 5.0:
            iv, iv_src = solved, "solved"
            flags.append("iv_solved")
    if rq.iv is not None and not _finite(rq.iv):
        flags.append("nan_field:iv")
    if iv is None:
        flags.append("iv_missing")

    delta = gamma = theta = vega = None
    g_src = "none"
    if iv is not None and t > 0:
        g = _BS.greeks(right, S, K, t, cfg.risk_free, cfg.div_for(rq.underlying), iv)
        delta, gamma, theta, vega, g_src = g.delta, g.gamma, g.theta, g.vega, "model"
        if rq.delta is not None and _finite(rq.delta) and abs(g.delta - rq.delta) > 0.08:
            flags.append("feed_delta_mismatch")
    elif rq.delta is not None and _finite(rq.delta):
        delta, gamma, theta, vega, g_src = rq.delta, rq.gamma, rq.theta, rq.vega, "feed"

    if last > 0 and rq.volume == 0 and stale_chain:
        flags.append("stale_last_trade")
    if stale_chain:
        flags.append("stale_chain")

    q = 1.0
    q -= 0.5 * lin(spread_pct, 0.02, 0.40) if mid > 0 else 0.5
    pen = {"zero_bid": 0.25, "below_intrinsic": 0.20, "iv_missing": 0.15, "iv_solved": 0.03, "stale_chain": 0.15,
           "feed_delta_mismatch": 0.05, "wide_spread": 0.05}
    for f in flags:
        q -= pen.get(f, 0.10 if f.startswith("nan_field") else 0.0)
    quality = round(clamp(q), 3)
    if not usable:
        quality = 0.0

    return OptionContract(
        symbol=rq.symbol, underlying=rq.underlying, expiration=rq.expiration, dte=dte, strike=K, right=right,
        spot=S, bid=bid, ask=ask, mid=mid, last=last, volume=max(0, int(rq.volume or 0)),
        open_interest=max(0, int(rq.open_interest or 0)), t_years=t, iv=iv, iv_source=iv_src,
        delta=delta, gamma=gamma, theta=theta, vega=vega, greeks_source=g_src,
        feed_iv=feed_iv, feed_delta=rq.delta if (rq.delta is not None and _finite(rq.delta)) else None,
        feed_gamma=rq.gamma if (rq.gamma is not None and _finite(rq.gamma)) else None,
        feed_theta=rq.theta if (rq.theta is not None and _finite(rq.theta)) else None,
        feed_vega=rq.vega if (rq.vega is not None and _finite(rq.vega)) else None, solved_iv=solved,
        bid_size=rq.bid_size, ask_size=rq.ask_size, last_trade_time=rq.last_trade_time,
        intrinsic=intrinsic, extrinsic=extrinsic, flags=flags, quality=quality, usable=usable,
        sellable=sellable and usable, raw=rq.raw)


def normalize_snapshot(snap: MarketSnapshot, cfg: Config, now_u: Optional[dt.datetime] = None,
                       today: Optional[dt.date] = None) -> NormalizedChain:
    now_u = now_u or utc_now()
    today = today or to_et(now_u).date()
    spot = snap.spot
    if not spot or not _finite(spot) or spot <= 0:
        raise ValueError("snapshot has no valid underlying price")
    fresh = snapshot_freshness(snap, cfg, now_u)
    contracts: list = []
    flag_counts: dict = {}
    for rq in snap.quotes:
        try:
            c = normalize_quote(rq, spot, cfg, now_u, today, stale_chain=fresh["stale"])
        except Exception as exc:  # one malformed row must never take down the run
            flag_counts["normalize_error"] = flag_counts.get("normalize_error", 0) + 1
            continue
        contracts.append(c)
        for f in c.flags:
            flag_counts[f] = flag_counts.get(f, 0) + 1
    chain = NormalizedChain(snap.symbol, spot, contracts)
    chain.diag = {"input_records": len(snap.quotes), "contracts": len(contracts),
                  "usable": sum(1 for c in contracts if c.usable), "flag_counts": flag_counts,
                  "dropped_at_provider": dict(snap.dropped_records), "freshness": fresh}
    return chain
