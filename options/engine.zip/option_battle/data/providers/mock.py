"""Mock provider: deterministic synthetic market so the whole application runs with no network and no credentials.

EVERYTHING produced here is synthetic and is labelled `MOCK` throughout the UI and API. It is built to exercise
the analytics, not to resemble any real instrument's history:

* daily bars come from a seeded phase model (trend / pullback / range / breakout / vol-expansion / ...)
* the chain is priced with Black-Scholes using a smile + term structure, then wrapped in the CBOE record shape
  and pushed through the SAME mapper the live CBOE provider uses (`map_cboe_chain`)
* a handful of deliberately malformed records are injected so validation safeguards are visibly exercised

Scenarios: bull_pullback (default), bear_rally, bull_trend, bear_trend, range, breakout, breakdown,
high_vol, compression, overextended.
"""
from __future__ import annotations

import datetime as dt
import math
import random
from typing import Optional

from option_battle.analytics.greeks import BlackScholes
from option_battle.config import Config
from option_battle.data.providers.base import MarketDataProvider
from option_battle.data.providers.cboe import map_cboe_chain
from option_battle.legacy.options_suggester import realized_vol, third_friday, to_et, utc_now
from option_battle.models.market import Bar, MarketSnapshot

# phase: (days, daily_drift, daily_vol, mode)   mode: "walk" | "range"
SCENARIOS: dict = {
    "bull_pullback": {"phases": [(470, 0.00055, 0.0072, "walk"), (110, 0.0009, 0.0062, "walk"), (9, -0.0042, 0.0080, "walk")],
                      "iv_mult": 1.32, "desc": "Long uptrend, strong run, short sharp pullback; IV rich vs realized"},
    "bear_rally": {"phases": [(470, -0.00035, 0.0090, "walk"), (110, -0.0011, 0.0085, "walk"), (8, 0.0040, 0.0085, "walk")],
                   "iv_mult": 1.20, "desc": "Long downtrend with a short counter-trend rally"},
    "bull_trend": {"phases": [(500, 0.00060, 0.0072, "walk"), (160, 0.00085, 0.0058, "walk")],
                   "iv_mult": 1.05, "desc": "Steady calm uptrend; IV near realized"},
    "bear_trend": {"phases": [(500, -0.00030, 0.0090, "walk"), (160, -0.0011, 0.0105, "walk")],
                   "iv_mult": 1.15, "desc": "Persistent downtrend"},
    "range": {"phases": [(420, 0.0003, 0.0085, "walk"), (240, 0.0, 0.0068, "range")],
              "iv_mult": 1.22, "desc": "Sideways mean-reverting range"},
    "breakout": {"phases": [(420, 0.0002, 0.0075, "walk"), (230, 0.0, 0.0050, "range"), (3, 0.0085, 0.0110, "walk")],
                 "iv_mult": 1.00, "desc": "Tight range then an upside range-expansion break"},
    "breakdown": {"phases": [(420, 0.0003, 0.0075, "walk"), (230, 0.0, 0.0050, "range"), (3, -0.0090, 0.0115, "walk")],
                  "iv_mult": 1.10, "desc": "Tight range then a downside break"},
    "high_vol": {"phases": [(500, 0.0004, 0.0075, "walk"), (14, -0.0010, 0.0240, "walk")],
                 "iv_mult": 1.05, "desc": "Volatility expansion / stress"},
    "compression": {"phases": [(500, 0.0003, 0.0090, "walk"), (60, 0.0001, 0.0020, "range")],
                    "iv_mult": 1.45, "desc": "Volatility compression after a volatile stretch"},
    "overextended": {"phases": [(500, 0.0005, 0.0070, "walk"), (14, 0.0092, 0.0045, "walk")],
                     "iv_mult": 1.10, "desc": "Parabolic run well above trend"},
}

# symbol -> (spot, daily-vol scale). Synthetic reference levels only.
MOCK_UNIVERSE = {"SPY": (601.42, 1.0), "QQQ": (528.30, 1.25), "IWM": (232.15, 1.35), "AAPL": (226.80, 1.6),
                 "NVDA": (131.40, 3.0), "TSLA": (248.10, 3.4), "MSFT": (432.60, 1.5), "AMD": (158.20, 2.6)}


def _weekday_back(d: dt.date) -> dt.date:
    while d.weekday() >= 5:
        d -= dt.timedelta(days=1)
    return d


def _weekdays_ending(end: dt.date, n: int) -> list:
    out, d = [], end
    while len(out) < n:
        if d.weekday() < 5:
            out.append(d)
        d -= dt.timedelta(days=1)
    return out[::-1]


def generate_bars(symbol: str, scenario: str, seed: int, today: dt.date, spot_target: float, vol_scale: float) -> list:
    sc = SCENARIOS.get(scenario) or SCENARIOS["bull_pullback"]
    rng = random.Random(f"{symbol}|{scenario}|{seed}")
    total = sum(p[0] for p in sc["phases"])
    dates = _weekdays_ending(_weekday_back(today), total)
    x = 0.0
    logp: list = []
    vols: list = []
    for days, drift, vol, mode in sc["phases"]:
        vol *= vol_scale
        mean_x = x
        # "walk" phases are noise-bridged in short blocks: noise is de-meaned inside each block so the path hugs the
        # designed drift (day-to-day noise is kept). Without this, random noise swamps the drift and scenarios stop
        # meaning what they say.
        eps = [vol * rng.gauss(0, 1) for _ in range(days)]
        block = min(10, days)
        for b0 in range(0, days, block):
            seg = eps[b0:b0 + block]
            m = sum(seg) / len(seg)
            eps[b0:b0 + block] = [e - m for e in seg]
        for i in range(days):
            if mode == "range":
                x += 0.10 * (mean_x - x) + eps[i]
            else:
                x += drift + eps[i]
            logp.append(x)
            vols.append(vol)
    scale = spot_target / math.exp(logp[-1])
    closes = [scale * math.exp(v) for v in logp]
    bars: list = []
    prev = closes[0] / math.exp(logp[1] - logp[0]) if len(closes) > 1 else closes[0]
    for i, d in enumerate(dates):
        v = vols[i]
        gap = rng.gauss(0, 0.30 * v)
        o = prev * math.exp(gap)
        c = closes[i]
        hi = max(o, c) * math.exp(abs(rng.gauss(0, 0.45 * v)))
        lo = min(o, c) * math.exp(-abs(rng.gauss(0, 0.45 * v)))
        ret = abs(math.log(c / prev)) / max(v, 1e-9)
        vol_sh = 7.0e7 * math.exp(rng.gauss(0, 0.25)) * (1.0 + 0.45 * min(3.0, ret))
        bars.append(Bar(d, round(o, 4), round(hi, 4), round(lo, 4), round(c, 4), float(int(vol_sh))))
        prev = c
    return bars


def _expirations(today: dt.date) -> list:
    exps: set = set()
    for i in range(0, 8):                                   # daily-style near term
        d = today + dt.timedelta(days=i)
        if d.weekday() < 5:
            exps.add(d)
    d = today
    for _ in range(12):                                     # weekly Fridays
        d = d + dt.timedelta(days=(4 - d.weekday()) % 7 or 7)
        exps.add(d)
    y, m = today.year, today.month
    for k in range(0, 12):                                  # monthlies
        mm = (m - 1 + k) % 12 + 1
        yy = y + (m - 1 + k) // 12
        e = third_friday(yy, mm)
        if e > today:
            exps.add(e)
    for k in (15, 27):                                      # LEAPS (January)
        yy = y + (m - 1 + k) // 12
        exps.add(third_friday(yy, 1))
    return sorted(e for e in exps if e >= today)


class MockProvider(MarketDataProvider):
    name = "mock"
    is_mock = True

    def __init__(self, cfg: Optional[Config] = None, scenario: str = "bull_pullback", seed: int = 7,
                 inject_faults: bool = True) -> None:
        self.cfg = cfg or Config()
        self.scenario = scenario if scenario in SCENARIOS else "bull_pullback"
        self.seed = seed
        self.inject_faults = inject_faults

    @staticmethod
    def scenarios() -> dict:
        return {k: v["desc"] for k, v in SCENARIOS.items()}

    def describe(self) -> dict:
        return {"name": self.name, "is_mock": True, "scenario": self.scenario,
                "scenario_description": SCENARIOS[self.scenario]["desc"], "seed": self.seed}

    def fetch_snapshot(self, symbol: str, price_override: Optional[float] = None) -> MarketSnapshot:
        symbol = symbol.upper().strip()
        spot_ref, vscale = MOCK_UNIVERSE.get(symbol, (None, None))
        if spot_ref is None:                                 # deterministic pseudo-instrument for unknown tickers
            r = random.Random(f"universe|{symbol}")
            spot_ref, vscale = round(r.uniform(25, 400), 2), r.uniform(1.2, 3.0)
        now_u = utc_now()
        today = to_et(now_u).date()
        bars = generate_bars(symbol, self.scenario, self.seed, today, spot_ref, vscale)
        spot = bars[-1].close
        closes = [b.close for b in bars]
        rv20, rv60 = realized_vol(closes, 20), realized_vol(closes, 60)
        rv_blend = (rv20 + rv60) / 2.0
        sc = SCENARIOS[self.scenario]
        atm30 = min(1.2, max(0.10, rv_blend * sc["iv_mult"]))
        records = self._chain(symbol, spot, atm30, today, now_u)
        snap = map_cboe_chain(symbol, spot, to_et(now_u).strftime("%Y-%m-%d %H:%M:%S"), records,
                              (bars, f"MOCK ({self.scenario})", []), provider="mock", is_mock=True,
                              spot_source="MOCK synthetic", price_override=price_override)
        snap.warnings.append(f"MOCK DATA: synthetic scenario '{self.scenario}' ({sc['desc']}). Nothing here is a "
                             "real quote, real history or real event.")
        return snap

    # ------------------------------------------------------------------ chain
    def _chain(self, symbol: str, spot: float, atm30: float, today: dt.date, now_u: dt.datetime) -> list:
        from option_battle.legacy.options_suggester import years_to_expiry
        bs = BlackScholes()
        r, q = self.cfg.risk_free, self.cfg.div_for(symbol)
        rng = random.Random(f"chain|{symbol}|{self.scenario}|{self.seed}")
        stress_inverted = self.scenario in ("high_vol", "breakdown")
        records: list = []
        near = spot * 0.12
        step_near = 1.0 if spot >= 100 else 0.5 if spot >= 30 else 0.25
        for exp in _expirations(today):
            dte = (exp - today).days
            t = years_to_expiry(exp, now_u)
            slope = -0.10 if stress_inverted else 0.045
            atm = max(0.06, atm30 * (1.0 + slope * math.log(max(dte, 1) / 30.0)))
            width = near if dte <= 120 else spot * 0.35
            step = step_near if dte <= 70 else step_near * 5
            lo = math.floor((spot - width) / step) * step
            K = lo
            while K <= spot + width:
                if K > 0:
                    for right in ("C", "P"):
                        records.append(self._record(bs, rng, symbol, exp, right, round(K, 3), spot, t, dte, atm, r, q))
                K += step
        if self.inject_faults:
            self._inject(records, symbol, rng)
        return records

    def _record(self, bs, rng, symbol, exp, right, K, spot, t, dte, atm, r, q) -> dict:
        sd = atm * math.sqrt(max(t, 1e-4))
        x = max(-3.0, min(3.0, math.log(K / spot) / sd))
        iv = atm * (1.0 - 0.10 * x + 0.035 * x * x) * (1.0 + rng.uniform(-0.006, 0.006))
        iv = max(0.05, iv)
        g = bs.greeks(right, spot, K, t, r, q, iv)
        intrinsic = max(0.0, spot - K) if right == "C" else max(0.0, K - spot)
        p = max(g.price, intrinsic + 0.01)     # American-style: never below intrinsic (European BS can be, deep ITM puts)
        moneyness = abs(x)
        rel = 0.006 + 0.020 * moneyness ** 1.3 + (0.012 if dte <= 1 else 0.0)
        half = max(0.005, p * rel * (1.0 + 2.5 / max(spot, 1.0) * 10.0 * 0.0))
        bid = max(0.0, math.floor((p - half) * 100.0) / 100.0)
        ask = max(bid + 0.01, math.ceil((p + half) * 100.0) / 100.0)
        if p < 0.04 and rng.random() < 0.5:
            bid = 0.0
        monthly = exp.weekday() == 4 and 15 <= exp.day <= 21
        base_oi = (9000.0 if monthly else 2500.0) * (1.0 if dte < 120 else 0.35) * math.exp(-0.5 * (moneyness / 1.15) ** 2)
        oi = int(max(0, base_oi * math.exp(rng.gauss(0, 0.55)) * (spot / 400.0) ** -0.0))
        vol = int(max(0, oi * rng.uniform(0.02, 0.35) * (3.0 if dte <= 2 else 1.0)))
        last = round(max(0.01, p * (1.0 + rng.uniform(-0.03, 0.03))), 2) if vol > 0 else 0.0
        occ = f"{symbol}{exp.strftime('%y%m%d')}{right}{int(round(K * 1000)):08d}"
        return {"option": occ, "bid": bid, "bid_size": rng.randint(1, 80), "ask": ask, "ask_size": rng.randint(1, 80),
                "iv": round(iv, 4), "open_interest": oi, "volume": vol, "delta": round(g.delta, 4),
                "gamma": round(g.gamma, 5), "vega": round(g.vega, 4), "theta": round(g.theta, 4),
                "rho": round(g.rho, 4), "last_trade_price": last,
                "last_trade_time": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")}

    @staticmethod
    def _inject(records: list, symbol: str, rng: random.Random) -> None:
        """Deterministic malformed rows to exercise validation (each is dropped or flagged by the normalizer)."""
        if len(records) < 50:
            return
        idx = sorted(rng.sample(range(len(records)), 7))
        records[idx[0]] = dict(records[idx[0]], iv=float("nan"))
        records[idx[1]] = dict(records[idx[1]], bid=records[idx[1]]["ask"] + 0.50)           # crossed market
        records[idx[2]] = {k: v for k, v in records[idx[2]].items() if k != "ask"}            # missing field
        records[idx[3]] = dict(records[idx[3]], option="BADSYMBOL")                           # unparseable
        records[idx[4]] = dict(records[idx[4]], bid=-1.0)                                     # negative price
        records[idx[5]] = "not-a-record"                                                      # wrong type
        # impossible price: above BOTH caps (a put above its strike, a call above the stock) whatever record is drawn
        k6 = int(str(records[idx[6]]["option"])[-8:]) / 1000.0
        records[idx[6]] = dict(records[idx[6]], ask=round(3.0 * k6 + 1000.0, 2))
