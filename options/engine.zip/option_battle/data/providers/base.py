"""Provider abstraction. The analytics engine only ever sees `MarketSnapshot` (provider-neutral RawQuote rows +
daily bars); it never imports a concrete provider or touches provider field names.

To add a provider: subclass `MarketDataProvider`, map your payload into `RawQuote`/`Bar`, register it in
`data/providers/__init__.py`."""
from __future__ import annotations

import threading
import time
from abc import ABC, abstractmethod
from typing import Any, Callable, Optional

from option_battle.models.market import MarketSnapshot


class ProviderError(Exception):
    """Provider could not deliver usable market data."""


class TTLCache:
    """Tiny thread-safe in-memory cache (the UI server is multi-threaded)."""

    def __init__(self) -> None:
        self._d: dict = {}
        self._lock = threading.Lock()

    def get(self, key: Any, ttl: float, loader: Callable[[], Any]) -> Any:
        now = time.time()
        with self._lock:
            hit = self._d.get(key)
            if hit and now - hit[0] < ttl:
                return hit[1]
        val = loader()
        with self._lock:
            self._d[key] = (time.time(), val)
        return val

    def invalidate(self, key: Any) -> None:
        with self._lock:
            self._d.pop(key, None)

    def clear(self) -> None:
        with self._lock:
            self._d.clear()


class MarketDataProvider(ABC):
    name = "base"
    is_mock = False

    @abstractmethod
    def fetch_snapshot(self, symbol: str, price_override: Optional[float] = None) -> MarketSnapshot:
        """Return quotes + daily history for `symbol`. Raise ProviderError when nothing usable exists."""

    def describe(self) -> dict:
        return {"name": self.name, "is_mock": self.is_mock}
