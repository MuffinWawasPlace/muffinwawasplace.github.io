"""Provider registry. `get_provider("cboe" | "mock", cfg, **options)`."""
from __future__ import annotations

from typing import Optional

from option_battle.config import Config
from option_battle.data.providers.base import MarketDataProvider, ProviderError  # noqa: F401


def get_provider(name: str, cfg: Optional[Config] = None, **options) -> MarketDataProvider:
    name = (name or "mock").lower()
    cfg = cfg or Config()
    if name == "mock":
        from option_battle.data.providers.mock import MockProvider
        return MockProvider(cfg, **{k: v for k, v in options.items() if k in ("scenario", "seed", "inject_faults")})
    if name == "cboe":
        from option_battle.data.providers.cboe import CboeProvider
        return CboeProvider(cfg, **{k: v for k, v in options.items() if k in ("timeout", "retries")})
    raise ValueError(f"unknown provider '{name}' (available: mock, cboe)")


PROVIDERS = ("mock", "cboe")
