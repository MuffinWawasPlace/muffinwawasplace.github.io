"""CBOE delayed-quote provider (PRIMARY live source, preserved from the Options Suggester).

Endpoints retained unchanged from the legacy implementation (all fetching/retry/parsing code is imported from it):
  chain   : https://cdn.cboe.com/api/global/delayed_quotes/options/{SYMBOL}.json
  history : https://cdn.cboe.com/api/global/delayed_quotes/charts/historical/{SYMBOL}.json
            with the legacy fallback chain Yahoo Finance -> CBOE historical -> Stooq (order kept as shipped)

This module is the ONLY place that knows CBOE field names. Everything is mapped into provider-neutral `RawQuote`
objects; malformed rows are counted in `snapshot.dropped_records` instead of crashing the run.
"""
from __future__ import annotations

import datetime as dt
import logging
import math
from typing import Any, Optional

from option_battle.config import Config
from option_battle.core.util import safe_float, safe_int
from option_battle.data.providers.base import MarketDataProvider, ProviderError, TTLCache
from option_battle.legacy.options_suggester import (DataError, Http, get_history, parse_occ,
                                                    to_et, utc_now)
from option_battle.models.market import MarketSnapshot, RawQuote

LOG = logging.getLogger("option_battle.cboe")

CBOE_CHAIN_URL = "https://cdn.cboe.com/api/global/delayed_quotes/options/{symbol}.json"
CBOE_HISTORY_URL = "https://cdn.cboe.com/api/global/delayed_quotes/charts/historical/{symbol}.json"


def _num(v: Any) -> Optional[float]:
    """float or None (NaN/inf/garbage -> None, so downstream can flag rather than silently use 0)."""
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def map_cboe_record(o: Any, root_wanted: str, dropped: dict) -> Optional[RawQuote]:
    """One CBOE option record -> RawQuote. Returns None (and counts why) for unusable rows."""
    if not isinstance(o, dict):
        dropped["bad_record"] = dropped.get("bad_record", 0) + 1
        return None
    occ = parse_occ(str(o.get("option", "")))
    if occ is None:
        dropped["unparseable_symbol"] = dropped.get("unparseable_symbol", 0) + 1
        return None
    if occ.root != root_wanted:
        dropped["nonstandard_root"] = dropped.get("nonstandard_root", 0) + 1   # adjusted deliverables, e.g. QQQ1
        return None
    iv = _num(o.get("iv"))
    if iv is not None and iv > 5.0:        # defensive: percent-format feed (legacy behaviour)
        iv /= 100.0
    if iv is not None and iv <= 0:
        iv = None
    has_quote = iv is not None
    return RawQuote(
        symbol=str(o.get("option", "")).replace(" ", "").upper(), underlying=occ.root, expiration=occ.expiration,
        right=occ.right, strike=occ.strike,
        bid=_num(o.get("bid")) if _num(o.get("bid")) is not None else float("nan"),
        ask=_num(o.get("ask")) if _num(o.get("ask")) is not None else float("nan"),
        last=safe_float(o.get("last_trade_price")), volume=safe_int(o.get("volume")),
        open_interest=safe_int(o.get("open_interest")), iv=iv,
        # CBOE reports zeros for Greeks when it has no model quote: treat as missing rather than as real zeros
        delta=_num(o.get("delta")) if has_quote else None, gamma=_num(o.get("gamma")) if has_quote else None,
        theta=_num(o.get("theta")) if has_quote else None, vega=_num(o.get("vega")) if has_quote else None,
        bid_size=safe_int(o.get("bid_size")), ask_size=safe_int(o.get("ask_size")),
        last_trade_time=str(o.get("last_trade_time") or ""), raw=o)


# The underlying mid is used only when the quote is two-sided and tight. A wide or one-sided quote (pre/post market,
# halted, stale) would make the mid worse than the last trade, so the last trade is kept as the fallback.
MAX_UNDERLYING_SPREAD_PCT = 0.005
# Below this fraction of contracts with an ask, the chain is treated as a quote-less snapshot (not cached).
MIN_QUOTED_FRACTION = 0.20


def underlying_spot(data: dict) -> tuple:
    """-> (spot, source text, observed quote dict). Prefers the bid/ask mid; falls back to last trade, then closes."""
    bid, ask = _num(data.get("bid")), _num(data.get("ask"))
    last = _num(data.get("current_price"))
    quote = {"bid": bid, "ask": ask, "last": last, "close": _num(data.get("close")),
             "prev_day_close": _num(data.get("prev_day_close")), "used": None}
    if bid and ask and bid > 0 and ask >= bid:
        mid = (bid + ask) / 2.0
        if (ask - bid) / mid <= MAX_UNDERLYING_SPREAD_PCT:
            quote["used"] = "mid"
            return mid, f"CBOE delayed mid ({bid:.2f} x {ask:.2f})", quote
        quote["mid_rejected"] = f"spread {(ask - bid) / mid * 100:.2f}% > {MAX_UNDERLYING_SPREAD_PCT * 100:.1f}%"
    for key, label in (("current_price", "CBOE delayed last trade"), ("close", "CBOE close"),
                       ("prev_day_close", "CBOE previous close")):
        v = _num(data.get(key))
        if v and v > 0:
            quote["used"] = key
            why = quote.get("mid_rejected") or "no two-sided underlying quote"
            return v, f"{label} (mid not used: {why})", quote
    return None, "", quote


def fetch_chain_with_quote(http: Http, symbol: str) -> tuple:
    """Same endpoint and parsing as the legacy `fetch_cboe_chain`, but keeps the underlying bid/ask so the spot can
    be a mid rather than a last trade. -> (spot, spot_source, timestamp, option records, quote dict)."""
    try:
        j = http.get(CBOE_CHAIN_URL.format(symbol=symbol)).json()
    except ValueError as exc:
        raise DataError(f"CBOE chain: invalid JSON ({exc})") from exc
    data = j.get("data") or {}
    if not isinstance(data, dict):
        raise DataError("CBOE chain: unexpected structure")
    opts = data.get("options") or []
    if not isinstance(opts, list) or not opts:
        raise DataError("CBOE chain: no options returned")
    spot, source, quote = underlying_spot(data)
    return spot, source, str(j.get("timestamp") or data.get("last_trade_time") or ""), opts, quote


def map_cboe_chain(symbol: str, spot: Optional[float], timestamp: str, records: list,
                   history: tuple, provider: str = "cboe", is_mock: bool = False,
                   spot_source: str = "CBOE delayed", price_override: Optional[float] = None) -> MarketSnapshot:
    """Shared by the live provider and by the mock provider (which emits CBOE-shaped payloads), so both exercise
    exactly the same mapping and malformed-row handling."""
    bars, hist_source, hist_errors = history
    snap = MarketSnapshot(symbol=symbol, provider=provider, spot=spot, spot_source=spot_source,
                          fetched_at_utc=utc_now(), chain_timestamp=timestamp, bars=list(bars),
                          history_source=hist_source, is_mock=is_mock)
    if hist_errors:
        snap.warnings.extend(f"history: {e}" for e in hist_errors)
    root_wanted = symbol.replace(".", "")
    for o in records:
        rq = map_cboe_record(o, root_wanted, snap.dropped_records)
        if rq is not None:
            snap.quotes.append(rq)
    if price_override and price_override > 0:
        if spot and abs(price_override / spot - 1.0) > 0.005:
            snap.warnings.append(f"price override {price_override:.2f} differs from feed {spot:.2f}: quotes are "
                                 "NOT repriced; Greeks are model-recomputed at the override (approximate what-if).")
        snap.spot, snap.spot_source = price_override, "user price override"
    elif not spot and bars:
        snap.spot, snap.spot_source = bars[-1].close, f"last close ({hist_source})"
    if snap.spot and bars and abs(bars[-1].close / snap.spot - 1.0) > 0.05:
        snap.warnings.append(f"last history close {bars[-1].close:.2f} differs >5% from chain spot {snap.spot:.2f}: "
                             "check data freshness or splits.")
    return snap


class CboeProvider(MarketDataProvider):
    name = "cboe"

    def __init__(self, cfg: Optional[Config] = None, timeout: float = 15.0, retries: int = 3) -> None:
        self.cfg = cfg or Config()
        self.http = Http(timeout, retries)
        self._cache = TTLCache()

    def fetch_snapshot(self, symbol: str, price_override: Optional[float] = None) -> MarketSnapshot:
        symbol = symbol.upper().strip()
        ttl = float(self.cfg.cache_ttl_seconds)
        try:
            spot, source, ts, records, quote = self._cache.get(
                ("chain", symbol), ttl, lambda: fetch_chain_with_quote(self.http, symbol))
        except DataError as exc:
            raise ProviderError(f"CBOE option chain unavailable for {symbol}: {exc}") from exc
        history = self._cache.get(("hist", symbol), max(ttl, 1800.0), lambda: get_history(self.http, symbol))
        snap = map_cboe_chain(symbol, spot, ts, records, history, provider="cboe",
                              spot_source=source or "CBOE delayed", price_override=price_override)
        snap.spot_quote = quote
        with_ask = sum(1 for q in snap.quotes if q.ask == q.ask and q.ask > 0)        # q.ask == q.ask: not NaN
        if snap.quotes and with_ask / len(snap.quotes) < MIN_QUOTED_FRACTION:
            snap.quotes_missing = True
            snap.warnings.append(f"CBOE sent this {symbol} chain with almost no bid/ask quotes ({with_ask} of "
                                 f"{len(snap.quotes)} contracts). This happens for a few minutes around the open. "
                                 "Option marks are unavailable or last-trade only; press Analyze again shortly.")
            self._cache.invalidate(("chain", symbol))                               # next request refetches
        if not snap.bars:
            snap.warnings.append("no price history from any source: regime, realized-vol and technical levels are "
                                 "UNAVAILABLE and regime-dependent scores fall back to neutral")
        if not snap.spot:
            raise ProviderError(f"no underlying price available for {symbol}")
        if not snap.quotes:
            raise ProviderError(f"no parseable standard-root contracts in the {symbol} chain")
        return snap
