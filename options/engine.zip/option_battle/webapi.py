"""In-browser entry point for the website build (runs under Pyodide; nothing here needs a server).

    install_shims()                    # call once, before importing anything else from option_battle
    call(method, path, query, body)    # -> JSON text {"status": int, "body": {...}}

The browser has no `requests` package, so a tiny stand-in built on synchronous XMLHttpRequest is registered under
that name. The legacy Http class (retries, status handling) runs unchanged on top of it. A site can only read
another site's data if that site allows it (CORS); when CBOE does not, the request fails cleanly and the page
falls back to MOCK data.
"""
from __future__ import annotations

import json
import sys
import types
from urllib.parse import urlencode

_ENGINE = None
_API = None


def install_shims() -> None:
    if "requests" not in sys.modules:
        mod = types.ModuleType("requests")

        class RequestException(Exception):
            pass

        class Response:
            def __init__(self, status: int, text: str, headers: dict) -> None:
                self.status_code, self.text, self.headers = status, text, headers
                self.content = text.encode("utf-8")
                self.ok = 200 <= status < 300

            def json(self):
                return json.loads(self.text)

        class Session:
            def __init__(self) -> None:
                self.headers: dict = {}      # browsers set their own User-Agent; custom ones are refused

            def get(self, url, params=None, timeout=None, **_kw):
                if params:
                    url += ("&" if "?" in url else "?") + urlencode(params)
                try:
                    from js import XMLHttpRequest   # only exists under Pyodide
                    x = XMLHttpRequest.new()
                    x.open("GET", url, False)    # synchronous: the engine is synchronous code
                    x.send()
                except Exception as exc:          # NetworkError: CORS refusal or offline
                    raise RequestException(f"browser could not read {url} ({exc})") from None
                if x.status == 0:
                    raise RequestException(f"browser could not read {url} (blocked or offline)")
                return Response(int(x.status), str(x.responseText or ""), {})

        mod.RequestException = RequestException
        mod.Response = Response
        mod.Session = Session
        mod.get = lambda url, **kw: Session().get(url, **kw)
        sys.modules["requests"] = mod
    import time
    time.sleep = lambda _s: None   # retries back off with sleep; in a page that would only freeze the screen


def _api():
    global _ENGINE, _API
    if _API is None:
        from option_battle.api import Api
        from option_battle.engine import Engine
        _ENGINE = Engine("mock")
        _API = Api(_ENGINE)
    return _API


def call(method: str, path: str, query_json: str = "{}", body_json: str = "{}") -> str:
    from option_battle.core.util import sanitize
    from option_battle.engine import AnalysisError
    api = _api()
    q = json.loads(query_json or "{}")
    try:
        body = json.loads(body_json or "{}")
    except ValueError:
        body = {}
    routes_get = {"/api/meta": lambda: api.meta(), "/api/trade": lambda: api.trade(q),
                  "/api/health": lambda: {"ok": True}}
    routes_post = {"/api/analyze": api.analyze, "/api/compare": api.compare,
                   "/api/portfolio/parse": api.parse_portfolio, "/api/portfolio/check": api.check_portfolio,
                   "/api/portfolio/import_csv": api.import_csv, "/api/backtest": api.backtest}
    try:
        if method == "GET" and path in routes_get:
            out, status = routes_get[path](), 200
        elif method == "POST" and path in routes_post:
            out, status = routes_post[path](body if isinstance(body, dict) else {}), 200
        else:
            out, status = {"error": f"no route {path}"}, 404
    except AnalysisError as exc:
        out, status = {"error": str(exc), "hint": exc.hint}, exc.status
    except Exception as exc:  # report, never leave the page hanging
        import traceback
        traceback.print_exc()
        out, status = {"error": f"internal error: {exc}", "hint": "Open the browser console for details."}, 500
    return json.dumps({"status": status, "body": sanitize(out)}, separators=(",", ":"), default=str)
