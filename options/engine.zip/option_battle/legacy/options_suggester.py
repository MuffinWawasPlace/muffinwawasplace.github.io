#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
options_suggester.py - VERSION 2
Portfolio-context-aware, stateless short-options decision engine for liquid
US stocks and ETFs (covered calls, cash-secured puts, existing-position management).

ARCHITECTURE RULES
  * Portfolio context is entered at runtime (interactively or via CLI flags) and
    exists ONLY in memory for this execution. Nothing is saved to disk.
  * No brokerage APIs, no account access, no trades.db, no paid data.
  * Data: CBOE delayed option chains + Yahoo/CBOE/Stooq daily history (fallback chain).

USAGE
  python options_suggester.py                     # interactive questionnaire
  python options_suggester.py --debug             # verbose factor/diagnostic output
  python options_suggester.py --json              # prompts go to stderr, JSON to stdout
  python options_suggester.py --price 756.40      # price override (single-symbol runs)
  python options_suggester.py --price QQQ=756.40 --price AAPL=230

  Non-interactive (any of these flags skips the questionnaire):
  python options_suggester.py --cash 60000 --holdings "QQQ 700, AAPL 150" \
      --short "QQQ C 720 2026-07-17 7 3.15" --watch "SPY,NVDA" \
      --delta 0.15-0.20 --assignment yes --json

DISCLAIMER: Model output based on delayed quotes and simplifying assumptions
(Black-Scholes, lognormal returns, no early exercise in the probability math).
NOT financial advice. NOT guaranteed optimal or profitable. Options involve
substantial risk, including assignment and loss of principal.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import io
import json
import logging
import math
import re
import sys
import textwrap
import time
from dataclasses import asdict, dataclass, field, replace
from typing import Any, Optional

try:
    import requests
except ImportError:  # pragma: no cover
    sys.stderr.write("ERROR: the 'requests' package is required. Install: pip install requests\n")
    sys.exit(2)

try:
    from zoneinfo import ZoneInfo

    NY_TZ: Optional[dt.tzinfo] = ZoneInfo("America/New_York")
except Exception:  # zoneinfo/tzdata unavailable on some Termux builds -> manual DST fallback
    NY_TZ = None

VERSION = "2.0.0"
ENGINE_NAME = "PORTFOLIO-AWARE OPTIONS SELLING SUGGESTER"
LOG = logging.getLogger("options_suggester")
W = 64  # target output width for phone screens

DISCLAIMER = (
    "Model output only, based on delayed CBOE quotes and simplifying assumptions "
    "(Black-Scholes with a flat dividend yield, lognormal returns, no early exercise "
    "in probability math). Probabilities are risk-neutral model estimates, not "
    "real-world forecasts. Not financial advice; not guaranteed optimal or profitable. "
    "Verify live quotes, margin/collateral rules and assignment consequences with "
    "your broker before trading."
)


# =============================================================================
# CONFIGURATION
# =============================================================================

@dataclass(frozen=True)
class Config:
    # DTE windows
    dte_min: int = 25
    dte_max: int = 45
    dte_pref_min: int = 28
    dte_pref_max: int = 38
    dte_ext_min: int = 21          # used only if no expiration falls in dte_min..dte_max
    dte_ext_max: int = 52
    allow_weeklies: bool = False
    # Delta preference (absolute delta); fallbacks derived by padding
    delta_lo: float = 0.15
    delta_hi: float = 0.20
    fallback_pad: float = 0.03     # 0.15-0.20 -> 0.12-0.23
    final_pad: float = 0.05        # 0.15-0.20 -> 0.10-0.25
    # Hard quality gates (disqualify)
    min_bid: float = 0.05
    min_mid: float = 0.15
    max_spread_pct: float = 0.25
    spread_abs_ok: float = 0.05    # spreads <= $0.05 pass regardless of %
    min_oi: int = 10
    min_em_ratio: float = 0.40     # strike must be at least 0.4 expected moves OTM
    # Soft references (penalties)
    adequate_mid: float = 0.50
    wide_spread_pct: float = 0.10
    adequate_oi: int = 250
    min_annual_roc: float = 0.03
    # Decision
    min_score: float = 55.0
    regime_bonus: float = 5.0             # +/- points for regime alignment
    strong_regime_multiplier: float = 1.5  # strong regimes: +/- 7.5 (15-pt swing)
    risk_gate: float = 5.0                 # extra threshold for counter-trend side in STRONG regimes
    # Portfolio
    conc_limit_broad: float = 0.60  # broad index exposure guideline (leverage-weighted / portfolio)
    conc_limit_other: float = 0.25  # single names / sector funds
    conc_slope: float = 60.0        # penalty points per 1.00 over the limit
    conc_cap: float = 25.0
    pending_mgmt_penalty: float = 3.0
    # Management
    watch_delta: float = 0.30
    threat_delta: float = 0.40
    deep_threat_delta: float = 0.50
    roll_max_delta: float = 0.35
    roll_dte_max: int = 60
    # Pricing model
    risk_free: float = 0.043
    div_yield: float = 0.0
    # Network / limits
    timeout: float = 15.0
    retries: int = 3
    max_symbols: int = 12


WEIGHTS: dict[str, float] = {
    "delta_fit": 20.0,
    "em_coverage": 20.0,
    "premium_yield": 18.0,
    "spread": 12.0,
    "liquidity": 13.0,
    "dte_fit": 10.0,
    "vol_edge": 7.0,
}
FACTOR_LABEL = {"delta_fit": "delta", "em_coverage": "EMcov", "premium_yield": "yield",
                "spread": "spread", "liquidity": "liq", "dte_fit": "DTE", "vol_edge": "IV/RV"}

# Simple annualized ROC: (0 points at, full points at). Calls on share value
# structurally yield less than puts on strike (skew); each side has its own scale.
# Capped at 18/100 so premium alone cannot dominate.
YIELD_SCALE: dict[str, tuple[float, float]] = {"PUT": (0.02, 0.12), "CALL": (0.015, 0.09)}

REGIME_MAX = 11.5
REGIME_MIN = -12.0

# Correlated-exposure groups with leverage factors (transparent, deliberately small).
EXPOSURE_GROUPS: dict[str, tuple[str, float]] = {
    "QQQ": ("NASDAQ100", 1.0), "QQQM": ("NASDAQ100", 1.0), "QLD": ("NASDAQ100", 2.0),
    "TQQQ": ("NASDAQ100", 3.0), "PSQ": ("NASDAQ100", -1.0), "SQQQ": ("NASDAQ100", -3.0),
    "SPY": ("SP500", 1.0), "VOO": ("SP500", 1.0), "IVV": ("SP500", 1.0), "SPLG": ("SP500", 1.0),
    "SSO": ("SP500", 2.0), "UPRO": ("SP500", 3.0), "SPXL": ("SP500", 3.0),
    "SH": ("SP500", -1.0), "SDS": ("SP500", -2.0), "SPXU": ("SP500", -3.0),
    "IWM": ("RUSSELL2000", 1.0), "VTWO": ("RUSSELL2000", 1.0), "TNA": ("RUSSELL2000", 3.0),
    "TZA": ("RUSSELL2000", -3.0),
    "DIA": ("DOW30", 1.0), "UDOW": ("DOW30", 3.0),
    "VTI": ("US_TOTAL", 1.0), "ITOT": ("US_TOTAL", 1.0),
    "SMH": ("SEMIS", 1.0), "SOXX": ("SEMIS", 1.0), "SOXL": ("SEMIS", 3.0), "SOXS": ("SEMIS", -3.0),
}
BROAD_GROUPS = {"NASDAQ100", "SP500", "RUSSELL2000", "DOW30", "US_TOTAL"}

TICKER_RE = re.compile(r"^[A-Z][A-Z0-9.]{0,9}$")


def exposure_key(sym: str) -> tuple[str, float]:
    return EXPOSURE_GROUPS.get(sym, (sym, 1.0))


# =============================================================================
# GENERIC HELPERS
# =============================================================================

class DataError(Exception):
    """Market data could not be retrieved or parsed."""


class InputError(Exception):
    """Portfolio context input was invalid."""


def safe_float(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return default
    if math.isnan(x) or math.isinf(x):
        return default
    return x


def safe_int(v: Any, default: int = 0) -> int:
    return int(round(safe_float(v, float(default))))


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def lin(x: float, x0: float, x1: float) -> float:
    """Linear map x0->0, x1->1, clamped. Works for decreasing maps (x1 < x0)."""
    if x1 == x0:
        return 1.0 if x >= x1 else 0.0
    return clamp((x - x0) / (x1 - x0))


def f_pct(x: Optional[float], d: int = 2) -> str:
    return "n/a" if x is None else f"{x * 100:.{d}f}%"


def f_num(x: Optional[float], d: int = 2) -> str:
    return "n/a" if x is None else f"{x:.{d}f}"


def f_usd(x: Optional[float], d: int = 2) -> str:
    if x is None:
        return "n/a"
    sign = "-" if x < 0 else ""
    return f"{sign}${abs(x):,.{d}f}"


def f_signed_usd(x: Optional[float]) -> str:
    if x is None:
        return "n/a"
    return ("+" if x >= 0 else "-") + f"${abs(x):,.2f}"


def wrap(text: str, indent: int = 2, width: int = W) -> str:
    return textwrap.fill(text, width=width, initial_indent=" " * indent,
                         subsequent_indent=" " * (indent + 2))


# =============================================================================
# TIME (America/New_York with manual DST fallback)
# =============================================================================

def _fallback_et_offset(utc_naive: dt.datetime) -> dt.timedelta:
    """US DST: 2nd Sunday of March 07:00 UTC .. 1st Sunday of November 06:00 UTC."""
    y = utc_naive.year
    m1 = dt.datetime(y, 3, 1)
    dst_start = m1 + dt.timedelta(days=(6 - m1.weekday()) % 7 + 7, hours=7)
    n1 = dt.datetime(y, 11, 1)
    dst_end = n1 + dt.timedelta(days=(6 - n1.weekday()) % 7, hours=6)
    return dt.timedelta(hours=-4) if dst_start <= utc_naive < dst_end else dt.timedelta(hours=-5)


def utc_now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def to_et(t_utc: dt.datetime) -> dt.datetime:
    if NY_TZ is not None:
        return t_utc.astimezone(NY_TZ)
    off = _fallback_et_offset(t_utc.astimezone(dt.timezone.utc).replace(tzinfo=None))
    return t_utc.astimezone(dt.timezone(off))


def expiry_close_utc(exp: dt.date) -> dt.datetime:
    if NY_TZ is not None:
        return dt.datetime(exp.year, exp.month, exp.day, 16, tzinfo=NY_TZ).astimezone(dt.timezone.utc)
    off = _fallback_et_offset(dt.datetime(exp.year, exp.month, exp.day, 20))
    return dt.datetime(exp.year, exp.month, exp.day, 16,
                       tzinfo=dt.timezone(off)).astimezone(dt.timezone.utc)


def years_to_expiry(exp: dt.date, now_u: dt.datetime) -> float:
    """Calendar time to the 16:00 ET close on expiration day, floored at 1 hour."""
    secs = (expiry_close_utc(exp) - now_u).total_seconds()
    return max(secs, 3600.0) / (365.0 * 86400.0)


def epoch_to_et_date(ts: float) -> dt.date:
    return to_et(dt.datetime.fromtimestamp(ts, tz=dt.timezone.utc)).date()


# =============================================================================
# HTTP
# =============================================================================

class Http:
    def __init__(self, timeout: float, retries: int) -> None:
        self.timeout = timeout
        self.retries = max(1, retries)
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": ("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                           "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"),
            "Accept": "application/json,text/csv,text/plain,*/*",
        })

    def get(self, url: str, params: Optional[dict] = None) -> requests.Response:
        last: Any = None
        for attempt in range(1, self.retries + 1):
            try:
                LOG.debug("GET %s params=%s (attempt %d)", url, params, attempt)
                r = self.session.get(url, params=params, timeout=self.timeout)
                if r.status_code == 200:
                    return r
                last = f"HTTP {r.status_code}"
                if r.status_code == 429:  # rate limited: back off and retry
                    if attempt < self.retries:
                        ra = safe_float(r.headers.get("Retry-After"), 0.0)
                        time.sleep(min(10.0, ra if ra > 0 else 2.0 * attempt))
                    continue
                if 400 <= r.status_code < 500:
                    break
            except requests.RequestException as exc:
                last = exc
            if attempt < self.retries:
                time.sleep(0.75 * attempt)
        raise DataError(f"GET failed for {url}: {last}")


# =============================================================================
# PRICE HISTORY
# =============================================================================

@dataclass
class Bar:
    date: dt.date
    open: float
    high: float
    low: float
    close: float
    volume: float


def clean_bars(bars: list[Bar]) -> list[Bar]:
    by_date: dict[dt.date, Bar] = {}
    for b in bars:
        if b.close > 0 and b.high > 0 and b.low > 0 and b.high >= b.low:
            by_date[b.date] = b
    return [by_date[d] for d in sorted(by_date)]


def fetch_history_yahoo(http: Http, symbol: str) -> list[Bar]:
    ysym = symbol.replace(".", "-")
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{ysym}"
    try:
        j = http.get(url, params={"range": "2y", "interval": "1d", "includePrePost": "false"}).json()
    except ValueError as exc:
        raise DataError(f"Yahoo: invalid JSON ({exc})") from exc
    res = (j.get("chart") or {}).get("result") or []
    if not res:
        raise DataError("Yahoo: empty result")
    r0 = res[0]
    ts = r0.get("timestamp") or []
    q = ((r0.get("indicators") or {}).get("quote") or [{}])[0]
    o, h, lo, c, v = (q.get(k) or [] for k in ("open", "high", "low", "close", "volume"))
    bars: list[Bar] = []
    for i, t in enumerate(ts):
        try:
            vals = (o[i], h[i], lo[i], c[i])
        except IndexError:
            continue
        if any(x is None for x in vals):
            continue
        vol = v[i] if i < len(v) and v[i] is not None else 0
        bars.append(Bar(epoch_to_et_date(t), float(vals[0]), float(vals[1]),
                        float(vals[2]), float(vals[3]), float(vol)))
    return clean_bars(bars)


def fetch_history_cboe(http: Http, symbol: str) -> list[Bar]:
    url = f"https://cdn.cboe.com/api/global/delayed_quotes/charts/historical/{symbol}.json"
    try:
        j = http.get(url).json()
    except ValueError as exc:
        raise DataError(f"CBOE history: invalid JSON ({exc})") from exc
    rows = j.get("data") or []
    if not isinstance(rows, list):
        raise DataError("CBOE history: unexpected structure")
    bars: list[Bar] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        try:
            d = dt.date.fromisoformat(str(r.get("date"))[:10])
        except ValueError:
            continue
        bars.append(Bar(d, safe_float(r.get("open")), safe_float(r.get("high")),
                        safe_float(r.get("low")), safe_float(r.get("close")),
                        safe_float(r.get("volume"))))
    return clean_bars(bars)


def fetch_history_stooq(http: Http, symbol: str) -> list[Bar]:
    s = symbol.lower().replace(".", "-")
    r = http.get("https://stooq.com/q/d/l/", params={"s": f"{s}.us", "i": "d"})
    text = r.text.strip()
    if not text.lower().startswith("date"):
        raise DataError("Stooq: non-CSV response")
    bars: list[Bar] = []
    for row in csv.DictReader(io.StringIO(text)):
        try:
            d = dt.date.fromisoformat(row["Date"])
        except (KeyError, ValueError):
            continue
        bars.append(Bar(d, safe_float(row.get("Open")), safe_float(row.get("High")),
                        safe_float(row.get("Low")), safe_float(row.get("Close")),
                        safe_float(row.get("Volume"))))
    return clean_bars(bars)


def get_history(http: Http, symbol: str) -> tuple[list[Bar], Optional[str], list[str]]:
    errors: list[str] = []
    for name, fn in (("Yahoo Finance", fetch_history_yahoo),
                     ("CBOE historical", fetch_history_cboe),
                     ("Stooq", fetch_history_stooq)):
        try:
            bars = fn(http, symbol)
            if len(bars) >= 60:
                return bars, name, errors
            errors.append(f"{name}: only {len(bars)} bars")
        except (DataError, ValueError, KeyError, TypeError) as exc:
            errors.append(f"{name}: {exc}")
    return [], None, errors


# =============================================================================
# OCC SYMBOLS + CHAIN
# =============================================================================

@dataclass(frozen=True)
class OccSymbol:
    root: str
    expiration: dt.date
    right: str
    strike: float


def parse_occ(raw: str) -> Optional[OccSymbol]:
    """ROOT + YYMMDD + C/P + STRIKE*1000 (8 digits). Tail is always 15 chars -> any root length."""
    s = str(raw).replace(" ", "").upper().lstrip("-")
    if len(s) < 16:
        return None
    root, tail = s[:-15], s[-15:]
    ymd, right, strike_s = tail[:6], tail[6], tail[7:]
    if not root.isalnum() or not ymd.isdigit() or right not in ("C", "P") or not strike_s.isdigit():
        return None
    try:
        exp = dt.datetime.strptime(ymd, "%y%m%d").date()
    except ValueError:
        return None
    strike = int(strike_s) / 1000.0
    if strike <= 0:
        return None
    return OccSymbol(root, exp, right, strike)


@dataclass
class ChainSnapshot:
    spot: Optional[float]
    timestamp: str
    options: list


def fetch_cboe_chain(http: Http, symbol: str) -> ChainSnapshot:
    url = f"https://cdn.cboe.com/api/global/delayed_quotes/options/{symbol}.json"
    try:
        j = http.get(url).json()
    except ValueError as exc:
        raise DataError(f"CBOE chain: invalid JSON ({exc})") from exc
    data = j.get("data") or {}
    if not isinstance(data, dict):
        raise DataError("CBOE chain: unexpected structure")
    opts = data.get("options") or []
    if not isinstance(opts, list) or not opts:
        raise DataError("CBOE chain: no options returned")
    spot = None
    for key in ("current_price", "close", "prev_day_close"):
        v = safe_float(data.get(key))
        if v > 0:
            spot = v
            break
    return ChainSnapshot(spot, str(j.get("timestamp") or data.get("last_trade_time") or ""), opts)


def third_friday(year: int, month: int) -> dt.date:
    d = dt.date(year, month, 1)
    return d + dt.timedelta(days=(4 - d.weekday()) % 7 + 14)


def is_standard_monthly(exp: dt.date, available: set) -> bool:
    """Third Friday, or the Thursday before it when Friday is an exchange holiday."""
    tf = third_friday(exp.year, exp.month)
    if exp == tf:
        return True
    return exp == tf - dt.timedelta(days=1) and tf not in available


# =============================================================================
# BLACK-SCHOLES (continuous dividend yield) - model approximations
# =============================================================================

def norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def bs_d1_d2(S: float, K: float, t: float, r: float, q: float, sigma: float) -> tuple[float, float]:
    vt = sigma * math.sqrt(t)
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma * sigma) * t) / vt
    return d1, d1 - vt


def bs_price(right: str, S: float, K: float, t: float, r: float, q: float, sigma: float) -> float:
    if t <= 0 or sigma <= 0:
        return max(0.0, S - K) if right == "C" else max(0.0, K - S)
    d1, d2 = bs_d1_d2(S, K, t, r, q, sigma)
    dq, dr = math.exp(-q * t), math.exp(-r * t)
    if right == "C":
        return S * dq * norm_cdf(d1) - K * dr * norm_cdf(d2)
    return K * dr * norm_cdf(-d2) - S * dq * norm_cdf(-d1)


def bs_delta(right: str, S: float, K: float, t: float, r: float, q: float, sigma: float) -> float:
    if t <= 0 or sigma <= 0:
        itm = (S > K) if right == "C" else (S < K)
        return (1.0 if right == "C" else -1.0) if itm else 0.0
    d1, _ = bs_d1_d2(S, K, t, r, q, sigma)
    dq = math.exp(-q * t)
    return dq * norm_cdf(d1) if right == "C" else -dq * norm_cdf(-d1)


def bs_prob_itm(right: str, S: float, K: float, t: float, r: float, q: float, sigma: float) -> float:
    """Risk-neutral P(finish ITM): N(d2) calls, N(-d2) puts. Model estimate only."""
    if t <= 0 or sigma <= 0:
        return 1.0 if ((S > K) if right == "C" else (S < K)) else 0.0
    _, d2 = bs_d1_d2(S, K, t, r, q, sigma)
    return norm_cdf(d2) if right == "C" else norm_cdf(-d2)


def implied_vol(right: str, price: float, S: float, K: float, t: float,
                r: float, q: float) -> Optional[float]:
    if price <= 0 or t <= 0:
        return None
    lo, hi = 1e-4, 5.0
    if bs_price(right, S, K, t, r, q, lo) > price or bs_price(right, S, K, t, r, q, hi) < price:
        return None
    for _ in range(120):
        mid = 0.5 * (lo + hi)
        if bs_price(right, S, K, t, r, q, mid) > price:
            hi = mid
        else:
            lo = mid
        if hi - lo < 1e-7:
            break
    return 0.5 * (lo + hi)


def resolve_iv(right: str, o: dict, mid: float, S: float, K: float, t: float,
               cfg: Config) -> tuple[Optional[float], str]:
    iv = safe_float(o.get("iv"))
    if iv > 5.0:  # defensive: percent-format feed
        iv /= 100.0
    if 0.01 < iv < 5.0:
        return iv, "feed"
    solved = implied_vol(right, mid, S, K, t, cfg.risk_free, cfg.div_yield) if mid > 0 else None
    if solved and 0.01 < solved < 5.0:
        return solved, "solved"
    return None, "none"


# =============================================================================
# INDICATORS + REGIME
# =============================================================================

def sma(vals: list[float], n: int) -> Optional[float]:
    return sum(vals[-n:]) / n if len(vals) >= n else None


def rsi_wilder(closes: list[float], n: int = 14) -> Optional[float]:
    if len(closes) < n + 1:
        return None
    gains, losses = [], []
    for i in range(1, len(closes)):
        ch = closes[i] - closes[i - 1]
        gains.append(max(ch, 0.0))
        losses.append(max(-ch, 0.0))
    ag, al = sum(gains[:n]) / n, sum(losses[:n]) / n
    for g, l in zip(gains[n:], losses[n:]):
        ag = (ag * (n - 1) + g) / n
        al = (al * (n - 1) + l) / n
    if al == 0:
        return 100.0 if ag > 0 else 50.0
    return 100.0 - 100.0 / (1.0 + ag / al)


def atr_wilder(bars: list[Bar], n: int = 14) -> Optional[float]:
    if len(bars) < n + 1:
        return None
    trs = []
    for i in range(1, len(bars)):
        h, l, pc = bars[i].high, bars[i].low, bars[i - 1].close
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    atr = sum(trs[:n]) / n
    for tr in trs[n:]:
        atr = (atr * (n - 1) + tr) / n
    return atr


def realized_vol(closes: list[float], n: int) -> Optional[float]:
    if len(closes) < n + 1:
        return None
    rets = [math.log(closes[i] / closes[i - 1]) for i in range(len(closes) - n, len(closes))]
    mean = sum(rets) / n
    var = sum((x - mean) ** 2 for x in rets) / (n - 1)
    return math.sqrt(var * 252.0)


def rv_percentile(closes: list[float], n: int = 20, lookback: int = 252) -> Optional[float]:
    """Percentile of the current 20d realized vol within its own trailing ~1y history."""
    if len(closes) < n + 61:
        return None
    rets = [math.log(closes[i] / closes[i - 1]) for i in range(1, len(closes))]
    series: list[float] = []
    for end in range(n, len(rets) + 1):
        w = rets[end - n:end]
        m = sum(w) / n
        series.append(math.sqrt(sum((x - m) ** 2 for x in w) / (n - 1) * 252.0))
    series = series[-lookback:]
    cur = series[-1]
    return sum(1 for v in series if v <= cur) / len(series)


def pct_return(closes: list[float], n: int) -> Optional[float]:
    if len(closes) < n + 1:
        return None
    return closes[-1] / closes[-1 - n] - 1.0


@dataclass
class Regime:
    label: str = "NEUTRAL"
    score: float = 0.0
    available: bool = False
    components: list = field(default_factory=list)
    indicators: dict = field(default_factory=dict)
    vol_state: str = "UNKNOWN"
    rv_pctile: Optional[float] = None
    notes: list = field(default_factory=list)


def classify_regime_score(score: float) -> str:
    if score >= 6.5:
        return "STRONG_BULLISH"
    if score >= 2.5:
        return "BULLISH"
    if score > -2.5:
        return "NEUTRAL"
    if score > -6.5:
        return "BEARISH"
    return "STRONG_BEARISH"


def compute_regime(bars: list[Bar], spot: Optional[float]) -> Regime:
    """Direction score from trend + momentum only; volatility reported separately."""
    if len(bars) < 30:
        return Regime(notes=["Insufficient price history; regime defaulted to NEUTRAL."])
    closes = [b.close for b in bars]
    px = spot if spot and spot > 0 else closes[-1]
    s20, s50, s200 = sma(closes, 20), sma(closes, 50), sma(closes, 200)
    s50_prev = sma(closes[:-10], 50) if len(closes) >= 60 else None
    rsi = rsi_wilder(closes, 14)
    atr = atr_wilder(bars, 14)
    rv20, rv60 = realized_vol(closes, 20), realized_vol(closes, 60)
    r20, r60 = pct_return(closes, 20), pct_return(closes, 60)
    pctile = rv_percentile(closes)

    comps: list[dict] = []
    notes: list[str] = []

    def add(name: str, value: Optional[float], pts: float, rule: str, kind: str = "pct") -> None:
        comps.append({"name": name, "value": value, "points": pts, "rule": rule, "kind": kind})
        if value is None:
            notes.append(f"{name} unavailable (short history); scored 0.")

    def above(name: str, a: Optional[float], b: Optional[float], w: float) -> None:
        if a is None or b is None:
            add(name, None, 0.0, f"+/-{w:g}")
        else:
            add(name, a / b - 1.0, w if a > b else -w, f"+/-{w:g}")

    above("Px vs SMA20", px, s20, 1.0)
    above("Px vs SMA50", px, s50, 1.5)
    above("Px vs SMA200", px, s200, 2.0)
    above("SMA20 vs SMA50", s20, s50, 1.0)
    above("SMA50 vs SMA200", s50, s200, 1.5)
    above("SMA50 10d slope", s50, s50_prev, 0.5)
    if rsi is None:
        add("RSI14", None, 0.0, "", "num")
    else:
        p = 0.0 if rsi >= 75 else 1.0 if rsi >= 55 else 0.0 if rsi > 45 else -1.0 if rsi >= 30 else -1.5
        add("RSI14", rsi, p, ">=75:0(overbought) 55-75:+1 30-45:-1 <30:-1.5", "num")
    if r20 is None:
        add("20d return", None, 0.0, "")
    else:
        p = 1.5 if r20 > 0.04 else 0.5 if r20 > 0.01 else -1.5 if r20 < -0.04 else -0.5 if r20 < -0.01 else 0.0
        add("20d return", r20, p, ">4%:+1.5 >1%:+.5 <-1%:-.5 <-4%:-1.5")
    if r60 is None:
        add("60d return", None, 0.0, "")
    else:
        p = 1.5 if r60 > 0.08 else 0.5 if r60 > 0.02 else -1.5 if r60 < -0.08 else -0.5 if r60 < -0.02 else 0.0
        add("60d return", r60, p, ">8%:+1.5 >2%:+.5 <-2%:-.5 <-8%:-1.5")

    if pctile is None:
        vol_state = "UNKNOWN"
    elif pctile >= 0.90:
        vol_state = "STRESSED"
    elif pctile >= 0.70:
        vol_state = "ELEVATED"
    elif pctile <= 0.30:
        vol_state = "CALM"
    else:
        vol_state = "NORMAL"

    score = round(sum(c["points"] for c in comps), 2)
    ind = {"price": px, "sma20": s20, "sma50": s50, "sma200": s200, "rsi14": rsi,
           "atr14": atr, "atr14_pct": (atr / px) if atr else None, "rv20": rv20, "rv60": rv60,
           "ret20": r20, "ret60": r60, "bars": len(bars), "last_bar": bars[-1].date.isoformat()}
    return Regime(classify_regime_score(score), score, True, comps, ind, vol_state, pctile, notes)


def regime_preference(label: str) -> tuple[Optional[str], bool]:
    return {"STRONG_BULLISH": ("PUT", True), "BULLISH": ("PUT", False), "NEUTRAL": (None, False),
            "BEARISH": ("CALL", False), "STRONG_BEARISH": ("CALL", True)}.get(label, (None, False))


# =============================================================================
# PORTFOLIO CONTEXT (memory only)
# =============================================================================

@dataclass
class ShortOption:
    symbol: str
    right: str              # "C" | "P"
    strike: float
    expiration: dt.date
    contracts: int
    entry: Optional[float]  # per share, if known

    @property
    def label(self) -> str:
        return f"{self.symbol} {self.expiration.isoformat()} {self.strike:g}{self.right}"


@dataclass
class PortfolioContext:
    cash: float = 0.0
    holdings: dict = field(default_factory=dict)
    shorts: list = field(default_factory=list)
    watchlist: list = field(default_factory=list)
    delta_lo: float = 0.15
    delta_hi: float = 0.20
    assignment_ok: bool = False
    source: str = "interactive"


@dataclass(frozen=True)
class DeltaBands:
    lo: float
    hi: float
    fb_lo: float
    fb_hi: float
    fin_lo: float
    fin_hi: float

    @staticmethod
    def build(lo: float, hi: float, cfg: Config) -> "DeltaBands":
        return DeltaBands(lo, hi, max(0.02, lo - cfg.fallback_pad), min(0.60, hi + cfg.fallback_pad),
                          max(0.02, lo - cfg.final_pad), min(0.60, hi + cfg.final_pad))

    @property
    def center(self) -> float:
        return (self.lo + self.hi) / 2.0

    def tier(self, d: float) -> int:
        if self.lo <= d <= self.hi:
            return 1
        if self.fb_lo <= d <= self.fb_hi:
            return 2
        if self.fin_lo <= d <= self.fin_hi:
            return 3
        return 0

    def fit(self, d: float) -> float:
        half = (self.hi - self.lo) / 2.0
        if self.lo <= d <= self.hi:
            return 1.0 - 0.3 * abs(d - self.center) / half if half > 0 else 1.0
        if self.fb_lo <= d <= self.fb_hi:
            out = (self.lo - d) if d < self.lo else (d - self.hi)
            span = max(1e-9, self.lo - self.fb_lo if d < self.lo else self.fb_hi - self.hi)
            return 0.7 - 0.3 * clamp(out / span)
        if self.fin_lo <= d <= self.fin_hi:
            out = (self.fb_lo - d) if d < self.fb_lo else (d - self.fb_hi)
            span = max(1e-9, self.fb_lo - self.fin_lo if d < self.fb_lo else self.fin_hi - self.fb_hi)
            return 0.4 - 0.3 * clamp(out / span)
        return 0.0


# ---- input parsing -----------------------------------------------------------

NONE_WORDS = {"", "NONE", "N", "NO", "0", "-", "NA", "N/A"}


def parse_ticker(tok: str) -> str:
    s = tok.strip().upper().lstrip("$")
    if not TICKER_RE.match(s) or s in NONE_WORDS:
        raise ValueError(f"invalid ticker '{tok}'")
    return s


def parse_money(raw: str) -> float:
    s = raw.strip().lower().replace("$", "").replace(",", "").replace("_", "")
    if s in ("", "none", "no", "n"):
        return 0.0
    mult = 1.0
    if s.endswith("k"):
        mult, s = 1_000.0, s[:-1]
    elif s.endswith("m"):
        mult, s = 1_000_000.0, s[:-1]
    try:
        v = float(s) * mult
    except ValueError:
        raise ValueError(f"cannot parse amount '{raw}'") from None
    if v < 0 or math.isnan(v) or math.isinf(v):
        raise ValueError("amount must be >= 0")
    return v


def parse_holdings(raw: str) -> dict:
    if raw.strip().upper() in NONE_WORDS:
        return {}
    out: dict[str, int] = {}
    pat = re.compile(r"^\$?([A-Za-z][A-Za-z0-9.]*)[\s:=]+([0-9][0-9,]*(?:\.[0-9]+)?)(?:\s*(?:sh|shares))?$", re.I)
    for part in re.split(r"[,;\n]+", raw):
        part = part.strip()
        if not part:
            continue
        m = pat.match(part)
        if not m:
            raise ValueError(f"cannot parse holding '{part}' (use: TICKER SHARES)")
        sym = parse_ticker(m.group(1))
        qty = int(math.floor(float(m.group(2).replace(",", ""))))
        out[sym] = out.get(sym, 0) + qty
    return {k: v for k, v in out.items() if v > 0}


def parse_symbols(raw: str) -> list:
    if raw.strip().upper() in NONE_WORDS:
        return []
    out: list[str] = []
    for tok in re.split(r"[,;\s]+", raw):
        if tok.strip():
            s = parse_ticker(tok)
            if s not in out:
                out.append(s)
    return out


def parse_date(tok: str) -> dt.date:
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%Y%m%d", "%y%m%d"):
        try:
            return dt.datetime.strptime(tok.strip(), fmt).date()
        except ValueError:
            continue
    raise ValueError(f"cannot parse date '{tok}' (use YYYY-MM-DD)")


def parse_short(raw: str) -> ShortOption:
    toks = raw.replace(",", " ").split()
    if not toks:
        raise ValueError("empty entry")
    occ = parse_occ(toks[0])
    if occ is not None:
        if len(toks) < 2:
            raise ValueError("OCC form needs contracts: OCCSYMBOL CONTRACTS [ENTRY]")
        contracts = abs(int(float(toks[1])))
        entry = float(toks[2].lstrip("$")) if len(toks) > 2 else None
        sym, right, strike, exp = occ.root, occ.right, occ.strike, occ.expiration
    else:
        if len(toks) < 5:
            raise ValueError("expected: TICKER C|P STRIKE YYYY-MM-DD CONTRACTS [ENTRY]")
        sym = parse_ticker(toks[0])
        r = toks[1].upper()
        if r in ("C", "CALL", "CALLS"):
            right = "C"
        elif r in ("P", "PUT", "PUTS"):
            right = "P"
        else:
            raise ValueError(f"option type must be C or P, got '{toks[1]}'")
        try:
            strike = float(toks[2].lstrip("$"))
        except ValueError:
            raise ValueError(f"bad strike '{toks[2]}'") from None
        exp = parse_date(toks[3])
        try:
            contracts = abs(int(float(toks[4])))
        except ValueError:
            raise ValueError(f"bad contracts '{toks[4]}'") from None
        entry = None
        if len(toks) > 5:
            try:
                entry = float(toks[5].lstrip("$"))
            except ValueError:
                raise ValueError(f"bad entry premium '{toks[5]}'") from None
    if strike <= 0 or contracts < 1:
        raise ValueError("strike must be > 0 and contracts >= 1")
    if entry is not None and entry <= 0:
        entry = None
    return ShortOption(sym, right, strike, exp, contracts, entry)


def parse_delta_range(raw: str) -> tuple[float, float]:
    s = raw.strip()
    if not s:
        return 0.15, 0.20
    parts = re.split(r"\s*(?:-|to|,|\s)\s*", s)
    parts = [p for p in parts if p]
    if len(parts) != 2:
        raise ValueError("use LOW-HIGH, e.g. 0.15-0.20")
    lo, hi = float(parts[0]), float(parts[1])
    if lo > 1 or hi > 1:
        lo, hi = lo / 100.0, hi / 100.0
    if lo > hi:
        lo, hi = hi, lo
    if not (0.03 <= lo < hi <= 0.50):
        raise ValueError("delta range must satisfy 0.03 <= low < high <= 0.50")
    return lo, hi


def parse_yes_no(raw: str) -> bool:
    s = raw.strip().lower()
    if s in ("y", "yes", "true", "1"):
        return True
    if s in ("", "n", "no", "false", "0"):
        return False
    raise ValueError("answer y or n")


# ---- interactive questionnaire (prompts on stderr so --json stdout stays clean)

class Prompter:
    def __init__(self) -> None:
        self.tty = sys.stdin.isatty()

    def ask(self, prompt: str) -> Optional[str]:
        sys.stderr.write(prompt)
        sys.stderr.flush()
        line = sys.stdin.readline()
        if line == "":
            return None
        return line.strip()

    def ask_parsed(self, prompt: str, parser, default: Any) -> Any:
        for _ in range(3):
            raw = self.ask(prompt)
            if raw is None:
                return default
            if raw == "" and default is not None:
                return default
            try:
                return parser(raw)
            except ValueError as exc:
                sys.stderr.write(f"   ! {exc}\n")
                if not self.tty:
                    raise InputError(str(exc)) from None
        raise InputError("too many invalid attempts")


def collect_interactive() -> PortfolioContext:
    p = Prompter()
    e = sys.stderr.write
    e("\n=== PORTFOLIO CONTEXT (kept in memory only; nothing is saved) ===\n")
    cash = p.ask_parsed("1) Cash available for NEW cash-secured puts\n"
                        "   (exclude cash already securing open puts) [$0]: ", parse_money, 0.0)
    holdings = p.ask_parsed("2) Stock/ETF holdings, e.g. 'QQQ 700, AAPL 150' [NONE]: ",
                            parse_holdings, {})
    e("3) Existing SHORT options, one per line:\n"
      "   TICKER C|P STRIKE YYYY-MM-DD CONTRACTS [ENTRY_PREMIUM_PER_SHARE]\n"
      "   e.g. 'QQQ C 720 2026-07-17 2 3.15'. Blank line or NONE when done.\n")
    shorts: list[ShortOption] = []
    while True:
        raw = p.ask("   short> ")
        if raw is None or raw.strip().upper() in NONE_WORDS | {"DONE", "END"}:
            break
        ok = True
        for chunk in raw.split(";"):
            if not chunk.strip():
                continue
            try:
                shorts.append(parse_short(chunk))
            except ValueError as exc:
                ok = False
                e(f"   ! {exc}\n")
                if not p.tty:
                    raise InputError(str(exc)) from None
        if ok and len(shorts) >= 30:
            break
    watch = p.ask_parsed("4) Extra watchlist tickers for new CSPs, e.g. 'SPY, NVDA'\n"
                         "   (held tickers are included automatically) [NONE]: ", parse_symbols, [])
    lo, hi = p.ask_parsed("5) Preferred delta range [0.15-0.20]: ", parse_delta_range, (0.15, 0.20))
    assign_ok = False
    if cash > 0:
        assign_ok = p.ask_parsed("6) Is assignment acceptable on cash-secured puts? [y/N]: ",
                                 parse_yes_no, False)
        if not assign_ok:
            e("   -> Every CSP can be assigned; new CSPs will be excluded.\n")
    e("\n")
    return PortfolioContext(cash, holdings, shorts, watch, lo, hi, assign_ok, "interactive")


def collect_from_args(args: argparse.Namespace) -> PortfolioContext:
    try:
        cash = parse_money(args.cash) if args.cash is not None else 0.0
        holdings = parse_holdings(args.holdings) if args.holdings else {}
        shorts = [parse_short(s) for s in (args.short or [])]
        watch = parse_symbols(args.watch) if args.watch else []
        lo, hi = parse_delta_range(args.delta) if args.delta else (0.15, 0.20)
        assign_ok = parse_yes_no(args.assignment) if args.assignment else False
    except ValueError as exc:
        raise InputError(str(exc)) from None
    return PortfolioContext(cash, holdings, shorts, watch, lo, hi, assign_ok, "cli flags")


# =============================================================================
# MARKET DATA PER SYMBOL
# =============================================================================

@dataclass
class Diagnostics:
    rejections: dict = field(default_factory=dict)
    total_contracts: int = 0
    parsed_contracts: int = 0

    def reject(self, reason: str) -> None:
        self.rejections[reason] = self.rejections.get(reason, 0) + 1


@dataclass
class MarketData:
    symbol: str
    ok: bool = False
    error: Optional[str] = None
    spot: Optional[float] = None
    spot_source: str = ""
    feed_spot: Optional[float] = None
    chain_timestamp: str = ""
    history_source: Optional[str] = None
    history_bars: int = 0
    history_last: Optional[str] = None
    history_errors: list = field(default_factory=list)
    rv20: Optional[float] = None
    rv60: Optional[float] = None
    rv_blend: Optional[float] = None
    regime: Regime = field(default_factory=Regime)
    model_greeks: bool = False
    rows_by_exp: dict = field(default_factory=dict)
    quote_index: dict = field(default_factory=dict)
    expirations: list = field(default_factory=list)
    selected_exps: list = field(default_factory=list)
    window_note: str = ""
    exp_info: dict = field(default_factory=dict)
    cands: list = field(default_factory=list)
    diag: Diagnostics = field(default_factory=Diagnostics)
    warnings: list = field(default_factory=list)

    @property
    def primary_exp(self) -> Optional[dt.date]:
        if not self.selected_exps:
            return None
        return min(self.selected_exps, key=lambda e: abs((e - self._today).days - 33)) \
            if hasattr(self, "_today") else self.selected_exps[0]


def select_expirations(exps: list, today: dt.date, cfg: Config) -> tuple[list, str]:
    avail = set(exps)
    future = [e for e in exps if e >= today]
    monthly = [e for e in future if is_standard_monthly(e, avail)]
    pool = future if cfg.allow_weeklies else monthly
    kind = "monthly+weekly" if cfg.allow_weeklies else "standard monthly"
    win = [e for e in pool if cfg.dte_min <= (e - today).days <= cfg.dte_max]
    if win:
        return win, f"{kind}, {cfg.dte_min}-{cfg.dte_max} DTE"
    ext = [e for e in pool if cfg.dte_ext_min <= (e - today).days <= cfg.dte_ext_max]
    if ext:
        center = (cfg.dte_pref_min + cfg.dte_pref_max) / 2.0
        best = min(ext, key=lambda e: abs((e - today).days - center))
        return [best], (f"{kind}; none in {cfg.dte_min}-{cfg.dte_max} DTE, using extended "
                        f"{cfg.dte_ext_min}-{cfg.dte_ext_max} window (penalized)")
    return [], f"no {kind} expiration within {cfg.dte_ext_min}-{cfg.dte_ext_max} DTE"


def atm_stats_for(md: MarketData, exp: dt.date, cfg: Config, now_u: dt.datetime,
                  today: dt.date) -> dict:
    """One consistent ATM IV / expected move per expiration (shared by calls and puts)."""
    if exp in md.exp_info:
        return md.exp_info[exp]
    spot = md.spot or 0.0
    t = years_to_expiry(exp, now_u)
    strikes: dict[float, dict] = {}
    for occ, o in md.rows_by_exp.get(exp, []):
        strikes.setdefault(occ.strike, {})[occ.right] = o
    atm_strike = atm_iv = straddle = None
    for K in sorted(strikes, key=lambda k: abs(k - spot)):
        ivs, mids = [], {}
        for right in ("C", "P"):
            o = strikes[K].get(right)
            if not o:
                continue
            bid, ask = safe_float(o.get("bid")), safe_float(o.get("ask"))
            mid = (bid + ask) / 2 if bid > 0 and ask >= bid else 0.0
            iv, _ = resolve_iv(right, o, mid, spot, K, t, cfg)
            if iv:
                ivs.append(iv)
            if mid > 0:
                mids[right] = mid
        if straddle is None and "C" in mids and "P" in mids:
            straddle = mids["C"] + mids["P"]
        if ivs:
            atm_strike, atm_iv = K, sum(ivs) / len(ivs)
            break
    em_source = "ATM IV"
    em = spot * atm_iv * math.sqrt(t) if atm_iv else None
    if em is None and straddle:
        em = straddle * 1.25  # ATM straddle ~= 0.8 * sigma * S * sqrt(t)  (approximation)
        atm_iv = em / (spot * math.sqrt(t)) if spot > 0 else None
        em_source = "ATM straddle x1.25"
    info = {"dte": (exp - today).days, "t_years": t, "atm_strike": atm_strike, "atm_iv": atm_iv,
            "straddle_mid": straddle, "expected_move": em,
            "expected_move_pct": (em / spot) if em and spot else None,
            "em_source": em_source if em else "unavailable",
            "atm_iv_rv": (atm_iv / md.rv_blend) if atm_iv and md.rv_blend else None,
            "standard_monthly": is_standard_monthly(exp, set(md.expirations))}
    md.exp_info[exp] = info
    return info


def load_market(http: Http, symbol: str, cfg: Config, price_override: Optional[float],
                now_u: dt.datetime, today: dt.date) -> MarketData:
    md = MarketData(symbol=symbol)
    md._today = today  # type: ignore[attr-defined]
    try:
        chain = fetch_cboe_chain(http, symbol)
    except DataError as exc:
        md.error = f"option chain unavailable: {exc}"
        return md
    md.feed_spot = chain.spot
    md.chain_timestamp = chain.timestamp
    bars, hs, herr = get_history(http, symbol)
    md.history_source, md.history_bars, md.history_errors = hs, len(bars), herr
    md.history_last = bars[-1].date.isoformat() if bars else None
    if not bars:
        md.warnings.append(f"{symbol}: price history unavailable; regime NEUTRAL, IV/RV neutral.")

    if price_override is not None:
        md.spot, md.spot_source = price_override, "user --price override"
        if chain.spot and abs(price_override / chain.spot - 1.0) > 0.005:
            md.model_greeks = True
            md.warnings.append(f"{symbol}: --price {price_override:.2f} differs from feed "
                               f"{chain.spot:.2f}; deltas recomputed from IV but premiums are "
                               "still live quotes (approximate what-if).")
    elif chain.spot:
        md.spot, md.spot_source = chain.spot, "CBOE delayed"
    elif bars:
        md.spot, md.spot_source = bars[-1].close, f"last close ({hs})"
    else:
        md.error = "no underlying price available"
        return md
    if bars and chain.spot and abs(bars[-1].close / chain.spot - 1.0) > 0.05:
        md.warnings.append(f"{symbol}: history close {bars[-1].close:.2f} differs >5% from chain "
                           f"spot {chain.spot:.2f}; check data freshness / splits.")

    closes = [b.close for b in bars]
    md.rv20, md.rv60 = realized_vol(closes, 20), realized_vol(closes, 60)
    rvs = [v for v in (md.rv20, md.rv60) if v]
    md.rv_blend = sum(rvs) / len(rvs) if rvs else None
    md.regime = compute_regime(bars, md.spot)

    root_wanted = symbol.replace(".", "")
    md.diag.total_contracts = len(chain.options)
    exps: set = set()
    for o in chain.options:
        if not isinstance(o, dict):
            md.diag.reject("bad_record")
            continue
        occ = parse_occ(str(o.get("option", "")))
        if occ is None:
            md.diag.reject("unparseable_symbol")
            continue
        if occ.root != root_wanted:
            md.diag.reject("nonstandard_root")  # e.g. adjusted deliverables like QQQ1
            continue
        md.diag.parsed_contracts += 1
        exps.add(occ.expiration)
        md.rows_by_exp.setdefault(occ.expiration, []).append((occ, o))
        md.quote_index[(occ.expiration, occ.right, round(occ.strike, 3))] = o
    if not exps:
        md.error = "no parseable standard-root contracts in chain"
        return md
    md.expirations = sorted(exps)
    md.selected_exps, md.window_note = select_expirations(md.expirations, today, cfg)
    for e in md.selected_exps:
        atm_stats_for(md, e, cfg, now_u, today)
    md.ok = True
    return md


# =============================================================================
# CANDIDATES
# =============================================================================

@dataclass
class Candidate:
    underlying: str
    side: str                 # CALL | PUT
    strategy: str             # COVERED_CALL | CASH_SECURED_PUT
    contract: str
    expiration: dt.date
    dte: int
    t_years: float
    standard_monthly: bool
    spot: float
    strike: float
    bid: float
    ask: float
    mid: float
    last: float
    spread: float
    spread_pct: float
    iv: float
    iv_source: str
    delta: float              # absolute
    delta_source: str
    open_interest: int
    volume: int
    atm_iv: Optional[float]
    expected_move: float
    expected_move_pct: float
    em_source: str
    distance: float
    distance_pct: float
    em_ratio: float
    premium_share: float
    credit_mid: float         # per contract
    credit_bid: float
    capital: float            # per contract
    roc: float
    annualized_roc: float
    breakeven: float
    assignment_metric: float
    prob_itm: float
    prob_touch: float
    iv_rv: Optional[float]
    atm_iv_rv: Optional[float]
    theo_at_rv: Optional[float]
    vol_edge_contract: Optional[float]
    delta_tier: int = 0
    factors: dict = field(default_factory=dict)
    penalties: dict = field(default_factory=dict)
    raw_score: float = 0.0
    disqualified: list = field(default_factory=list)
    adjustments: dict = field(default_factory=dict)
    final_score: float = 0.0
    threshold: float = 0.0
    viable: bool = False
    max_contracts: int = 0
    suggested_contracts: int = 0
    sizing_note: str = ""
    concentration_pre: Optional[float] = None
    concentration_post: Optional[float] = None

    @property
    def qualifies_hard(self) -> bool:
        return not self.disqualified

    @property
    def short_label(self) -> str:
        return f"{self.underlying} {self.expiration.isoformat()} {self.strike:g}{'C' if self.side == 'CALL' else 'P'}"


def make_candidate(underlying: str, occ: OccSymbol, o: dict, spot: float, cfg: Config,
                   now_u: dt.datetime, today: dt.date, info: dict, rv_blend: Optional[float],
                   model_greeks: bool, diag: Diagnostics, d_lo: float, d_hi: float) -> Optional[Candidate]:
    right, K = occ.right, occ.strike
    side = "CALL" if right == "C" else "PUT"
    if (side == "CALL" and K <= spot) or (side == "PUT" and K >= spot):
        diag.reject("not_otm")
        return None
    bid, ask = safe_float(o.get("bid")), safe_float(o.get("ask"))
    if bid <= 0:
        diag.reject("no_bid")
        return None
    if ask <= 0 or ask < bid:
        diag.reject("bad_quote")
        return None
    em = info.get("expected_move")
    if not em or em <= 0:
        diag.reject("no_expected_move")
        return None
    mid = (bid + ask) / 2.0
    dte = (occ.expiration - today).days
    t = years_to_expiry(occ.expiration, now_u)
    r, q = cfg.risk_free, cfg.div_yield
    iv, iv_src = resolve_iv(right, o, mid, spot, K, t, cfg)
    if iv is None:
        diag.reject("no_iv")
        return None
    fd = safe_float(o.get("delta"))
    if not model_greeks and 0.0 < abs(fd) < 1.0:
        delta, d_src = abs(fd), "feed"
    else:
        delta, d_src = abs(bs_delta(right, spot, K, t, r, q, iv)), "model"
    if not (d_lo <= delta <= d_hi):
        diag.reject("delta_out_of_range")
        return None

    spread = ask - bid
    spread_pct = spread / mid if mid > 0 else 1.0
    distance = (K - spot) if side == "CALL" else (spot - K)
    em_ratio = distance / em
    if side == "PUT":
        capital = K * 100.0                      # cash-secured: strike x 100 (approx.)
        roc = mid / K
        breakeven = K - mid
        assign_metric = (spot - (K - mid)) / spot  # effective purchase discount vs spot
    else:
        capital = spot * 100.0                   # value of the 100 shares committed
        roc = mid / spot
        breakeven = spot - mid                   # downside breakeven on shares from today
        assign_metric = (K - spot + mid) / spot  # total return if called away
    annual = roc * 365.0 / max(dte, 1)
    p_itm = bs_prob_itm(right, spot, K, t, r, q, iv)
    p_touch = min(1.0, 2.0 * p_itm)  # reflection-principle approximation
    theo = edge = iv_rv = None
    if rv_blend and rv_blend > 0:
        theo = bs_price(right, spot, K, t, r, q, rv_blend)
        edge = (mid - theo) * 100.0
        iv_rv = iv / rv_blend
    atm_iv = info.get("atm_iv")
    c = Candidate(
        underlying=underlying, side=side,
        strategy="COVERED_CALL" if side == "CALL" else "CASH_SECURED_PUT",
        contract=str(o.get("option", "")), expiration=occ.expiration, dte=dte, t_years=t,
        standard_monthly=bool(info.get("standard_monthly")), spot=spot, strike=K,
        bid=bid, ask=ask, mid=mid, last=safe_float(o.get("last_trade_price")),
        spread=spread, spread_pct=spread_pct, iv=iv, iv_source=iv_src, delta=delta,
        delta_source=d_src, open_interest=safe_int(o.get("open_interest")),
        volume=safe_int(o.get("volume")), atm_iv=atm_iv, expected_move=em,
        expected_move_pct=em / spot, em_source=str(info.get("em_source")),
        distance=distance, distance_pct=distance / spot, em_ratio=em_ratio,
        premium_share=mid, credit_mid=mid * 100.0, credit_bid=bid * 100.0, capital=capital,
        roc=roc, annualized_roc=annual, breakeven=breakeven, assignment_metric=assign_metric,
        prob_itm=p_itm, prob_touch=p_touch, iv_rv=iv_rv,
        atm_iv_rv=(atm_iv / rv_blend) if atm_iv and rv_blend else None,
        theo_at_rv=theo, vol_edge_contract=edge,
    )
    if mid < cfg.min_mid:
        c.disqualified.append(f"mid {mid:.2f} < {cfg.min_mid:.2f}")
    if bid < cfg.min_bid:
        c.disqualified.append(f"bid {bid:.2f} < {cfg.min_bid:.2f}")
    if spread_pct > cfg.max_spread_pct and spread > cfg.spread_abs_ok:
        c.disqualified.append(f"spread {spread_pct * 100:.1f}% > {cfg.max_spread_pct * 100:.0f}%")
    if c.open_interest < cfg.min_oi:
        c.disqualified.append(f"OI {c.open_interest} < {cfg.min_oi}")
    if em_ratio < cfg.min_em_ratio:
        c.disqualified.append(f"dist/EM {em_ratio:.2f} < {cfg.min_em_ratio:.2f}")
    return c


def score_raw(c: Candidate, cfg: Config, bands: DeltaBands) -> None:
    """Contract-quality score 0-100 (no portfolio context)."""
    d = c.delta
    c.delta_tier = bands.tier(d)
    delta_fit = bands.fit(d)
    em_cov = lin(c.em_ratio, 0.50, 1.00)
    y0, y1 = YIELD_SCALE[c.side]
    yld = lin(c.annualized_roc, y0, y1)
    spread_q = lin(c.spread_pct, 0.15, 0.02)
    oi_q = lin(math.log10(c.open_interest + 1), 1.0, math.log10(5000))
    vol_q = lin(math.log10(c.volume + 1), 0.0, math.log10(1000))
    liq = 0.6 * oi_q + 0.4 * vol_q
    if cfg.dte_pref_min <= c.dte <= cfg.dte_pref_max:
        dte_fit = 1.0
    elif cfg.dte_min <= c.dte < cfg.dte_pref_min:
        dte_fit = 0.5 + 0.5 * lin(c.dte, cfg.dte_min, cfg.dte_pref_min)
    elif cfg.dte_pref_max < c.dte <= cfg.dte_max:
        dte_fit = 0.5 + 0.5 * lin(c.dte, cfg.dte_max, cfg.dte_pref_max)
    else:
        dte_fit = 0.3
    # ATM IV / RV is identical for both sides of an expiration -> no skew bias.
    vol_edge = 0.5 if c.atm_iv_rv is None else lin(c.atm_iv_rv, 0.85, 1.40)
    raw = {"delta_fit": delta_fit, "em_coverage": em_cov, "premium_yield": yld,
           "spread": spread_q, "liquidity": liq, "dte_fit": dte_fit, "vol_edge": vol_edge}
    c.factors = {k: {"factor": round(v, 4), "points": round(v * WEIGHTS[k], 2), "weight": WEIGHTS[k]}
                 for k, v in raw.items()}
    pen: dict[str, float] = {}
    if d > bands.hi:
        pen["excessive_delta"] = -(d - bands.hi) * 250.0
    if c.em_ratio < 0.75:
        pen["poor_em_coverage"] = -(0.75 - c.em_ratio) * 50.0
    if c.spread_pct > cfg.wide_spread_pct and c.spread > cfg.spread_abs_ok:
        pen["wide_spread"] = -min(15.0, (c.spread_pct - cfg.wide_spread_pct) * 100.0)
    if c.open_interest < cfg.adequate_oi:
        pen["poor_liquidity_oi"] = -8.0 * (1.0 - c.open_interest / cfg.adequate_oi)
    if c.volume == 0:
        pen["no_volume_today"] = -3.0
    if c.mid < cfg.adequate_mid:
        pen["low_premium"] = -10.0 * (1.0 - c.mid / cfg.adequate_mid)
    if c.annualized_roc < cfg.min_annual_roc:
        pen["low_annualized_roc"] = -5.0
    if c.dte < cfg.dte_pref_min:
        pen["dte_outside_pref"] = -min(7.0, float(cfg.dte_pref_min - c.dte))
    elif c.dte > cfg.dte_pref_max:
        pen["dte_outside_pref"] = -min(7.0, float(c.dte - cfg.dte_pref_max))
    if not c.standard_monthly:
        pen["weekly_expiration"] = -3.0
    c.penalties = {k: round(v, 2) for k, v in pen.items()}
    total = sum(f["points"] for f in c.factors.values()) + sum(c.penalties.values())
    c.raw_score = round(clamp(total, 0.0, 100.0), 2)
    c.final_score = c.raw_score


def build_candidates(md: MarketData, cfg: Config, bands: DeltaBands, now_u: dt.datetime,
                     today: dt.date) -> None:
    for e in md.selected_exps:
        info = atm_stats_for(md, e, cfg, now_u, today)
        for occ, o in md.rows_by_exp.get(e, []):
            c = make_candidate(md.symbol, occ, o, md.spot or 0.0, cfg, now_u, today, info,
                               md.rv_blend, md.model_greeks, md.diag, bands.fin_lo, bands.fin_hi)
            if c is not None:
                score_raw(c, cfg, bands)
                md.cands.append(c)


# =============================================================================
# PORTFOLIO STATE
# =============================================================================

def portfolio_state(ctx: PortfolioContext, markets: dict) -> dict:
    prices = {s: md.spot for s, md in markets.items() if md.ok and md.spot}
    short_calls: dict[str, int] = {}
    short_put_notional: dict[str, float] = {}
    for p in ctx.shorts:
        if p.right == "C":
            short_calls[p.symbol] = short_calls.get(p.symbol, 0) + p.contracts
        else:
            short_put_notional[p.symbol] = short_put_notional.get(p.symbol, 0.0) + p.strike * 100 * p.contracts
    holdings: dict[str, dict] = {}
    warnings: list[str] = []
    hold_value = 0.0
    group_exp: dict[str, float] = {}
    for sym, sh in ctx.holdings.items():
        px = prices.get(sym)
        committed = min(sh, short_calls.get(sym, 0) * 100)
        uncovered = max(0, short_calls.get(sym, 0) * 100 - sh)
        free = sh - committed
        val = sh * px if px else None
        if val is not None:
            hold_value += val
            g, lev = exposure_key(sym)
            group_exp[g] = group_exp.get(g, 0.0) + val * lev
        else:
            warnings.append(f"{sym}: no price; holding excluded from portfolio value.")
        holdings[sym] = {"shares": sh, "price": px, "value": val, "committed_shares": committed,
                         "free_shares": free, "free_lots": free // 100, "uncovered_call_shares": uncovered}
        if uncovered:
            warnings.append(f"{sym}: short calls cover {short_calls[sym] * 100} shares but only {sh} "
                            f"held -> {uncovered} shares UNCOVERED (naked call risk).")
    for sym, n in short_calls.items():
        if sym not in ctx.holdings:
            warnings.append(f"{sym}: {n} short call(s) with no shares reported -> UNCOVERED (naked) calls.")
    for sym, notional in short_put_notional.items():
        g, lev = exposure_key(sym)
        group_exp[g] = group_exp.get(g, 0.0) + notional * lev
    total = ctx.cash + hold_value + sum(short_put_notional.values())
    return {"total_value": total, "holdings_value": hold_value, "holdings": holdings,
            "short_calls": short_calls, "short_put_notional": short_put_notional,
            "group_exposure": group_exp, "warnings": warnings}


def group_concentration(state: dict, sym: str, add_notional: float = 0.0) -> Optional[float]:
    total = state["total_value"]
    if total <= 0:
        return None
    g, lev = exposure_key(sym)
    return abs(state["group_exposure"].get(g, 0.0) + add_notional * lev) / total


def conc_limit(sym: str, cfg: Config) -> float:
    g, _ = exposure_key(sym)
    return cfg.conc_limit_broad if g in BROAD_GROUPS else cfg.conc_limit_other


# =============================================================================
# EXISTING POSITION MANAGEMENT
# =============================================================================

@dataclass
class MgmtResult:
    position: ShortOption
    action: str = "NO_ACTION"   # HOLD | CLOSE | ROLL | LET_EXPIRE | NO_ACTION
    urgency: int = 0            # 3 risk, 2 economics, 1 watch, 0 routine
    reasons: list = field(default_factory=list)
    metrics: dict = field(default_factory=dict)
    quote_source: str = ""
    contract: str = ""
    replacement: Optional[Candidate] = None
    roll: Optional[dict] = None


def find_roll(pos: ShortOption, cur_mid: float, cur_ask: Optional[float], md: MarketData,
              cfg: Config, bands: DeltaBands, now_u: dt.datetime, today: dt.date) -> Optional[dict]:
    """Later expiration, same or better strike, quality-gated, net credit at mid."""
    cur_dte = (pos.expiration - today).days
    lo_dte = max(cfg.dte_ext_min, cur_dte + 7)
    avail = set(md.expirations)
    exps = [e for e in md.expirations if e > pos.expiration and lo_dte <= (e - today).days <= cfg.roll_dte_max
            and (cfg.allow_weeklies or is_standard_monthly(e, avail))]
    best: Optional[Candidate] = None
    diag = Diagnostics()
    for e in exps:
        info = atm_stats_for(md, e, cfg, now_u, today)
        for occ, o in md.rows_by_exp.get(e, []):
            if occ.right != pos.right:
                continue
            if pos.right == "C" and occ.strike < pos.strike:
                continue
            if pos.right == "P" and occ.strike > pos.strike:
                continue
            c = make_candidate(md.symbol, occ, o, md.spot or 0.0, cfg, now_u, today, info, md.rv_blend,
                               md.model_greeks, diag, 0.05, cfg.roll_max_delta)
            if c is None or not c.qualifies_hard or c.mid - cur_mid < 0:
                continue
            score_raw(c, cfg, bands)
            if best is None or c.raw_score > best.raw_score:
                best = c
    if best is None:
        return None
    close_px = cur_ask if cur_ask else cur_mid
    net_mid = best.mid - cur_mid
    net_cons = best.bid - close_px
    return {"candidate": best, "close_mid": cur_mid, "close_ask": cur_ask, "open_mid": best.mid,
            "open_bid": best.bid, "net_mid_share": net_mid, "net_cons_share": net_cons,
            "net_mid_total": net_mid * 100 * pos.contracts, "net_cons_total": net_cons * 100 * pos.contracts}


def evaluate_short(pos: ShortOption, md: Optional[MarketData], ctx: PortfolioContext, state: dict,
                   cfg: Config, bands: DeltaBands, now_u: dt.datetime, today: dt.date) -> MgmtResult:
    res = MgmtResult(position=pos)
    if md is None or not md.ok or not md.spot:
        res.reasons.append("Market data unavailable for this underlying; review manually.")
        return res
    S, K, right = md.spot, pos.strike, pos.right
    dte = (pos.expiration - today).days
    if dte < 0:
        res.reasons.append("Expiration date has passed; confirm expiry/assignment status with broker.")
        return res
    t = years_to_expiry(pos.expiration, now_u)
    r, q = cfg.risk_free, cfg.div_yield
    o = md.quote_index.get((pos.expiration, right, round(K, 3)))
    bid = ask = mid = iv = None
    iv_src = "none"
    if o:
        res.contract = str(o.get("option", ""))
        b, a = safe_float(o.get("bid")), safe_float(o.get("ask"))
        if a > 0 and a >= b >= 0:
            bid, ask = b, a
            mid = (b + a) / 2.0 if b > 0 else a / 2.0
            res.quote_source = "CBOE delayed quote"
        elif safe_float(o.get("last_trade_price")) > 0:
            mid = safe_float(o.get("last_trade_price"))
            res.quote_source = "last trade (no valid bid/ask)"
        iv, iv_src = resolve_iv(right, o, mid or 0.0, S, K, t, cfg)
    if iv is None:
        near = min(md.selected_exps or md.expirations[:1] or [pos.expiration],
                   key=lambda e: abs((e - pos.expiration).days))
        info = atm_stats_for(md, near, cfg, now_u, today) if near in md.rows_by_exp else {}
        iv = info.get("atm_iv") or md.rv_blend
        iv_src = "proxy (ATM IV/RV)" if iv else "none"
    intrinsic = max(0.0, S - K) if right == "C" else max(0.0, K - S)
    if mid is None:
        if iv:
            mid = bs_price(right, S, K, t, r, q, iv)
            res.quote_source = "MODEL ESTIMATE (contract not found in chain)"
        else:
            mid = intrinsic
            res.quote_source = "intrinsic only (no quote, no IV)"
    fd = safe_float(o.get("delta")) if o else 0.0
    if o and not md.model_greeks and 0.0 < abs(fd) <= 1.0:
        delta, d_src = abs(fd), "feed"
    elif iv:
        delta, d_src = abs(bs_delta(right, S, K, t, r, q, iv)), "model"
    else:
        delta, d_src = (1.0 if intrinsic > 0 else 0.0), "intrinsic"
    itm = intrinsic > 0
    extrinsic = max(0.0, mid - intrinsic)
    otm = (K - S) if right == "C" else (S - K)
    info_e = atm_stats_for(md, pos.expiration, cfg, now_u, today) if pos.expiration in md.rows_by_exp else {}
    em = info_e.get("expected_move") or (S * iv * math.sqrt(t) if iv else None)
    p_itm = bs_prob_itm(right, S, K, t, r, q, iv) if iv else (1.0 if itm else 0.0)
    p_touch = 1.0 if itm else min(1.0, 2.0 * p_itm)
    collateral_base = K if right == "P" else S
    remaining_ann = (mid / collateral_base) * 365.0 / max(dte, 1)
    captured = (pos.entry - mid) / pos.entry if pos.entry else None
    pnl_total = (pos.entry - mid) * 100 * pos.contracts if pos.entry else None
    threatened = itm or delta >= cfg.threat_delta
    deep = delta >= cfg.deep_threat_delta or itm
    uncovered = right == "C" and state["holdings"].get(pos.symbol, {}).get("uncovered_call_shares", 0) > 0 \
        or (right == "C" and pos.symbol not in ctx.holdings)
    early_assign = itm and extrinsic < max(0.05, 0.002 * K)
    res.metrics = {"spot": S, "dte": dte, "bid": bid, "ask": ask, "mid": mid, "iv": iv, "iv_source": iv_src,
                   "delta": delta, "delta_source": d_src, "itm": itm, "intrinsic": intrinsic,
                   "extrinsic": extrinsic, "otm_distance": otm, "otm_pct": otm / S,
                   "expected_move": em, "em_ratio": (otm / em) if em else None, "prob_itm": p_itm,
                   "prob_touch": p_touch, "captured_pct": captured, "pnl_at_mid_total": pnl_total,
                   "buyback_cost_ask_total": (ask * 100 * pos.contracts) if ask else None,
                   "remaining_ann_yield": remaining_ann, "threatened": threatened,
                   "early_assignment_risk": early_assign, "uncovered": uncovered}

    def roll_or_none() -> Optional[dict]:
        return find_roll(pos, mid, ask, md, cfg, bands, now_u, today)

    def replacement() -> Optional[Candidate]:
        side = "CALL" if right == "C" else "PUT"
        pool = [c for c in md.cands if c.side == side and c.qualifies_hard]
        if side == "PUT":
            per_contract_cash = K * 100 + ctx.cash / max(pos.contracts, 1)
            pool = [c for c in pool if c.capital <= per_contract_cash]
        return max(pool, key=lambda c: c.raw_score, default=None)

    R = res.reasons
    if early_assign:
        R.append("ITM with little extrinsic value left: American-style early assignment risk is "
                 "elevated (especially before an ex-dividend date).")
    if dte <= 2:
        if not itm and delta < 0.15:
            res.action, res.urgency = "LET_EXPIRE", 1
            R.append(f"{dte} DTE, OTM, delta {delta:.2f}: remaining premium is small and buying back "
                     "would mostly pay the spread. Letting it expire is the model preference.")
        elif threatened:
            rl = roll_or_none()
            if rl:
                res.action, res.urgency, res.roll = "ROLL", 3, rl
                R.append("Near expiration and ITM/threatened: a later expiration at the same or better "
                         "strike is available for a net credit, which avoids assignment without paying to exit.")
            elif right == "P" and not ctx.assignment_ok:
                res.action, res.urgency = "CLOSE", 3
                R.append("Near expiration, ITM/threatened, no credit roll, and you said assignment is not "
                         "acceptable -> buy to close.")
            elif uncovered:
                res.action, res.urgency = "CLOSE", 3
                R.append("Threatened call is not covered by shares; assignment would create a short "
                         "stock position -> buy to close.")
            else:
                res.action, res.urgency = "HOLD", 1
                R.append("Near expiration and threatened, but no roll is available for a credit. "
                         + ("Assignment (buying shares at the strike) was declared acceptable."
                            if right == "P" else
                            "Assignment would sell your shares at the strike; close only if you must keep them."))
        else:
            res.action, res.urgency = "HOLD", 1
            R.append(f"{dte} DTE, delta {delta:.2f}: not clearly safe, not clearly threatened. Watch into the close.")
        return res

    if threatened:
        rl = roll_or_none()
        if rl and (dte <= 21 or deep):
            res.action, res.urgency, res.roll = "ROLL", 3, rl
            R.append(f"Strike threatened (delta {delta:.2f}{', ITM' if itm else ''}) with {dte} DTE. Gamma "
                     "risk rises as expiration nears; a roll out in time to the same/better strike is "
                     "available for a net credit, so risk is extended without paying a debit.")
        elif right == "P" and not ctx.assignment_ok and deep:
            res.action, res.urgency = "CLOSE", 3
            R.append(f"Deeply threatened put (delta {delta:.2f}) and assignment is not acceptable; no credit "
                     "roll found -> buy to close to cap the loss.")
        elif uncovered and deep:
            res.action, res.urgency = "CLOSE", 3
            R.append("Deeply threatened call that is not covered by shares -> buy to close.")
        else:
            res.action, res.urgency = "HOLD", 1
            if rl is None:
                R.append(f"Threatened (delta {delta:.2f}) but no quality roll exists for a net credit; rolling for "
                         "a debit just pays to extend risk. Holding; reassess as expiration approaches.")
            else:
                R.append(f"Threatened (delta {delta:.2f}) but {dte} DTE remain; a credit roll exists and can be "
                         "used later if the move continues. Not forced now (rolling is not automatic).")
        return res

    if captured is not None:
        remaining = mid / pos.entry
        if remaining <= 0.20 and dte > 3:
            res.action, res.urgency = "CLOSE", 2
            R.append(f"{captured * 100:.0f}% of the entry premium captured; only {f_usd(mid * 100)}/contract of "
                     "potential profit remains versus the full tail risk of staying short. Closing and "
                     "redeploying is the model preference.")
        elif remaining <= 0.50 and dte >= 21:
            res.action, res.urgency = "CLOSE", 2
            R.append(f"{captured * 100:.0f}% captured with {dte} DTE still remaining: the premium decayed faster "
                     "than time, so the remaining reward per day of risk is now poor.")
    if res.action == "NO_ACTION" and delta < 0.08 and dte > 7:
        rep = replacement()
        if rep and remaining_ann < rep.annualized_roc / 3.0:
            res.action, res.urgency = "CLOSE", 2
            R.append(f"Delta {delta:.2f}: remaining premium yields ~{f_pct(remaining_ann)} annualized versus "
                     f"~{f_pct(rep.annualized_roc)} for a fresh {rep.short_label}. Opportunity cost favors "
                     "closing and redeploying.")
    if res.action == "CLOSE":
        res.replacement = replacement()
        return res
    res.action = "HOLD"
    res.urgency = 1 if delta >= cfg.watch_delta else 0
    R.append(f"Delta {delta:.2f}, {dte} DTE"
             + (f", {captured * 100:.0f}% captured" if captured is not None else "")
             + ": within acceptable range; theta is still working. No action needed."
             + (" WATCH: delta above 0.30." if delta >= cfg.watch_delta else ""))
    if pos.entry is None:
        R.append("Entry premium not supplied; profit-capture rules skipped.")
    return res


# =============================================================================
# ELIGIBILITY + PORTFOLIO ADJUSTMENTS
# =============================================================================

def apply_adjustments(c: Candidate, md: MarketData, state: dict, ctx: PortfolioContext,
                      cfg: Config, pending: set) -> None:
    adj: dict[str, float] = {}
    pref, strong = regime_preference(md.regime.label)
    bonus = cfg.regime_bonus * (cfg.strong_regime_multiplier if strong else 1.0)
    if pref:
        adj["regime_alignment"] = bonus if c.side == pref else -bonus
    limit = conc_limit(c.underlying, cfg)
    c.concentration_pre = group_concentration(state, c.underlying, 0.0)
    _, lev = exposure_key(c.underlying)
    if c.side == "PUT":
        post = group_concentration(state, c.underlying, c.capital)
        c.concentration_post = post
        if post is not None and post > limit:
            adj["concentration"] = -min(cfg.conc_cap, (post - limit) * cfg.conc_slope)
        if md.regime.vol_state == "STRESSED":
            adj["vol_stress"] = -4.0
        elif md.regime.vol_state == "ELEVATED":
            adj["vol_elevated"] = -2.0
        util = c.capital / ctx.cash if ctx.cash > 0 else 1.0
        if util > 0.80:
            adj["cash_utilization"] = -4.0
        elif util > 0.50:
            adj["cash_utilization"] = -2.0
        if abs(lev) > 1:
            adj["leveraged_etf"] = -3.0
        max_cash = int(ctx.cash // c.capital) if c.capital > 0 else 0
        n_conc = 0
        for n in range(1, min(max_cash, 200) + 1):
            pc = group_concentration(state, c.underlying, n * c.capital)
            if pc is not None and pc <= limit:
                n_conc = n
            else:
                break
        c.max_contracts = max_cash
        if max_cash < 1:
            c.suggested_contracts = 0
            c.sizing_note = "insufficient cash"
        elif n_conc >= 1:
            c.suggested_contracts = n_conc
            c.sizing_note = f"largest qty within cash and {limit:.0%} exposure guideline"
        else:
            c.suggested_contracts = 1
            c.sizing_note = f"1 contract already exceeds {limit:.0%} exposure guideline (penalized)"
    else:
        c.concentration_post = c.concentration_pre
        if c.concentration_pre is not None and c.concentration_pre > limit:
            adj["concentration_relief"] = 2.0
        free_lots = state["holdings"].get(c.underlying, {}).get("free_lots", 0)
        c.max_contracts = free_lots
        if md.regime.label in ("BULLISH", "STRONG_BULLISH") and free_lots > 1:
            c.suggested_contracts = math.ceil(free_lots / 2)
            c.sizing_note = "partial coverage (~50% of free lots) keeps upside in a bullish regime"
        else:
            c.suggested_contracts = free_lots
            c.sizing_note = "cover free (uncommitted) lots"
    if (c.underlying, c.side) in pending:
        adj["resolve_existing_first"] = -cfg.pending_mgmt_penalty
    c.adjustments = {k: round(v, 2) for k, v in adj.items()}
    c.final_score = round(clamp(c.raw_score + sum(c.adjustments.values()), 0.0, 100.0), 2)
    th = cfg.min_score
    if strong and pref and c.side != pref:
        th += cfg.risk_gate
    c.threshold = th
    c.viable = c.qualifies_hard and c.final_score >= th and c.suggested_contracts >= 1


def build_eligibility(ctx: PortfolioContext, state: dict, markets: dict, mgmt: list,
                      cfg: Config) -> dict:
    out: dict[str, dict] = {}
    pending = {(m.position.symbol, "CALL" if m.position.right == "C" else "PUT")
               for m in mgmt if m.action in ("ROLL", "CLOSE")}
    threatened_puts = {m.position.symbol for m in mgmt
                       if m.position.right == "P" and m.metrics.get("threatened")}
    csp_syms: list[str] = []
    for s in list(ctx.watchlist) + list(ctx.holdings):
        if s not in csp_syms:
            csp_syms.append(s)

    for sym in ctx.holdings:
        key = f"{sym}:CALL"
        md = markets.get(sym)
        h = state["holdings"].get(sym, {})
        entry = {"symbol": sym, "side": "CALL", "eligible": False, "reason": "", "cands": [],
                 "excluded_cash": 0, "quality_fail": 0}
        if md is None or not md.ok:
            entry["reason"] = f"market data unavailable ({md.error if md else 'not loaded'})"
        elif h.get("free_lots", 0) < 1:
            entry["reason"] = (f"{h.get('shares', 0)} shares, {h.get('committed_shares', 0)} committed to "
                               f"existing short calls -> {h.get('free_shares', 0)} free (<100)")
        else:
            entry["eligible"] = True
            allc = [c for c in md.cands if c.side == "CALL"]
            entry["quality_fail"] = sum(1 for c in allc if not c.qualifies_hard)
            good = [c for c in allc if c.qualifies_hard]
            for c in good:
                apply_adjustments(c, md, state, ctx, cfg, pending)
            entry["cands"] = sorted(good, key=lambda c: (c.final_score, -abs(c.delta - (ctx.delta_lo + ctx.delta_hi) / 2)),
                                    reverse=True)
            entry["reason"] = (f"{h['free_lots']} free lot(s) ({h['free_shares']} uncommitted shares); "
                               f"{len(good)} quality contract(s) in delta/DTE window")
        out[key] = entry

    for sym in csp_syms:
        key = f"{sym}:PUT"
        md = markets.get(sym)
        entry = {"symbol": sym, "side": "PUT", "eligible": False, "reason": "", "cands": [],
                 "excluded_cash": 0, "quality_fail": 0}
        if not ctx.assignment_ok:
            entry["reason"] = "assignment declared unacceptable (every CSP can be assigned)"
        elif ctx.cash <= 0:
            entry["reason"] = "no cash supplied for CSPs"
        elif md is None or not md.ok:
            entry["reason"] = f"market data unavailable ({md.error if md else 'not loaded'})"
        elif sym in threatened_puts:
            entry["reason"] = "existing short put on this underlying is threatened; no added put exposure"
        else:
            allc = [c for c in md.cands if c.side == "PUT"]
            afford = [c for c in allc if c.capital <= ctx.cash]
            entry["excluded_cash"] = len(allc) - len(afford)
            entry["quality_fail"] = sum(1 for c in afford if not c.qualifies_hard)
            if allc and not afford:
                cheapest = min(c.capital for c in allc)
                entry["reason"] = (f"insufficient cash: cheapest in-window CSP needs {f_usd(cheapest, 0)}, "
                                   f"you supplied {f_usd(ctx.cash, 0)}")
            else:
                entry["eligible"] = True
                good = [c for c in afford if c.qualifies_hard]
                for c in good:
                    apply_adjustments(c, md, state, ctx, cfg, pending)
                entry["cands"] = sorted(good, key=lambda c: c.final_score, reverse=True)
                entry["reason"] = (f"{len(good)} affordable quality contract(s)"
                                   + (f"; {entry['excluded_cash']} excluded for cash" if entry["excluded_cash"] else ""))
        out[key] = entry
    return out


# =============================================================================
# FINAL DECISION
# =============================================================================

def action_name(c: Candidate) -> str:
    return "SELL CASH-SECURED PUT" if c.side == "PUT" else "SELL COVERED CALL"


def reason_text(c: Candidate, md: MarketData) -> str:
    parts = []
    pref, strong = regime_preference(md.regime.label)
    lab = md.regime.label.replace("_", " ").lower()
    if pref is None:
        parts.append(f"{lab} regime (no side preference)")
    elif pref == c.side:
        parts.append(f"{lab} regime favors this side")
    else:
        parts.append(f"{lab} regime favors the other side, overcome on economics")
    parts.append(f"delta {c.delta:.3f} (tier {c.delta_tier})")
    if c.em_ratio >= 0.90:
        parts.append(f"adequate expected-move coverage ({c.em_ratio:.2f}x EM)")
    else:
        parts.append(f"moderate expected-move coverage ({c.em_ratio:.2f}x EM)")
    liq = "strong" if c.open_interest >= 1000 and c.spread_pct <= 0.05 else "acceptable"
    parts.append(f"{liq} liquidity (OI {c.open_interest:,}, spread {f_pct(c.spread_pct, 1)})")
    if c.atm_iv_rv is not None:
        tone = "favorable" if c.atm_iv_rv >= 1.10 else "neutral" if c.atm_iv_rv >= 0.95 else "unfavorable"
        parts.append(f"{tone} IV/realized-vol ({c.atm_iv_rv:.2f})")
    if "concentration" in c.adjustments:
        parts.append("BUT concentration penalty applied")
    else:
        parts.append("acceptable portfolio exposure")
    return ", ".join(parts) + "."


def explain_win(a: Candidate, b: Candidate) -> list[str]:
    out = [f"#1 {a.short_label} ({a.final_score:.1f}) beats #2 {b.short_label} ({b.final_score:.1f}) "
           f"by {a.final_score - b.final_score:.1f} pts: raw {a.raw_score - b.raw_score:+.1f}, "
           f"portfolio adj {sum(a.adjustments.values()) - sum(b.adjustments.values()):+.1f}."]
    diffs = sorted(((k, a.factors[k]["points"] - b.factors[k]["points"]) for k in a.factors),
                   key=lambda kv: kv[1], reverse=True)
    better = [f"{FACTOR_LABEL[k]} {v:+.1f}" for k, v in diffs if v > 0.5][:3]
    worse = [f"{FACTOR_LABEL[k]} {v:+.1f}" for k, v in diffs[::-1] if v < -0.5][:2]
    if better:
        out.append("#1 stronger on: " + ", ".join(better) + ".")
    if worse:
        out.append("#2 stronger on: " + ", ".join(worse) + ".")
    return out


def make_decision(mgmt: list, elig: dict, markets: dict, cfg: Config) -> dict:
    logic: list[str] = []
    reps: list[Candidate] = []
    for key, e in elig.items():
        if e["eligible"] and e["cands"]:
            reps.append(e["cands"][0])
    reps.sort(key=lambda c: c.final_score, reverse=True)
    viable = [c for c in reps if c.viable]
    urgent = sorted([m for m in mgmt if m.action in ("ROLL", "CLOSE")], key=lambda m: -m.urgency)
    holds = [m for m in mgmt if m.action == "HOLD"]
    expires = [m for m in mgmt if m.action == "LET_EXPIRE"]
    any_eligible = any(e["eligible"] for e in elig.values())

    logic.append(f"Existing positions evaluated first: {len(mgmt)} "
                 f"({len(urgent)} need action, {len(holds)} hold, {len(expires)} let expire).")
    logic.append(f"Eligible side/underlying combinations: {sum(1 for e in elig.values() if e['eligible'])} "
                 f"of {len(elig)}; representatives ranked: {len(reps)}; viable (final >= threshold): {len(viable)}.")
    for c in reps:
        if not c.viable:
            logic.append(f"{c.short_label} final {c.final_score:.1f} < threshold {c.threshold:.1f} -> not viable.")

    dec: dict[str, Any] = {"headline": "", "lines": [], "reason": "", "followups": [], "logic": logic,
                           "ranked": reps, "primary_kind": None}
    for m in expires:
        dec["followups"].append(f"LET EXPIRE: {m.position.label} x{m.position.contracts}")

    if urgent:
        m = urgent[0]
        p = m.position
        if m.action == "ROLL" and m.roll:
            rc: Candidate = m.roll["candidate"]
            dec["headline"] = "ROLL EXISTING POSITION"
            dec["lines"] = [
                f"BUY TO CLOSE: {p.label} x{p.contracts} @ ~{m.roll['close_mid']:.2f}"
                + (f" (ask {m.roll['close_ask']:.2f})" if m.roll["close_ask"] else ""),
                f"SELL TO OPEN: {rc.short_label} x{p.contracts} @ ~{rc.mid:.2f} (bid {rc.bid:.2f})",
                f"Net ~ {f_signed_usd(m.roll['net_mid_total'])} at mids | conservative "
                f"{f_signed_usd(m.roll['net_cons_total'])} (bid/ask)",
            ]
        else:
            dec["headline"] = "CLOSE EXISTING POSITION"
            dec["lines"] = [f"BUY TO CLOSE: {p.label} x{p.contracts} @ ~{m.metrics.get('mid', 0):.2f}"
                            + (f" (ask {m.metrics['ask']:.2f})" if m.metrics.get("ask") else "")]
            if m.replacement:
                dec["lines"].append(f"Optional replacement: SELL {m.replacement.short_label} "
                                    f"@ ~{m.replacement.mid:.2f} (raw score {m.replacement.raw_score:.1f})")
        dec["reason"] = " ".join(m.reasons)
        dec["primary_kind"] = "management"
        for m2 in urgent[1:]:
            dec["followups"].append(f"ALSO {m2.action}: {m2.position.label} x{m2.position.contracts}")
        for c in viable[:3]:
            dec["followups"].append(f"THEN CONSIDER {action_name(c)}: {c.short_label} "
                                    f"x{c.suggested_contracts} (score {c.final_score:.1f})")
        logic.append("Management of an existing position takes priority over opening new risk.")
    elif viable:
        c = viable[0]
        md = markets[c.underlying]
        dec["headline"] = action_name(c)
        dec["lines"] = [
            f"{c.short_label}" + (f"  ({c.contract})" if c.contract else ""),
            f"Qty {c.suggested_contracts} (max eligible {c.max_contracts}) | limit near mid "
            f"{c.mid:.2f}, natural {c.bid:.2f}",
            f"Score {c.final_score:.1f}/100 (raw {c.raw_score:.1f}, portfolio adj "
            f"{sum(c.adjustments.values()):+.1f})",
        ]
        dec["reason"] = reason_text(c, md)
        dec["primary_kind"] = "new"
        if len(viable) > 1:
            logic += explain_win(c, viable[1])
        else:
            logic.append(f"{c.short_label} is the only viable trade.")
        for h in holds:
            dec["followups"].append(f"HOLD: {h.position.label} x{h.position.contracts}")
    else:
        if not any_eligible:
            dec["headline"] = "HOLD EXISTING POSITION(S)" if holds else "NO ELIGIBLE TRADE"
            dec["reason"] = ("No covered-call lots are free and no cash-secured put is eligible "
                             "(cash, assignment preference, or exposure).")
        elif reps:
            dec["headline"] = ("HOLD EXISTING POSITION(S) - NO NEW TRADE (WAIT)" if holds
                               else "NO TRADE (WAIT)")
            dec["reason"] = ("Eligible contracts exist, but none reaches the minimum final score; "
                             "the market/portfolio fit is not attractive enough right now.")
        else:
            dec["headline"] = ("HOLD EXISTING POSITION(S) - NO NEW TRADE" if holds else "NO TRADE")
            dec["reason"] = ("No contract in the delta/DTE window passed liquidity, spread and "
                             "expected-move quality gates.")
        dec["primary_kind"] = "none"
        for h in holds:
            dec["followups"].append(f"HOLD: {h.position.label} x{h.position.contracts}")
    return dec


# =============================================================================
# REPORTING (phone-friendly text)
# =============================================================================

def cand_rows(c: Candidate, idx: int) -> list[str]:
    flag = " VIABLE" if c.viable else ""
    return [
        f"  {idx}) {c.expiration.isoformat()} {c.strike:g}{'C' if c.side == 'CALL' else 'P'} "
        f"d{c.delta:.3f} T{c.delta_tier} {c.dte}DTE  F{c.final_score:.1f}{flag}",
        f"     {c.bid:.2f}/{c.ask:.2f} mid {c.mid:.2f} sp {f_pct(c.spread_pct, 1)} "
        f"OI {c.open_interest:,} v {c.volume:,}",
        f"     D/EM {c.em_ratio:.2f} ann {f_pct(c.annualized_roc, 1)} raw {c.raw_score:.1f} "
        f"adj {sum(c.adjustments.values()):+.1f}",
    ]


def cand_card(c: Candidate, debug: bool) -> list[str]:
    L = [f"  {action_name(c)}: {c.short_label}"]
    if c.contract:
        L.append(f"  Contract: {c.contract}")
    L += [
        f"  Spot {f_usd(c.spot)} | DTE {c.dte} | {'std monthly' if c.standard_monthly else 'WEEKLY'}",
        f"  Delta {c.delta:.3f} ({c.delta_source}, tier {c.delta_tier}) | IV {f_pct(c.iv, 1)} ({c.iv_source})",
        f"  ATM IV {f_pct(c.atm_iv, 1)} | Bid/Ask {c.bid:.2f}/{c.ask:.2f} | Mid {c.mid:.2f}",
        f"  Spread {f_usd(c.spread)} ({f_pct(c.spread_pct, 1)}) | OI {c.open_interest:,} | Vol {c.volume:,}",
        f"  Exp move 1sd +/-{f_usd(c.expected_move)} ({f_pct(c.expected_move_pct)}) [{c.em_source}]",
        f"  OTM {f_usd(c.distance)} ({f_pct(c.distance_pct)}) | Dist/EM {c.em_ratio:.2f}",
        f"  Premium {f_usd(c.premium_share)}/sh | {f_usd(c.credit_mid)}/contract mid "
        f"({f_usd(c.credit_bid)} at bid)",
        f"  Capital {f_usd(c.capital, 0)}/contract "
        + ("(strike x100, approx.)" if c.side == "PUT" else "(100 shares at spot)"),
        f"  ROC {f_pct(c.roc)} period | {f_pct(c.annualized_roc)} ann. (simple)",
        f"  Breakeven {f_usd(c.breakeven)} | "
        + (f"eff. buy {f_pct(c.assignment_metric)} below spot" if c.side == "PUT"
           else f"{f_pct(c.assignment_metric)} total if called"),
        f"  P(ITM) {f_pct(c.prob_itm, 1)} (risk-neutral model) | P(touch) ~{f_pct(c.prob_touch, 1)}",
        f"  IV/RV {f_num(c.iv_rv)} (contract) | ATM IV/RV {f_num(c.atm_iv_rv)}",
        f"  Vol-edge vs RV ~{f_usd(c.vol_edge_contract)}/contract (model; ignores skew/drift/jumps)",
        f"  RAW {c.raw_score:.1f} | PORTFOLIO ADJ {sum(c.adjustments.values()):+.1f} | "
        f"FINAL {c.final_score:.1f} (min {c.threshold:.1f})",
    ]
    if c.concentration_pre is not None:
        L.append(f"  Exposure (lev-wtd group): {f_pct(c.concentration_pre, 1)} -> "
                 f"{f_pct(c.concentration_post, 1)} of portfolio")
    L.append(f"  Size: suggest {c.suggested_contracts}, max {c.max_contracts} ({c.sizing_note})")
    L.append(wrap("Factors: " + ", ".join(f"{FACTOR_LABEL[k]} {v['points']:.1f}/{v['weight']:.0f}"
                                         for k, v in c.factors.items()), 2))
    L.append(wrap("Penalties: " + (", ".join(f"{k} {v:+.1f}" for k, v in c.penalties.items()) or "none"), 2))
    L.append(wrap("Portfolio adj: " + (", ".join(f"{k} {v:+.1f}" for k, v in c.adjustments.items()) or "none"), 2))
    if debug and c.disqualified:
        L.append(wrap("Disqualified: " + "; ".join(c.disqualified), 2))
    return L


def render_text(R: dict, debug: bool, top_n: int) -> str:
    L: list[str] = []
    sep, sub = "=" * W, "-" * W
    ctx: PortfolioContext = R["ctx"]
    state: dict = R["state"]
    cfg: Config = R["cfg"]
    markets: dict = R["markets"]
    dec: dict = R["decision"]

    def h(title: str) -> None:
        L.extend(["", sub, f" {title}", sub])

    L += [sep, f" {ENGINE_NAME}", f" v{VERSION} | {R['generated_at']} ET", sep]
    L.append(wrap("Model output only. Delayed data. Not financial advice. Portfolio context is "
                  "held in memory only and is never saved.", 1))

    h("1. CURRENT PORTFOLIO CONTEXT")
    L.append(f"  Context source: {ctx.source}")
    L.append(f"  Cash for new CSPs: {f_usd(ctx.cash)}")
    L.append(f"  CSP assignment acceptable: {'YES' if ctx.assignment_ok else 'NO'}")
    L.append(f"  Delta pref {ctx.delta_lo:.2f}-{ctx.delta_hi:.2f} | fallback "
             f"{R['bands'].fb_lo:.2f}-{R['bands'].fb_hi:.2f} | final {R['bands'].fin_lo:.2f}-{R['bands'].fin_hi:.2f}")
    L.append(f"  Weeklies allowed: {'YES' if cfg.allow_weeklies else 'NO (monthly only)'}")
    if state["holdings"]:
        L.append("  Holdings:")
        for sym, hd in state["holdings"].items():
            L.append(f"   {sym}: {hd['shares']:,} sh @ {f_usd(hd['price'])} = {f_usd(hd['value'], 0)}")
            L.append(f"     committed {hd['committed_shares']:,} | free {hd['free_shares']:,} "
                     f"| free lots {hd['free_lots']}")
    else:
        L.append("  Holdings: NONE")
    if ctx.shorts:
        L.append("  Existing short options:")
        for p in ctx.shorts:
            L.append(f"   {p.label} x{p.contracts} entry "
                     f"{f_num(p.entry) if p.entry else 'unknown'}")
    else:
        L.append("  Existing short options: NONE")
    if ctx.watchlist:
        L.append(f"  CSP watchlist: {', '.join(ctx.watchlist)}")
    L.append(f"  Approx. portfolio value: {f_usd(state['total_value'], 0)}")
    L.append("   (cash + priced holdings + short-put collateral)")
    if state["group_exposure"] and state["total_value"] > 0:
        L.append("  Leverage-weighted exposure (assignment basis):")
        for g, v in sorted(state["group_exposure"].items(), key=lambda kv: -abs(kv[1])):
            lim = cfg.conc_limit_broad if g in BROAD_GROUPS else cfg.conc_limit_other
            L.append(f"   {g}: {f_usd(v, 0)} = {f_pct(abs(v) / state['total_value'], 1)} "
                     f"(guideline {lim:.0%})")

    h("2. MARKET DATA & REGIME")
    if not markets:
        L.append("  No symbols to analyze.")
    for sym, md in markets.items():
        if not md.ok:
            L.append(f"  {sym}: DATA UNAVAILABLE - {md.error}")
            continue
        reg = md.regime
        L.append(f"  {sym}: {f_usd(md.spot)} ({md.spot_source})")
        L.append(f"   Regime {reg.label} score {reg.score:+.1f} "
                 f"[{REGIME_MIN:+.0f}..{REGIME_MAX:+.1f}]")
        L.append(f"   Vol state {reg.vol_state} (RV20 pctile {f_pct(reg.rv_pctile, 0)}) "
                 f"RV20 {f_pct(md.rv20, 1)} RV60 {f_pct(md.rv60, 1)}")
        ind = reg.indicators
        if ind:
            L.append(f"   SMA20 {f_num(ind.get('sma20'))} SMA50 {f_num(ind.get('sma50'))} "
                     f"SMA200 {f_num(ind.get('sma200'))}")
            L.append(f"   RSI {f_num(ind.get('rsi14'), 1)} 20d {f_pct(ind.get('ret20'), 1)} "
                     f"60d {f_pct(ind.get('ret60'), 1)} ATR% {f_pct(ind.get('atr14_pct'), 2)}")
        L.append(wrap(f"Expirations: {md.window_note}", 3))
        for e in md.selected_exps:
            info = md.exp_info.get(e, {})
            L.append(f"   {e.isoformat()} {info.get('dte')}DTE ATM IV {f_pct(info.get('atm_iv'), 1)} "
                     f"IV/RV {f_num(info.get('atm_iv_rv'))}")
            L.append(f"     1sd move +/-{f_usd(info.get('expected_move'))} "
                     f"({f_pct(info.get('expected_move_pct'))}) [{info.get('em_source')}]")
        if debug:
            for c in reg.components:
                v = "n/a" if c["value"] is None else (f"{c['value']:.1f}" if c["kind"] == "num"
                                                      else f"{c['value'] * 100:+.2f}%")
                L.append(f"     {c['name']:<16} {v:>8} {c['points']:+.1f}")
            L.append(f"     history: {md.history_source} ({md.history_bars} bars, last {md.history_last})")

    h("3. EXISTING POSITION MANAGEMENT")
    if not R["mgmt"]:
        L.append("  No existing short options reported.")
    for i, m in enumerate(R["mgmt"], 1):
        p, mt = m.position, m.metrics
        L.append(f"  [{i}] SHORT {p.label} x{p.contracts} (entry "
                 f"{f_num(p.entry) if p.entry else 'unknown'})")
        if mt:
            L.append(f"    Spot {f_usd(mt['spot'])} | DTE {mt['dte']} | {m.quote_source}")
            if m.contract:
                L.append(f"    Contract {m.contract}")
            L.append(f"    Bid/Ask {f_num(mt['bid'])}/{f_num(mt['ask'])} mid {f_num(mt['mid'])} "
                     f"IV {f_pct(mt['iv'], 1)}")
            L.append(f"    Delta {mt['delta']:.3f} ({mt['delta_source']}) | "
                     f"{'ITM' if mt['itm'] else 'OTM'} | extrinsic {f_num(mt['extrinsic'])}")
            L.append(f"    OTM dist {f_usd(mt['otm_distance'])} ({f_pct(mt['otm_pct'])}) | "
                     f"EM +/-{f_usd(mt['expected_move'])} | D/EM {f_num(mt['em_ratio'])}")
            L.append(f"    P(ITM) {f_pct(mt['prob_itm'], 1)} | P(touch) ~{f_pct(mt['prob_touch'], 1)}")
            if mt["captured_pct"] is not None:
                L.append(f"    Captured {f_pct(mt['captured_pct'], 1)} | P/L at mid "
                         f"{f_signed_usd(mt['pnl_at_mid_total'])} total")
            L.append(f"    Remaining yield ~{f_pct(mt['remaining_ann_yield'], 1)} ann.")
        L.append(f"    ACTION: {m.action.replace('_', ' ')}"
                 + (" EXISTING POSITION" if m.action in ("HOLD", "CLOSE", "ROLL") else ""))
        for rsn in m.reasons:
            L.append(wrap("- " + rsn, 4))
        if m.roll:
            rc: Candidate = m.roll["candidate"]
            L.append("    BUY TO CLOSE:")
            L.append(f"     {p.label} @ ~{m.roll['close_mid']:.2f}"
                     + (f" (ask {m.roll['close_ask']:.2f})" if m.roll["close_ask"] else ""))
            L.append("    SELL TO OPEN:")
            L.append(f"     {rc.short_label} @ ~{rc.mid:.2f} (bid {rc.bid:.2f})")
            L.append(f"     delta {rc.delta:.3f} | {rc.dte}DTE | D/EM {rc.em_ratio:.2f} | raw {rc.raw_score:.1f}")
            L.append(f"    Net ~{f_signed_usd(m.roll['net_mid_share'])}/sh at mids = "
                     f"{f_signed_usd(m.roll['net_mid_total'])} total")
            L.append(f"    Conservative (bid/ask): {f_signed_usd(m.roll['net_cons_total'])} total")
        if m.replacement and m.action == "CLOSE":
            rp = m.replacement
            L.append(f"    Replacement candidate: SELL {rp.short_label} @ ~{rp.mid:.2f} "
                     f"d{rp.delta:.3f} raw {rp.raw_score:.1f}")

    for title, side in (("4. ELIGIBLE COVERED CALLS", "CALL"), ("5. ELIGIBLE CASH-SECURED PUTS", "PUT")):
        h(title)
        entries = [e for e in R["elig"].values() if e["side"] == side]
        if not entries:
            L.append("  None: " + ("no holdings reported." if side == "CALL" else
                                   "no CSP symbols (holdings/watchlist) supplied."))
        for e in entries:
            status = "ELIGIBLE" if e["eligible"] else "NOT ELIGIBLE"
            L.append(f"  {e['symbol']}: {status}")
            L.append(wrap(e["reason"], 4))
            if e["eligible"] and not e["cands"]:
                L.append("    No contract passed quality gates"
                         + (f" ({e['quality_fail']} failed)." if e["quality_fail"] else "."))
            for i, c in enumerate(e["cands"][:top_n], 1):
                L += cand_rows(c, i)

    h("6. TOP CANDIDATES (best per underlying/side)")
    reps = dec["ranked"]
    if not reps:
        L.append("  None.")
    for c in reps:
        L += cand_card(c, debug)
        L.append("")

    h("7. PORTFOLIO-ADJUSTED RANKING")
    if not reps:
        L.append("  No eligible quality candidates to rank.")
    for i, c in enumerate(reps, 1):
        tag = "SELL CSP" if c.side == "PUT" else "SELL CALL"
        L.append(f"  {i}. {tag}: {c.short_label}")
        L.append(f"     RAW {c.raw_score:.1f} | ADJ {sum(c.adjustments.values()):+.1f} | "
                 f"FINAL {c.final_score:.1f} {'VIABLE' if c.viable else '(below ' + format(c.threshold, '.1f') + ')'}")

    h("8. DECISION LOGIC")
    for line in dec["logic"]:
        L.append(wrap("- " + line, 2))

    if debug:
        h("DEBUG DIAGNOSTICS")
        for sym, md in markets.items():
            d = md.diag
            L.append(f"  {sym}: contracts {d.total_contracts}, parsed {d.parsed_contracts}, "
                     f"candidates {len(md.cands)}")
            for k, v in sorted(d.rejections.items(), key=lambda kv: -kv[1]):
                L.append(f"    rejected[{k}] = {v}")
            for err in md.history_errors:
                L.append(wrap(f"history error: {err}", 4))

    if R["warnings"]:
        h("WARNINGS")
        for w in R["warnings"]:
            L.append(wrap("! " + w, 2))

    h("DISCLAIMER")
    L.append(wrap(DISCLAIMER, 2))

    L += ["", sep, " FINAL MODEL PREFERENCE", sep]
    L.append(f"MODEL PREFERENCE: {dec['headline']}")
    for line in dec["lines"]:
        L.append(line)
    if dec["followups"]:
        for f_ in dec["followups"]:
            L.append(f"  + {f_}")
    L.append(textwrap.fill("Reason: " + dec["reason"], width=W, subsequent_indent="  "))
    L.append("(Model output - not a guaranteed optimal or profitable trade.)")
    L.append(sep)
    return "\n".join(L)


# =============================================================================
# JSON
# =============================================================================

def cj(c: Optional[Candidate]) -> Optional[dict]:
    return None if c is None else asdict(c)


def build_json(R: dict, top_n: int) -> dict:
    ctx: PortfolioContext = R["ctx"]
    dec = R["decision"]
    markets = {}
    for sym, md in R["markets"].items():
        markets[sym] = {
            "ok": md.ok, "error": md.error, "spot": md.spot, "spot_source": md.spot_source,
            "chain_timestamp": md.chain_timestamp, "history_source": md.history_source,
            "history_bars": md.history_bars, "rv20": md.rv20, "rv60": md.rv60, "rv_blend": md.rv_blend,
            "regime": asdict(md.regime), "window_note": md.window_note,
            "expirations": [{"expiration": e.isoformat(), **md.exp_info.get(e, {})} for e in md.selected_exps],
            "diagnostics": {"rejections": md.diag.rejections, "total": md.diag.total_contracts,
                            "parsed": md.diag.parsed_contracts},
        }
    mg = []
    for m in R["mgmt"]:
        mg.append({"position": asdict(m.position), "action": m.action, "urgency": m.urgency,
                   "reasons": m.reasons, "metrics": m.metrics, "quote_source": m.quote_source,
                   "contract": m.contract, "replacement": cj(m.replacement),
                   "roll": None if not m.roll else {**{k: v for k, v in m.roll.items() if k != "candidate"},
                                                    "candidate": cj(m.roll["candidate"])}})
    elig = {k: {"symbol": e["symbol"], "side": e["side"], "eligible": e["eligible"], "reason": e["reason"],
                "excluded_for_cash": e["excluded_cash"], "quality_fail": e["quality_fail"],
                "top": [cj(c) for c in e["cands"][:top_n]]} for k, e in R["elig"].items()}
    return {
        "engine": ENGINE_NAME, "version": VERSION, "generated_at_et": R["generated_at"],
        "portfolio_context": {"source": ctx.source, "cash_for_csp": ctx.cash, "holdings": ctx.holdings,
                              "short_options": [asdict(p) for p in ctx.shorts], "watchlist": ctx.watchlist,
                              "delta_range": [ctx.delta_lo, ctx.delta_hi], "assignment_ok": ctx.assignment_ok,
                              "persisted": False},
        "portfolio_state": {k: v for k, v in R["state"].items() if k != "warnings"},
        "assumptions": {"config": asdict(R["cfg"]), "weights": WEIGHTS, "yield_scale": YIELD_SCALE,
                        "delta_bands": asdict(R["bands"])},
        "markets": markets,
        "existing_position_management": mg,
        "eligibility": elig,
        "ranking": [{"rank": i + 1, "action": action_name(c), "contract": c.contract, "label": c.short_label,
                     "raw_score": c.raw_score, "portfolio_adjustment": round(sum(c.adjustments.values()), 2),
                     "final_score": c.final_score, "threshold": c.threshold, "viable": c.viable,
                     "suggested_contracts": c.suggested_contracts} for i, c in enumerate(dec["ranked"])],
        "decision": {"model_preference": dec["headline"], "details": dec["lines"], "reason": dec["reason"],
                     "followups": dec["followups"], "logic": dec["logic"], "primary_kind": dec["primary_kind"]},
        "warnings": R["warnings"],
        "disclaimer": DISCLAIMER,
    }


# =============================================================================
# MAIN
# =============================================================================

def parse_args(argv: Optional[list] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Portfolio-aware covered call / CSP / roll decision engine (V2).")
    p.add_argument("--debug", action="store_true", help="Verbose diagnostics and factor detail.")
    p.add_argument("--json", action="store_true", help="JSON to stdout (prompts go to stderr).")
    p.add_argument("--price", action="append", default=None,
                   help="Price override: 756.40 (single symbol) or SYM=PRICE (repeatable).")
    p.add_argument("--top", type=int, default=3, help="Candidates listed per underlying/side (default 3).")
    p.add_argument("--allow-weeklies", action="store_true", help="Also consider non-monthly expirations.")
    p.add_argument("--min-score", type=float, default=None, help="Minimum final score (default 55).")
    p.add_argument("--rate", type=float, default=None, help="Risk-free rate, decimal (default 0.043).")
    p.add_argument("--div-yield", type=float, default=None, help="Dividend yield, decimal (default 0).")
    p.add_argument("--timeout", type=float, default=None, help="HTTP timeout seconds (default 15).")
    g = p.add_argument_group("non-interactive portfolio context (any flag skips the questionnaire)")
    g.add_argument("--cash", default=None, help="Cash for new CSPs, e.g. 60000 or 60k.")
    g.add_argument("--holdings", default=None, help='e.g. "QQQ 700, AAPL 150".')
    g.add_argument("--short", action="append", default=None,
                   help='Existing short, e.g. "QQQ C 720 2026-07-17 2 3.15" (repeatable).')
    g.add_argument("--watch", default=None, help='CSP watchlist, e.g. "SPY,NVDA".')
    g.add_argument("--delta", default=None, help="Delta range, e.g. 0.15-0.20.")
    g.add_argument("--assignment", default=None, help="CSP assignment acceptable: yes/no.")
    g.add_argument("--no-input", action="store_true", help="Never prompt; use flags/defaults only.")
    return p.parse_args(argv)


def parse_price_overrides(vals: Optional[list], symbols: list) -> dict:
    out: dict[str, float] = {}
    bare: Optional[float] = None
    for v in vals or []:
        if "=" in v:
            s, px = v.split("=", 1)
            out[parse_ticker(s)] = float(px)
        else:
            bare = float(v)
    if bare is not None:
        if len(symbols) == 1:
            out[symbols[0]] = bare
        else:
            raise ValueError("bare --price requires exactly one symbol; use --price SYM=PRICE")
    for s, px in out.items():
        if px <= 0:
            raise ValueError(f"--price for {s} must be positive")
    return out


def run(args: argparse.Namespace) -> int:
    logging.basicConfig(level=logging.DEBUG if args.debug else logging.WARNING,
                        format="%(levelname)s %(name)s: %(message)s", stream=sys.stderr)
    use_flags = args.no_input or any(x is not None for x in (args.cash, args.holdings, args.short,
                                                              args.watch, args.delta, args.assignment))
    try:
        ctx = collect_from_args(args) if use_flags else collect_interactive()
    except InputError as exc:
        msg = f"Invalid portfolio input: {exc}"
        if args.json:
            print(json.dumps({"error": msg, "model_preference": "NO TRADE", "disclaimer": DISCLAIMER}, indent=2))
        else:
            sys.stderr.write(f"ERROR: {msg}\nMODEL PREFERENCE: NO TRADE (input invalid)\n")
        return 2

    overrides: dict[str, Any] = {"delta_lo": ctx.delta_lo, "delta_hi": ctx.delta_hi,
                                 "allow_weeklies": bool(args.allow_weeklies)}
    if args.min_score is not None:
        overrides["min_score"] = args.min_score
    if args.rate is not None:
        overrides["risk_free"] = args.rate
    if args.div_yield is not None:
        overrides["div_yield"] = args.div_yield
    if args.timeout is not None:
        overrides["timeout"] = args.timeout
    cfg = replace(Config(), **overrides)
    bands = DeltaBands.build(cfg.delta_lo, cfg.delta_hi, cfg)

    warnings: list[str] = []
    symbols: list[str] = []
    csp_active = ctx.assignment_ok and ctx.cash > 0
    for s in [p.symbol for p in ctx.shorts] + list(ctx.holdings) + (ctx.watchlist if csp_active else []):
        if s not in symbols:
            symbols.append(s)
    if ctx.watchlist and not csp_active:
        warnings.append("Watchlist ignored: CSPs need cash > 0 and assignment acceptable.")
    if len(symbols) > cfg.max_symbols:
        warnings.append(f"Symbol list truncated to {cfg.max_symbols}: dropped {', '.join(symbols[cfg.max_symbols:])}.")
        symbols = symbols[:cfg.max_symbols]
    try:
        price_ovr = parse_price_overrides(args.price, symbols)
    except ValueError as exc:
        sys.stderr.write(f"ERROR: {exc}\n")
        return 2

    now_u = utc_now()
    today = to_et(now_u).date()
    http = Http(cfg.timeout, cfg.retries)
    markets: dict[str, MarketData] = {}
    for i, sym in enumerate(symbols):
        if not args.json:
            sys.stderr.write(f"Fetching {sym} ({i + 1}/{len(symbols)})...\n")
        try:
            md = load_market(http, sym, cfg, price_ovr.get(sym), now_u, today)
        except Exception as exc:  # never crash on one bad symbol
            LOG.debug("load_market crashed for %s", sym, exc_info=True)
            md = MarketData(symbol=sym, error=f"unexpected error: {exc}")
        if md.ok:
            try:
                build_candidates(md, cfg, bands, now_u, today)
            except Exception as exc:
                LOG.debug("candidate build failed for %s", sym, exc_info=True)
                md.warnings.append(f"{sym}: candidate build failed ({exc}).")
        else:
            warnings.append(f"{sym}: {md.error}")
        warnings.extend(md.warnings)
        markets[sym] = md
        if i < len(symbols) - 1:
            time.sleep(0.25)  # politeness toward free endpoints

    state = portfolio_state(ctx, markets)
    warnings.extend(state["warnings"])
    mgmt = [evaluate_short(p, markets.get(p.symbol), ctx, state, cfg, bands, now_u, today) for p in ctx.shorts]
    mgmt.sort(key=lambda m: -m.urgency)
    elig = build_eligibility(ctx, state, markets, mgmt, cfg)
    decision = make_decision(mgmt, elig, markets, cfg)

    R = {"generated_at": to_et(now_u).strftime("%Y-%m-%d %H:%M:%S"), "ctx": ctx, "cfg": cfg, "bands": bands,
         "state": state, "markets": markets, "mgmt": mgmt, "elig": elig, "decision": decision,
         "warnings": warnings}
    top_n = max(1, args.top)
    if args.json:
        print(json.dumps(build_json(R, top_n), indent=2, default=str))
    else:
        print(render_text(R, args.debug, top_n))
    return 0


def main() -> None:
    try:
        sys.exit(run(parse_args()))
    except KeyboardInterrupt:
        sys.stderr.write("\nInterrupted. Nothing was saved.\n")
        sys.exit(130)


if __name__ == "__main__":
    main()