"""Engine orchestrator: DATA -> NORMALIZATION -> MARKET ANALYSIS -> OPTIONS ANALYSIS -> REGIME -> STRATEGY ->
RISK -> SCORING -> ORDER TIMING -> PRESENTATION payloads.

Stateless with respect to the user: each request carries its own portfolio/settings. Recent analyses are kept in a
small in-memory LRU only so the UI can ask for trade details / comparisons without recomputing.
"""
from __future__ import annotations

import datetime as dt
import logging
import math
import threading
import time
import uuid
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Optional

from option_battle import ENGINE_NAME, VERSION
from option_battle.analytics.comparison import compare as compare_evals
from option_battle.analytics.context import Context, build_context
from option_battle.analytics.entry import decide, invalidation, limit_zone, timing_assessment, wait_condition
from option_battle.analytics.greeks import early_exercise_premium
from option_battle.analytics.management import manage_positions
from option_battle.analytics.narrative import action_label, short_label, what_breaks, why_ranked
from option_battle.analytics.portfolio_fit import portfolio_state, trade_fit, trade_requirements
from option_battle.analytics.risk import risk_report
from option_battle.analytics.scoring import LABELS, score_trade, strategy_regime_fit
from option_battle.analytics.sizing import sizing_table
from option_battle.analytics.technicals import sma
from option_battle.analytics.trade_metrics import compute_metrics
from option_battle.config import Config, load_config
from option_battle.core.util import sanitize
from option_battle.data.normalize import normalize_snapshot
from option_battle.data.providers import ProviderError, get_provider
from option_battle.legacy.options_suggester import to_et, utc_now
from option_battle.models.portfolio import PortfolioContext, PortfolioParseError, parse_portfolio_text
from option_battle.models.trade import STRATEGY_NAMES
from option_battle.strategies import ALL_STRATEGIES, BY_KEY, META

LOG = logging.getLogger("option_battle.engine")

ARENAS = [
    {"key": "put", "title": "Put battle", "strategies": ["cash_secured_put", "long_put", "protective_put"]},
    {"key": "call", "title": "Call battle", "strategies": ["covered_call", "long_call", "collar"]},
    {"key": "spread", "title": "Spread battle",
     "strategies": ["put_credit_spread", "call_credit_spread", "bull_call_spread", "bear_put_spread"]},
]
DATA_KINDS = {
    "observed": "taken directly from the data provider (quotes, sizes, OI, volume, history bars)",
    "calculated": "computed deterministically from observed data (mid, Greeks from IV, payoff, statistics)",
    "estimated": "model output under stated assumptions (probabilities, scenario marks, delta-gamma targets)",
    "inferred": "rule-based interpretation (regime label, support/resistance, assignment risk level)",
    "conceptual": "visual summary of calculated components (battle stats)",
    "unavailable": "not provided by any configured source; never filled with a guess",
}


class AnalysisError(Exception):
    def __init__(self, msg: str, hint: str = "", status: int = 400):
        super().__init__(msg)
        self.hint = hint
        self.status = status


@dataclass
class Evaluated:
    trade: object
    metrics: object
    score: object
    decision: dict
    timing: dict
    action: str
    short_label: str
    requirements: dict = field(default_factory=dict)
    hypothetical: bool = False
    fit: Optional[dict] = None
    sizing: Optional[dict] = None
    zone: Optional[dict] = None
    peers: dict = field(default_factory=dict)


@dataclass
class Analysis:
    id: str
    ctx: Context
    evals: list
    by_id: dict
    weights: dict
    pf_state: Optional[dict]
    created: float
    result: dict = field(default_factory=dict)


def _f(x, d=4):
    if x is None:
        return None
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return round(v, d) if math.isfinite(v) else None


class Engine:
    def __init__(self, default_provider: str = "mock", base_overrides: Optional[dict] = None,
                 max_store: int = 8) -> None:
        self.default_provider = default_provider
        self.base_overrides = base_overrides or {}
        self._providers: dict = {}
        self._store: "OrderedDict[str, Analysis]" = OrderedDict()
        self._lock = threading.Lock()
        self.max_store = max_store

    # ------------------------------------------------------------------ plumbing
    def config(self, overrides: Optional[dict] = None) -> Config:
        merged: dict = {}
        for src in (self.base_overrides, overrides or {}):
            for k, v in src.items():
                if isinstance(v, dict) and isinstance(merged.get(k), dict):
                    merged[k] = {**merged[k], **v}
                else:
                    merged[k] = v
        return load_config(merged)

    def provider(self, name: str, cfg: Config, scenario: str = "bull_pullback", seed: int = 7):
        key = (name, scenario if name == "mock" else "", seed if name == "mock" else 0)
        with self._lock:
            p = self._providers.get(key)
            if p is None:
                p = get_provider(name, cfg, scenario=scenario, seed=seed)
                self._providers[key] = p
            p.cfg = cfg
        return p

    def _remember(self, a: Analysis) -> None:
        with self._lock:
            self._store[a.id] = a
            while len(self._store) > self.max_store:
                self._store.popitem(last=False)

    def get(self, aid: str) -> Analysis:
        with self._lock:
            a = self._store.get(aid)
        if a is None:
            raise AnalysisError("analysis expired or unknown: run the analysis again", status=404)
        return a

    # ------------------------------------------------------------------ analysis
    def analyze(self, req: dict) -> dict:
        t0 = time.time()
        timings: dict = {}

        def mark(stage: str, since: float) -> float:
            now = time.time()
            timings[stage] = round((now - since) * 1000.0, 1)
            return now

        symbol = str(req.get("symbol") or "SPY").upper().strip().lstrip("$")
        if not symbol or len(symbol) > 10 or not symbol.replace(".", "").isalnum():
            raise AnalysisError(f"invalid symbol '{symbol}'")
        pname = str(req.get("provider") or self.default_provider).lower()
        cfg = self.config(req.get("config"))
        if req.get("weights"):
            from option_battle.config import _merge
            _merge(cfg.weights, req["weights"])
        weights = cfg.weights.normalized()
        scenario = str(req.get("scenario") or "bull_pullback")
        try:
            prov = self.provider(pname, cfg, scenario, int(req.get("seed") or 7))
        except ValueError as exc:
            raise AnalysisError(str(exc)) from None
        price_override = req.get("price_override")
        try:
            price_override = float(price_override) if price_override not in (None, "") else None
        except (TypeError, ValueError):
            raise AnalysisError("price override must be a number") from None
        t = time.time()
        try:
            snap = prov.fetch_snapshot(symbol, price_override)
        except ProviderError as exc:
            hint = ("Live CBOE data could not be fetched. Check the network connection, or switch the provider to "
                    "MOCK to run the whole application on synthetic data.") if pname == "cboe" else ""
            raise AnalysisError(str(exc), hint, 502) from None
        t = mark("fetch", t)
        try:
            pf = self._portfolio(req)
        except PortfolioParseError as exc:
            raise AnalysisError(f"portfolio: {exc}") from None
        exps = []
        for e in req.get("expirations") or []:
            try:
                exps.append(dt.date.fromisoformat(str(e)[:10]))
            except ValueError:
                pass
        try:
            ctx = build_context(snap, cfg, pf, req.get("events"), exps or None, req.get("dte_target"))
        except ValueError as exc:
            raise AnalysisError(f"cannot analyse {symbol}: {exc}", status=422) from None
        t = mark("context", t)
        snaps = {symbol: snap}
        markets = {symbol: {"spot": ctx.spot, "chain": ctx.chain, "error": None, "source": snap.spot_source}}
        if pf is not None and not pf.empty:
            for s in pf.symbols()[:cfg_max_symbols()]:
                if s in markets:
                    continue
                try:
                    sn = prov.fetch_snapshot(s)
                    snaps[s] = sn
                    markets[s] = {"spot": sn.spot, "chain": normalize_snapshot(sn, cfg, ctx.now_u, ctx.today), "error": None,
                                  "source": sn.spot_source}
                except Exception as exc:
                    markets[s] = {"spot": None, "chain": None, "error": str(exc)}
        st = portfolio_state(pf, markets, cfg, ctx.today, ctx.now_u)
        ctx.pf_state = st
        mgmt = None
        if pf is not None and any(p.qty < 0 for p in pf.options):
            mgmt = manage_positions(pf, snaps, ctx.now_u, ctx.today,
                                    assignment_ok=bool(req.get("assignment_ok", False)))
        t = mark("portfolio", t)

        wanted = [k for k in (req.get("strategies") or []) if k in BY_KEY] or [s.key for s in ALL_STRATEGIES]
        trades = []
        build_errors = []
        for s in ALL_STRATEGIES:
            if s.key not in wanted:
                continue
            try:
                trades.extend(s.build(ctx.chain, ctx.selected_exps, cfg))
            except Exception as exc:  # one strategy failing must not sink the board
                LOG.exception("strategy %s failed", s.key)
                build_errors.append(f"{s.key}: {exc}")
        t = mark("strategies", t)
        evals: list = []
        for tr in trades:
            try:
                m = compute_metrics(tr, ctx)
                tm = timing_assessment(tr, m, ctx)
                sc = score_trade(tr, m, ctx, weights, tm)
            except Exception as exc:
                LOG.exception("evaluation failed for %s", tr.id)
                build_errors.append(f"{tr.id}: {exc}")
                continue
            evals.append(Evaluated(tr, m, sc, {}, tm, action_label(tr), short_label(tr)))
        t = mark("scoring", t)
        self._peers(evals)
        for e in evals:
            e.decision = decide(e.trade, e.metrics, e.score, ctx, e.peers)
            e.requirements = trade_requirements(e.trade, st)
            e.hypothetical = e.requirements.get("ok") is False or (st is None and (META[e.trade.strategy].owns_shares))
            if st is not None:
                e.sizing = sizing_table(e.trade, e.metrics, ctx, st)
                e.fit = trade_fit(e.trade, e.metrics, ctx, st, e.sizing)
        t = mark("decisions", t)
        by_id = {e.trade.id: e for e in evals}
        a = Analysis(uuid.uuid4().hex[:12], ctx, evals, by_id, weights, st, time.time())
        ranked = self._ranked(evals, cfg, st)
        head = self._headline(ranked, evals, ctx, st)
        arenas = self._arenas(evals, ctx)
        for e in ([head] if head else []) + [x for ar in arenas for x in ar["_top"]]:
            if e.zone is None:
                e.zone = limit_zone(e.trade, e.score.total, ctx, weights, e.timing)
        t = mark("entry_zones", t)
        result = {
            "analysis_id": a.id,
            "meta": {"engine": ENGINE_NAME, "version": VERSION, "provider": snap.provider, "is_mock": snap.is_mock,
                     "provider_info": prov.describe(), "generated_at_et": to_et(ctx.now_u).strftime("%Y-%m-%d %H:%M:%S"),
                     "data_kinds": DATA_KINDS, "timings_ms": timings,
                     "disclaimer": ("Decision support only. Delayed or synthetic data and simplifying models (Black-Scholes, "
                                    "lognormal probabilities). Scores rank candidates under the current model; they are not "
                                    "forecasts or guarantees. Not financial advice. Nothing here places orders.")},
            "underlying": self._underlying(ctx, snap),
            "regime": self._regime_payload(ctx),
            "volatility": {"iv_regime": ctx.ivr, "term": ctx.term,
                           "expirations": [i.to_dict() for i in sorted(ctx.exp.values(), key=lambda i: i.dte)
                                           if i.dte <= 200],
                           "selected": [e.isoformat() for e in ctx.selected_exps], "focus": ctx.focus_exp,
                           "selection_note": ctx.selection_note},
            "technicals": {"snapshot": ctx.tech.to_dict(), "levels": {
                "supports": [lv.__dict__ for lv in ctx.levels.supports],
                "resistances": [lv.__dict__ for lv in ctx.levels.resistances],
                "available": ctx.levels.available, "note": ctx.levels.note}},
            "chart": self._chart(ctx, arenas, head),
            "history": ctx.hist,
            "events": {"items": [e.to_dict() for e in ctx.events], "coverage": ctx.event_coverage},
            "strategies": self._strategy_battle(evals, ctx),
            "arenas": [{k: v for k, v in ar.items() if not k.startswith("_")} for ar in arenas],
            "headline": self._headline_payload(head, ctx, evals) if head else None,
            "ranking": [self.summary(e) for e in ranked[:cfg.max_ranked_rows]],
            "portfolio": {"state": st, "management": mgmt, "entered": st is not None,
                          "parsed": pf.to_dict() if pf else None},
            "diagnostics": {"chain": ctx.chain.diag, "warnings": ctx.warnings + build_errors, "n_trades": len(trades),
                            "n_evaluated": len(evals), "n_disqualified": sum(1 for e in evals if e.score.disqualified),
                            "freshness": ctx.freshness, "history_source": snap.history_source, "bars": len(snap.bars)},
            "config": {"weights": weights, "labels": LABELS, "enter_threshold": cfg.enter_threshold,
                       "avoid_threshold": cfg.avoid_threshold, "delta_bands": cfg.delta_bands,
                       "dte_window": [cfg.dte_min, cfg.dte_max], "limits": cfg.limits.__dict__,
                       "risk_free": cfg.risk_free, "div_yield": cfg.div_for(symbol)},
        }
        mark("total", t0)
        result["meta"]["timings_ms"] = timings
        a.result = result
        self._remember(a)
        return sanitize(result)

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _portfolio(req: dict) -> Optional[PortfolioContext]:
        if req.get("portfolio"):
            return PortfolioContext.from_dict(req["portfolio"])
        txt = req.get("portfolio_text")
        if txt and str(txt).strip():
            return parse_portfolio_text(str(txt))
        return None

    @staticmethod
    def _peers(evals: list) -> None:
        best_exp: dict = {}
        best_all: dict = {}
        for e in evals:
            if e.score.disqualified:
                continue
            k = (e.trade.strategy, e.trade.expiration)
            if k not in best_exp or e.score.total > best_exp[k].score.total:
                best_exp[k] = e
        for (strat, exp), e in best_exp.items():
            best_all.setdefault(strat, []).append(e)
        for e in evals:
            se = best_exp.get((e.trade.strategy, e.trade.expiration))
            others = [x for x in best_all.get(e.trade.strategy, []) if x.trade.expiration != e.trade.expiration]
            oe = max(others, key=lambda x: x.score.total) if others else None
            e.peers = {"same_exp_best": (se.score.total, f"{se.short_label} {se.trade.expiration:%b %d}", se.trade.id) if se else None,
                       "other_exp_best": (oe.score.total, f"{oe.short_label} {oe.trade.expiration:%b %d}", oe.trade.id) if oe else None}

    @staticmethod
    def _ranked(evals: list, cfg: Config, st: Optional[dict]) -> list:
        pool = [e for e in evals if not e.score.disqualified]
        if not cfg.include_hypothetical:
            pool = [e for e in pool if not e.hypothetical]
        order = {"ENTER": 0, "WAIT": 1, "AVOID": 2}
        return sorted(pool, key=lambda e: (-e.score.total, order[e.decision["status"]]))

    @staticmethod
    def _headline(ranked: list, evals: list, ctx, st) -> Optional[Evaluated]:
        if not ranked:
            return None
        pool = [e for e in ranked if e.decision.get("status") != "AVOID"] or ranked
        if st is not None:
            feas = [e for e in pool if not e.hypothetical]
            if feas:
                return feas[0]
        return pool[0]

    def summary(self, e: Evaluated) -> dict:
        t, m, s = e.trade, e.metrics, e.score
        return {
            "id": t.id, "strategy": t.strategy, "name": t.title, "family": META[t.strategy].family,
            "action": e.action, "label": e.short_label, "expiration": t.expiration.isoformat(), "dte": t.dte,
            "legs": [{"action": l.action, "right": l.contract.right, "strike": l.contract.strike, "bid": l.contract.bid,
                      "ask": l.contract.ask, "mid": l.contract.mid, "iv": _f(l.contract.iv), "delta": _f(l.contract.delta, 3),
                      "oi": l.contract.open_interest, "volume": l.contract.volume, "symbol": l.contract.symbol,
                      "flags": l.contract.flags} for l in t.legs],
            "stock_units": t.stock_units,
            "price": {"mid": abs(t.price_mid), "natural": t.price_natural * (-1 if t.price_mid < 0 else 1),
                      "best": t.price_best * (-1 if t.price_mid < 0 else 1),
                      "side": "CREDIT" if t.price_mid < 0 else "DEBIT"},
            "score": s.total, "raw_score": s.raw_total,
            "components": [{k: c[k] for k in ("key", "label", "factor", "weight", "points")} for c in s.components],
            "penalties": s.penalties, "gates": s.gates, "disqualified": s.disqualified, "battle": s.battle,
            "status": e.decision.get("status"),
            "reasons": e.decision.get("avoid_reasons", []) + e.decision.get("wait_reasons", []),
            "metrics": {"em_ratio": _f(m.em_ratio, 3), "pop": _f(m.pop, 3), "p_itm": _f(m.p_itm_primary, 3),
                        "delta_shares": _f(m.net_delta_shares, 2), "theta_usd": _f(m.net_theta_usd, 2),
                        "vega_usd": _f(m.net_vega_usd, 2), "breakevens": [_f(b, 2) for b in t.breakevens],
                        "max_loss_usd": _f(m.max_loss_usd, 2), "max_gain_usd": _f(m.max_gain_usd, 2),
                        "capital_usd": _f(m.capital_usd, 2), "roc": _f(m.roc), "annualized_roc": _f(m.annualized_roc),
                        "iv": _f(m.primary_iv), "iv_rv": _f(m.iv_rv, 3), "liquidity": _f(m.liquidity["score"], 3),
                        "spread_cost_usd": _f(m.spread_cost_usd, 2), "primary_delta": _f(m.primary_delta_abs, 3),
                        "credit_usd": _f(m.credit_mid_usd, 2), "debit_usd": _f(m.debit_mid_usd, 2),
                        "distance_pct": _f(m.primary_distance_pct), "events_inside": len(m.events_inside)},
            "hypothetical": e.hypothetical, "requirements": e.requirements.get("notes", []),
            "portfolio_fit": (e.fit or {}).get("score"),
            "zone": e.zone,
        }

    def _underlying(self, ctx, snap) -> dict:
        bars = ctx.bars
        prev = bars[-2].close if len(bars) >= 2 else None
        last_close = bars[-1].close if bars else None
        ref = prev if (last_close and abs(last_close / ctx.spot - 1) < 1e-6) else last_close
        chg = (ctx.spot / ref - 1.0) if ref else None
        return {"symbol": ctx.symbol, "spot": ctx.spot, "spot_source": snap.spot_source, "change_pct": chg,
                "change_ref": "previous close" if ref else None, "chain_timestamp": snap.chain_timestamp,
                "freshness": ctx.freshness, "history_source": snap.history_source, "bars": len(bars),
                "provider": snap.provider, "is_mock": snap.is_mock, "quotes_missing": snap.quotes_missing}

    def _regime_payload(self, ctx) -> dict:
        r = ctx.regime.to_dict()
        fi = ctx.info(ctx.focus_exp) if ctx.focus_exp else None
        daily_em = (fi.atm_iv / math.sqrt(252.0)) if (fi and fi.atm_iv) else None
        r["posture"] = ctx.posture.to_dict()
        r["iv_regime"] = ctx.ivr
        r["expected_move"] = {"focus_expiration": ctx.focus_exp, "dte": fi.dte if fi else None,
                              "pct": fi.expected_move_pct if fi else None, "usd": fi.expected_move if fi else None,
                              "source": fi.em_source if fi else "unavailable", "daily_pct": daily_em,
                              "basis": "1 standard deviation = spot x ATM IV x sqrt(t) (calculated from observed IV)"}
        r["strategy_fit"] = []
        for s in ALL_STRATEGIES:
            f = strategy_regime_fit(s.key, ctx.posture, ctx.regime.label)
            r["strategy_fit"].append({"key": s.key, "name": STRATEGY_NAMES[s.key], "family": META[s.key].family,
                                      "fit": f["factor"], "reasons": f["reasons"]})
        r["strategy_fit"].sort(key=lambda x: -x["fit"])
        return r

    def _strategy_battle(self, evals: list, ctx) -> list:
        out = []
        for s in ALL_STRATEGIES:
            es = [e for e in evals if e.trade.strategy == s.key]
            ok = sorted((e for e in es if not e.score.disqualified), key=lambda e: -e.score.total)
            f = strategy_regime_fit(s.key, ctx.posture, ctx.regime.label)
            out.append({"key": s.key, "name": STRATEGY_NAMES[s.key], "family": META[s.key].family,
                        "regime_fit": f["factor"], "fit_reasons": f["reasons"], "n": len(es),
                        "n_disqualified": len(es) - len(ok), "best": self.summary(ok[0]) if ok else None,
                        "best_score": ok[0].score.total if ok else None})
        out.sort(key=lambda x: -(x["best_score"] or 0))
        return out

    def _arenas(self, evals: list, ctx) -> list:
        out = []
        for ar in ARENAS:
            strat_rows, parts, tops = [], {}, []
            for k in ar["strategies"]:
                es = [e for e in evals if e.trade.strategy == k]
                es.sort(key=lambda e: (e.score.disqualified, -e.score.total))
                ok = [e for e in es if not e.score.disqualified]
                best_exp = ok[0].trade.expiration.isoformat() if ok else (es[0].trade.expiration.isoformat() if es else None)
                strat_rows.append({"key": k, "name": STRATEGY_NAMES[k], "best_score": ok[0].score.total if ok else None,
                                   "n": len(es), "best_expiration": best_exp,
                                   "regime_fit": strategy_regime_fit(k, ctx.posture, ctx.regime.label)["factor"]})
                parts[k] = [self.summary(e) for e in es[:40]]
                tops.extend(ok[:3])
            ranked = [r for r in strat_rows if r["best_score"] is not None]
            default = max(ranked, key=lambda r: (r["best_score"], r["regime_fit"]))["key"] if ranked else ar["strategies"][0]
            out.append({"key": ar["key"], "title": ar["title"], "strategies": strat_rows, "default": default,
                        "participants": parts, "_top": [e for e in tops if e.trade.strategy == default]})
        return out

    def _headline_payload(self, e: Evaluated, ctx, evals: list) -> dict:
        same = sorted((x for x in evals if x.trade.strategy == e.trade.strategy and x is not e and not x.score.disqualified),
                      key=lambda x: -x.score.total)
        peers = [(x.score.total, f"{x.short_label} {x.trade.expiration:%b %d}") for x in same[:1]]
        inval = invalidation(e.trade, ctx)
        out = self.summary(e)
        out.update({"why": why_ranked(e, ctx, peers), "breaks": what_breaks(e, ctx, inval), "invalidation": inval,
                    "wait_condition": wait_condition(e.trade, ctx, e.decision, e.zone),
                    "checks": e.decision.get("checks", []),
                    "fit_statements": (e.fit or {}).get("statements", [])})
        return out

    def _chart(self, ctx, arenas: list, head: Optional[Evaluated]) -> dict:
        bars = ctx.bars
        n = len(bars)
        closes = [b.close for b in bars]
        win = 180
        start = max(0, n - win)

        def series(k: int) -> list:
            out, run = [], 0.0
            for i in range(n):
                run += closes[i]
                if i >= k:
                    run -= closes[i - k]
                out.append(run / k if i >= k - 1 else None)
            return out[start:]

        trs = [None] + [max(bars[i].high - bars[i].low, abs(bars[i].high - bars[i - 1].close),
                            abs(bars[i].low - bars[i - 1].close)) for i in range(1, n)]
        atr, a = [], None
        for i in range(n):
            if i == 14:
                a = sum(trs[1:15]) / 14.0
            elif i > 14:
                a = (a * 13 + trs[i]) / 14.0
            atr.append(a)
        s20 = series(20)
        atr_w = atr[start:]
        upper = [(m + 2 * x) if (m is not None and x is not None) else None for m, x in zip(s20, atr_w)]
        lower = [(m - 2 * x) if (m is not None and x is not None) else None for m, x in zip(s20, atr_w)]
        fi = ctx.info(ctx.focus_exp) if ctx.focus_exp else None
        cone = None
        if fi and fi.atm_iv and bars:
            pts = []
            days = max(1, fi.dte)
            for d in sorted({0, max(1, days // 4), max(1, days // 2), max(1, 3 * days // 4), days}):
                tt = d / 365.0
                em = ctx.spot * fi.atm_iv * math.sqrt(tt)
                pts.append({"days": d, "date": (ctx.today + dt.timedelta(days=d)).isoformat(), "em": em})
            cone = {"expiration": ctx.focus_exp, "points": pts, "atm_iv": fi.atm_iv,
                    "kind": "calculated (1 sd from ATM IV; not a forecast range)"}
        strikes = []
        for ar in arenas:
            for k, lst in ar["participants"].items():
                for p in lst[:6]:
                    for l in p["legs"]:
                        strikes.append({"strike": l["strike"], "right": l["right"], "strategy": k})
        return {"bars": [{"d": b.date.isoformat(), "o": b.open, "h": b.high, "l": b.low, "c": b.close, "v": b.volume}
                         for b in bars[start:]],
                "sma20": s20, "sma50": series(50), "sma200": series(200), "atr_upper": upper, "atr_lower": lower,
                "atr_band_def": "SMA20 +/- 2 x ATR14", "spot": ctx.spot, "cone": cone,
                "levels": {"supports": [lv.price for lv in ctx.levels.supports],
                           "resistances": [lv.price for lv in ctx.levels.resistances]},
                "strikes": strikes, "selected": [l.contract.strike for l in head.trade.legs] if head else []}

    # ------------------------------------------------------------------ detail / compare
    def trade_detail(self, aid: str, tid: str) -> dict:
        a = self.get(aid)
        e = a.by_id.get(tid)
        if e is None:
            raise AnalysisError("unknown trade id for this analysis", status=404)
        ctx = a.ctx
        if e.zone is None:
            e.zone = limit_zone(e.trade, e.score.total, ctx, a.weights, e.timing)
        risk = risk_report(e.trade, ctx, detail=True)
        american = []
        for l in e.trade.legs:
            c = l.contract
            if c.iv and c.t_years > 0:
                try:
                    eep = early_exercise_premium(c.right, c.spot, c.strike, c.t_years, ctx.cfg.risk_free,
                                                 ctx.cfg.div_for(c.underlying), c.iv)
                except Exception:
                    eep = None
                american.append({"leg": c.label, "early_exercise_premium": eep,
                                 "pct_of_mid": (eep / c.mid) if (eep is not None and c.mid > 0) else None})
        inval = invalidation(e.trade, ctx)
        same = sorted((x for x in a.evals if x.trade.strategy == e.trade.strategy and x is not e and not x.score.disqualified),
                      key=lambda x: -x.score.total)
        nearby = sorted((x for x in a.evals if x.trade.strategy == e.trade.strategy and x.trade.expiration == e.trade.expiration
                         and x is not e), key=lambda x: abs(x.trade.primary_leg.contract.strike - e.trade.primary_leg.contract.strike))[:4]
        summ = self.summary(e)
        summ["components"] = e.score.components
        detail = {
            "trade": summ,
            "why": why_ranked(e, ctx, [(x.score.total, f"{x.short_label} {x.trade.expiration:%b %d}") for x in same[:1]]),
            "breaks": what_breaks(e, ctx, inval), "invalidation": inval,
            "decision": e.decision, "wait_condition": wait_condition(e.trade, ctx, e.decision, e.zone),
            "zone": e.zone, "risk": risk, "american": american,
            "american_note": ("CRR binomial (American exercise) minus Black-Scholes (European) value per share. Scores use "
                              "Black-Scholes; a material early-exercise premium means short ITM legs can be assigned early."),
            "sizing": e.sizing or sizing_table(e.trade, e.metrics, ctx, None),
            "fit": e.fit or trade_fit(e.trade, e.metrics, ctx, None, None),
            "regime_fit": e.score.regime_fit_detail,
            "nearby": [{"id": x.trade.id, "label": x.short_label, "score": x.score.total, "status": x.decision.get("status"),
                        "delta": _f(x.metrics.primary_delta_abs, 3)} for x in nearby],
            "pipeline": self._pipeline(e, ctx, risk),
        }
        return sanitize(detail)

    def _pipeline(self, e: Evaluated, ctx, risk: dict) -> list:
        t = e.trade
        return [
            {"stage": "Raw data", "kind": "observed",
             "data": {"provider": ctx.provider, "is_mock": ctx.is_mock, "spot": ctx.spot,
                      "spot_source": ctx.snapshot.spot_source, "chain_timestamp": ctx.snapshot.chain_timestamp,
                      "legs_raw": [l.contract.raw for l in t.legs]}},
            {"stage": "Normalized data", "kind": "calculated",
             "data": [l.contract.to_dict() for l in t.legs]},
            {"stage": "Calculated metrics", "kind": "calculated", "data": e.metrics.to_dict()},
            {"stage": "Regime interpretation", "kind": "inferred",
             "data": {"label": ctx.regime.label, "confidence": ctx.regime.confidence, "lean": ctx.regime.lean,
                      "posture": ctx.posture.to_dict(), "iv_regime": ctx.ivr, "reasons": ctx.regime.reasons,
                      "override_notes": ctx.regime.override_notes}},
            {"stage": "Strategy fit", "kind": "calculated", "data": e.score.regime_fit_detail},
            {"stage": "Risk", "kind": "calculated / estimated", "data": risk},
            {"stage": "Score", "kind": "calculated",
             "data": {"total": e.score.total, "raw_total": e.score.raw_total, "components": e.score.components,
                      "penalties": e.score.penalties, "gates": e.score.gates, "weights": ctx.cfg.weights.normalized()}},
            {"stage": "Entry decision", "kind": "calculated",
             "data": {"decision": e.decision, "zone": e.zone, "timing": e.timing}},
        ]

    def compare(self, aid: str, ids: list) -> dict:
        a = self.get(aid)
        es = [a.by_id[i] for i in ids if i in a.by_id][:6]
        if len(es) < 2:
            raise AnalysisError("select at least two contracts to compare")
        return sanitize(compare_evals(es, a.ctx))


def cfg_max_symbols() -> int:
    return 12
