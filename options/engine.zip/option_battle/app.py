"""Wawas Options Suggester - local web server (stdlib only; runs on Android Termux).

    python -m option_battle.app                 # live CBOE delayed data, http://127.0.0.1:8765
    python -m option_battle.app --mock          # synthetic data, no network needed
    python -m option_battle.app --cli SPY       # text battle board in the terminal

Binds to 127.0.0.1 by default (local only). Use --host 0.0.0.0 to reach it from another device on your network.
The server never places orders and never writes portfolio data to disk.
"""
from __future__ import annotations

import argparse
import gzip
import json
import logging
import mimetypes
import os
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Optional
from urllib.parse import parse_qs, urlparse

if __package__ in (None, ""):          # allow `python app.py` from inside the folder
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    __package__ = "option_battle"      # noqa: A001

from option_battle import ENGINE_NAME, VERSION
from option_battle.config import Config
from option_battle.api import Api
from option_battle.data.providers import PROVIDERS
from option_battle.engine import AnalysisError, Engine

LOG = logging.getLogger("option_battle.app")
HERE = os.path.dirname(os.path.abspath(__file__))
UI_DIR = os.path.join(HERE, "ui")
MAX_BODY = 512 * 1024


def make_handler(api: Api, quiet: bool = False):
    class Handler(BaseHTTPRequestHandler):
        server_version = f"WawasOptionsSuggester/{VERSION}"

        def log_message(self, fmt, *args):  # route through logging
            if not quiet:
                LOG.info("%s %s", self.address_string(), fmt % args)

        # -------------------------------------------------------------- responses
        def _send(self, code: int, body: bytes, ctype: str, cache: bool = False) -> None:
            gz = "gzip" in (self.headers.get("Accept-Encoding") or "") and len(body) > 1400
            if gz:
                body = gzip.compress(body, 6)
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "max-age=300" if cache else "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            if gz:
                self.send_header("Content-Encoding", "gzip")
            self.end_headers()
            self.wfile.write(body)

        def _json(self, code: int, obj) -> None:
            self._send(code, json.dumps(obj, separators=(",", ":"), default=str).encode("utf-8"),
                       "application/json; charset=utf-8")

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length") or 0)
            if n > MAX_BODY:
                raise AnalysisError("request body too large", status=413)
            raw = self.rfile.read(n) if n else b"{}"
            try:
                d = json.loads(raw.decode("utf-8") or "{}")
            except ValueError:
                raise AnalysisError("request body is not valid JSON") from None
            if not isinstance(d, dict):
                raise AnalysisError("request body must be a JSON object")
            return d

        def _guard(self, fn) -> None:
            t = time.time()
            try:
                self._json(200, fn())
            except AnalysisError as exc:
                self._json(exc.status, {"error": str(exc), "hint": exc.hint})
            except Exception as exc:  # last line of defence: report, never crash the server
                LOG.error("unhandled error: %s\n%s", exc, traceback.format_exc())
                self._json(500, {"error": f"internal error: {exc}", "hint": "See the server log in Termux."})
            finally:
                LOG.debug("%s took %.0f ms", self.path, (time.time() - t) * 1000)

        def _static(self, rel: str) -> None:
            path = os.path.normpath(os.path.join(UI_DIR, rel))
            if not path.startswith(UI_DIR + os.sep) or not os.path.isfile(path):
                self._json(404, {"error": "not found"})
                return
            ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype in ("application/javascript",):
                ctype += "; charset=utf-8"
            with open(path, "rb") as fh:
                self._send(200, fh.read(), ctype, cache=False)

        # -------------------------------------------------------------- routes
        def do_GET(self) -> None:  # noqa: N802
            u = urlparse(self.path)
            q = {k: v[0] for k, v in parse_qs(u.query).items()}
            if u.path in ("/", "/index.html"):
                return self._static("templates/index.html")
            if u.path.startswith("/static/"):
                return self._static(u.path[1:])
            if u.path == "/api/health":
                return self._json(200, {"ok": True, "engine": ENGINE_NAME, "version": VERSION})
            if u.path == "/api/meta":
                return self._guard(api.meta)
            if u.path == "/api/trade":
                return self._guard(lambda: api.trade(q))
            self._json(404, {"error": f"no route {u.path}"})

        def do_POST(self) -> None:  # noqa: N802
            u = urlparse(self.path)
            routes = {"/api/analyze": api.analyze, "/api/compare": api.compare,
                      "/api/portfolio/parse": api.parse_portfolio, "/api/portfolio/check": api.check_portfolio,
                      "/api/portfolio/import_csv": api.import_csv, "/api/backtest": api.backtest}
            fn = routes.get(u.path)
            if fn is None:
                return self._json(404, {"error": f"no route {u.path}"})
            self._guard(lambda: fn(self._body()))

    return Handler


def serve(host: str, port: int, engine: Engine, quiet: bool = False) -> None:
    mimetypes.add_type("application/javascript", ".js")
    mimetypes.add_type("text/css", ".css")
    srv = ThreadingHTTPServer((host, port), make_handler(Api(engine), quiet))
    srv.daemon_threads = True
    url = f"http://{'127.0.0.1' if host in ('0.0.0.0', '') else host}:{port}"
    print(f"\n  {ENGINE_NAME} v{VERSION}\n  provider: {engine.default_provider.upper()}\n  open {url} in your browser"
          f"\n  Ctrl+C to stop\n", flush=True)
    try:
        srv.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("\nstopped. nothing was saved.")
    finally:
        srv.server_close()


def main(argv: Optional[list] = None) -> int:
    ap = argparse.ArgumentParser(description=f"{ENGINE_NAME}: local regime-aware options analytics")
    ap.add_argument("--host", default=os.environ.get("OPTION_BATTLE_HOST", "127.0.0.1"))
    ap.add_argument("--port", type=int, default=int(os.environ.get("OPTION_BATTLE_PORT", "8765")))
    ap.add_argument("--provider", choices=PROVIDERS, default=os.environ.get("OPTION_BATTLE_PROVIDER", "cboe"))
    ap.add_argument("--mock", action="store_true", help="shortcut for --provider mock")
    ap.add_argument("--config", default="", help="JSON config overrides file")
    ap.add_argument("--events", default="", help="JSON events file (earnings, ex-dividend, ...)")
    ap.add_argument("--cli", metavar="SYMBOL", help="print a text battle board and exit")
    ap.add_argument("--scenario", default="bull_pullback", help="mock scenario for --cli")
    ap.add_argument("--debug", action="store_true")
    ap.add_argument("--quiet", action="store_true", help="no per-request log lines")
    a = ap.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if a.debug else logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s", stream=sys.stderr)
    if a.config:
        os.environ["OPTION_BATTLE_CONFIG"] = a.config
    base = {"events_file": a.events} if a.events else {}
    engine = Engine("mock" if a.mock else a.provider, base)
    if a.cli:
        from option_battle.cli import print_board
        return print_board(engine, a.cli, "mock" if a.mock else a.provider, a.scenario)
    serve(a.host, a.port, engine, a.quiet)
    return 0


if __name__ == "__main__":
    sys.exit(main())
