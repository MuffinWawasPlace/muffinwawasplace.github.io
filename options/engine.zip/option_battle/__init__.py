"""Wawas Options Suggester: regime-aware, explainable local options analytics."""

VERSION = "1.1.0"
ENGINE_NAME = "WAWAS OPTIONS SUGGESTER"
